// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.serialization;

public interface ClassNameMatcher
{
    boolean matches(final String p0);
}
