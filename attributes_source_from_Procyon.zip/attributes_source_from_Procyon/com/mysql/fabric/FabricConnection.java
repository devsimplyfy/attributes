// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric;

import java.util.concurrent.TimeUnit;
import java.util.Iterator;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import com.mysql.fabric.proto.xmlrpc.XmlRpcClient;

public class FabricConnection
{
    private XmlRpcClient client;
    private Map<String, ShardMapping> shardMappingsByTableName;
    private Map<String, ServerGroup> serverGroupsByName;
    private long shardMappingsExpiration;
    private int shardMappingsTtl;
    private long serverGroupsExpiration;
    private int serverGroupsTtl;
    
    public FabricConnection(final String url, final String username, final String password) throws FabricCommunicationException {
        this.shardMappingsByTableName = new HashMap<String, ShardMapping>();
        this.serverGroupsByName = new HashMap<String, ServerGroup>();
        this.client = new XmlRpcClient(url, username, password);
        this.refreshState();
    }
    
    public FabricConnection(final Set<String> urls, final String username, final String password) throws FabricCommunicationException {
        this.shardMappingsByTableName = new HashMap<String, ShardMapping>();
        this.serverGroupsByName = new HashMap<String, ServerGroup>();
        throw new UnsupportedOperationException("Multiple connections not supported.");
    }
    
    public String getInstanceUuid() {
        return null;
    }
    
    public int getVersion() {
        return 0;
    }
    
    public int refreshState() throws FabricCommunicationException {
        final FabricStateResponse<Set<ServerGroup>> serverGroups = this.client.getServerGroups();
        final FabricStateResponse<Set<ShardMapping>> shardMappings = this.client.getShardMappings();
        this.serverGroupsExpiration = serverGroups.getExpireTimeMillis();
        this.serverGroupsTtl = serverGroups.getTtl();
        for (final ServerGroup g : serverGroups.getData()) {
            this.serverGroupsByName.put(g.getName(), g);
        }
        this.shardMappingsExpiration = shardMappings.getExpireTimeMillis();
        this.shardMappingsTtl = shardMappings.getTtl();
        for (final ShardMapping m : shardMappings.getData()) {
            for (final ShardTable t : m.getShardTables()) {
                this.shardMappingsByTableName.put(t.getDatabase() + "." + t.getTable(), m);
            }
        }
        return 0;
    }
    
    public int refreshStatePassive() {
        try {
            return this.refreshState();
        }
        catch (FabricCommunicationException e) {
            this.serverGroupsExpiration = System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(this.serverGroupsTtl);
            this.shardMappingsExpiration = System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(this.shardMappingsTtl);
            return 0;
        }
    }
    
    public ServerGroup getServerGroup(final String serverGroupName) {
        if (this.isStateExpired()) {
            this.refreshStatePassive();
        }
        return this.serverGroupsByName.get(serverGroupName);
    }
    
    public ShardMapping getShardMapping(final String database, final String table) {
        if (this.isStateExpired()) {
            this.refreshStatePassive();
        }
        return this.shardMappingsByTableName.get(database + "." + table);
    }
    
    public boolean isStateExpired() {
        return System.currentTimeMillis() > this.shardMappingsExpiration || System.currentTimeMillis() > this.serverGroupsExpiration;
    }
    
    public Set<String> getFabricHosts() {
        return null;
    }
    
    public XmlRpcClient getClient() {
        return this.client;
    }
}
