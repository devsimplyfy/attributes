// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.jdbc;

import com.mysql.jdbc.JDBC4MySQLConnection;
import com.mysql.jdbc.JDBC4ClientInfoProvider;
import java.sql.Struct;
import java.sql.Array;
import java.sql.SQLClientInfoException;
import com.mysql.jdbc.Connection;
import java.util.Iterator;
import com.mysql.jdbc.ReplicationConnection;
import java.sql.SQLXML;
import java.sql.NClob;
import java.sql.Clob;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Properties;
import com.mysql.fabric.FabricConnection;

public class JDBC4FabricMySQLConnectionProxy extends FabricMySQLConnectionProxy implements JDBC4FabricMySQLConnection, FabricMySQLConnectionProperties
{
    private static final long serialVersionUID = 5845485979107347258L;
    private FabricConnection fabricConnection;
    
    public JDBC4FabricMySQLConnectionProxy(final Properties props) throws SQLException {
        super(props);
    }
    
    @Override
    public Blob createBlob() {
        try {
            this.transactionBegun();
            return this.getActiveConnection().createBlob();
        }
        catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    @Override
    public Clob createClob() {
        try {
            this.transactionBegun();
            return this.getActiveConnection().createClob();
        }
        catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    @Override
    public NClob createNClob() {
        try {
            this.transactionBegun();
            return this.getActiveConnection().createNClob();
        }
        catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    @Override
    public SQLXML createSQLXML() throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().createSQLXML();
    }
    
    @Override
    public void setClientInfo(final Properties properties) throws SQLClientInfoException {
        for (final Connection c : this.serverConnections.values()) {
            c.setClientInfo(properties);
        }
    }
    
    @Override
    public void setClientInfo(final String name, final String value) throws SQLClientInfoException {
        for (final Connection c : this.serverConnections.values()) {
            c.setClientInfo(name, value);
        }
    }
    
    @Override
    public Array createArrayOf(final String typeName, final Object[] elements) throws SQLException {
        return this.getActiveConnection().createArrayOf(typeName, elements);
    }
    
    @Override
    public Struct createStruct(final String typeName, final Object[] attributes) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().createStruct(typeName, attributes);
    }
    
    @Override
    public JDBC4ClientInfoProvider getClientInfoProviderImpl() throws SQLException {
        return ((JDBC4MySQLConnection)this.getActiveConnection()).getClientInfoProviderImpl();
    }
}
