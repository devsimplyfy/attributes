// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.jdbc;

import com.mysql.jdbc.ConnectionProperties;

public interface FabricMySQLConnectionProperties extends ConnectionProperties
{
    void setFabricShardKey(final String p0);
    
    String getFabricShardKey();
    
    void setFabricShardTable(final String p0);
    
    String getFabricShardTable();
    
    void setFabricServerGroup(final String p0);
    
    String getFabricServerGroup();
    
    void setFabricProtocol(final String p0);
    
    String getFabricProtocol();
    
    void setFabricUsername(final String p0);
    
    String getFabricUsername();
    
    void setFabricPassword(final String p0);
    
    String getFabricPassword();
    
    void setFabricReportErrors(final boolean p0);
    
    boolean getFabricReportErrors();
}
