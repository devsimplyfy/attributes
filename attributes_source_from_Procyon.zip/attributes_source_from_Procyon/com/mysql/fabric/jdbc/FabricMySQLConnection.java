// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.jdbc;

import java.util.Set;
import com.mysql.fabric.ServerGroup;
import java.sql.SQLException;
import com.mysql.jdbc.MySQLConnection;

public interface FabricMySQLConnection extends MySQLConnection
{
    void clearServerSelectionCriteria() throws SQLException;
    
    void setShardKey(final String p0) throws SQLException;
    
    String getShardKey();
    
    void setShardTable(final String p0) throws SQLException;
    
    String getShardTable();
    
    void setServerGroupName(final String p0) throws SQLException;
    
    String getServerGroupName();
    
    ServerGroup getCurrentServerGroup();
    
    void clearQueryTables() throws SQLException;
    
    void addQueryTable(final String p0) throws SQLException;
    
    Set<String> getQueryTables();
}
