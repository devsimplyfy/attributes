// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.jdbc;

import java.util.Properties;
import com.mysql.fabric.FabricCommunicationException;
import com.mysql.jdbc.SQLError;
import com.mysql.jdbc.ConnectionImpl;
import com.mysql.jdbc.MySQLConnection;
import com.mysql.jdbc.Connection;
import java.sql.SQLException;
import com.mysql.jdbc.ExceptionInterceptor;

public class ErrorReportingExceptionInterceptor implements ExceptionInterceptor
{
    private String hostname;
    private String port;
    private String fabricHaGroup;
    
    public SQLException interceptException(final SQLException sqlEx, final Connection conn) {
        final MySQLConnection mysqlConn = (MySQLConnection)conn;
        if (ConnectionImpl.class.isAssignableFrom(mysqlConn.getMultiHostSafeProxy().getClass())) {
            return null;
        }
        final FabricMySQLConnectionProxy fabricProxy = (FabricMySQLConnectionProxy)mysqlConn.getMultiHostSafeProxy();
        try {
            return fabricProxy.interceptException(sqlEx, conn, this.fabricHaGroup, this.hostname, this.port);
        }
        catch (FabricCommunicationException ex) {
            return SQLError.createSQLException("Failed to report error to Fabric.", "08S01", ex, null);
        }
    }
    
    public void init(final Connection conn, final Properties props) throws SQLException {
        this.hostname = props.getProperty("HOST");
        this.port = props.getProperty("PORT");
        final String connectionAttributes = props.getProperty("connectionAttributes");
        this.fabricHaGroup = connectionAttributes.replaceAll("^.*\\bfabricHaGroup:(.+)\\b.*$", "$1");
    }
    
    public void destroy() {
    }
}
