// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.jdbc;

import com.mysql.jdbc.Util;
import java.util.Collections;
import com.mysql.jdbc.profiler.ProfilerEventHandler;
import java.sql.SQLWarning;
import com.mysql.jdbc.ServerPreparedStatement;
import com.mysql.jdbc.StatementInterceptorV2;
import com.mysql.jdbc.SingleByteCharsetConverter;
import java.util.Timer;
import com.mysql.jdbc.CachedResultSetMetaData;
import java.util.concurrent.Executor;
import com.mysql.jdbc.Extension;
import com.mysql.jdbc.ConnectionProperties;
import java.sql.DatabaseMetaData;
import java.util.TimeZone;
import java.util.Calendar;
import com.mysql.jdbc.MysqlIO;
import com.mysql.jdbc.ResultSetInternalMethods;
import com.mysql.jdbc.Field;
import com.mysql.jdbc.Buffer;
import com.mysql.jdbc.StatementImpl;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.CallableStatement;
import java.sql.Savepoint;
import java.util.List;
import com.mysql.jdbc.ReplicationConnectionProxy;
import java.util.ArrayList;
import java.util.Iterator;
import com.mysql.jdbc.MySQLConnection;
import com.mysql.jdbc.ReplicationConnectionGroup;
import com.mysql.fabric.Server;
import com.mysql.jdbc.ReplicationConnectionGroupManager;
import com.mysql.jdbc.exceptions.MySQLNonTransientConnectionException;
import java.sql.SQLException;
import com.mysql.jdbc.ExceptionInterceptor;
import com.mysql.jdbc.log.LogFactory;
import com.mysql.fabric.FabricCommunicationException;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.SQLError;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Properties;
import com.mysql.fabric.ShardMapping;
import java.util.Set;
import com.mysql.jdbc.ReplicationConnection;
import com.mysql.fabric.ServerGroup;
import java.util.Map;
import com.mysql.fabric.FabricConnection;
import com.mysql.jdbc.log.Log;
import com.mysql.jdbc.ConnectionPropertiesImpl;

public class FabricMySQLConnectionProxy extends ConnectionPropertiesImpl implements FabricMySQLConnection, FabricMySQLConnectionProperties
{
    private static final long serialVersionUID = 5845485979107347258L;
    private Log log;
    protected FabricConnection fabricConnection;
    protected boolean closed;
    protected boolean transactionInProgress;
    protected Map<ServerGroup, ReplicationConnection> serverConnections;
    protected ReplicationConnection currentConnection;
    protected String shardKey;
    protected String shardTable;
    protected String serverGroupName;
    protected Set<String> queryTables;
    protected ServerGroup serverGroup;
    protected String host;
    protected String port;
    protected String username;
    protected String password;
    protected String database;
    protected ShardMapping shardMapping;
    protected boolean readOnly;
    protected boolean autoCommit;
    protected int transactionIsolation;
    private String fabricShardKey;
    private String fabricShardTable;
    private String fabricServerGroup;
    private String fabricProtocol;
    private String fabricUsername;
    private String fabricPassword;
    private boolean reportErrors;
    private static final Set<String> replConnGroupLocks;
    private static final Class<?> JDBC4_NON_TRANSIENT_CONN_EXCEPTION;
    
    public FabricMySQLConnectionProxy(final Properties props) throws SQLException {
        this.closed = false;
        this.transactionInProgress = false;
        this.serverConnections = new HashMap<ServerGroup, ReplicationConnection>();
        this.queryTables = new HashSet<String>();
        this.readOnly = false;
        this.autoCommit = true;
        this.transactionIsolation = 4;
        this.reportErrors = false;
        this.fabricShardKey = props.getProperty("fabricShardKey");
        this.fabricShardTable = props.getProperty("fabricShardTable");
        this.fabricServerGroup = props.getProperty("fabricServerGroup");
        this.fabricProtocol = props.getProperty("fabricProtocol");
        this.fabricUsername = props.getProperty("fabricUsername");
        this.fabricPassword = props.getProperty("fabricPassword");
        this.reportErrors = Boolean.valueOf(props.getProperty("fabricReportErrors"));
        props.remove("fabricShardKey");
        props.remove("fabricShardTable");
        props.remove("fabricServerGroup");
        props.remove("fabricProtocol");
        props.remove("fabricUsername");
        props.remove("fabricPassword");
        props.remove("fabricReportErrors");
        this.host = props.getProperty("HOST");
        this.port = props.getProperty("PORT");
        this.username = props.getProperty("user");
        this.password = props.getProperty("password");
        this.database = props.getProperty("DBNAME");
        if (this.username == null) {
            this.username = "";
        }
        if (this.password == null) {
            this.password = "";
        }
        String exceptionInterceptors = props.getProperty("exceptionInterceptors");
        if (exceptionInterceptors == null || "null".equals("exceptionInterceptors")) {
            exceptionInterceptors = "";
        }
        else {
            exceptionInterceptors += ",";
        }
        exceptionInterceptors += "com.mysql.fabric.jdbc.ErrorReportingExceptionInterceptor";
        props.setProperty("exceptionInterceptors", exceptionInterceptors);
        this.initializeProperties(props);
        if (this.fabricServerGroup != null && this.fabricShardTable != null) {
            throw SQLError.createSQLException("Server group and shard table are mutually exclusive. Only one may be provided.", "08004", null, this.getExceptionInterceptor(), this);
        }
        try {
            final String url = this.fabricProtocol + "://" + this.host + ":" + this.port;
            this.fabricConnection = new FabricConnection(url, this.fabricUsername, this.fabricPassword);
        }
        catch (FabricCommunicationException ex) {
            throw SQLError.createSQLException("Unable to establish connection to the Fabric server", "08004", ex, this.getExceptionInterceptor(), this);
        }
        this.log = LogFactory.getLogger(this.getLogger(), "FabricMySQLConnectionProxy", null);
        this.setShardTable(this.fabricShardTable);
        this.setShardKey(this.fabricShardKey);
        this.setServerGroupName(this.fabricServerGroup);
    }
    
    synchronized SQLException interceptException(final SQLException sqlEx, final Connection conn, final String groupName, final String hostname, final String portNumber) throws FabricCommunicationException {
        if (((sqlEx.getSQLState() == null || !sqlEx.getSQLState().startsWith("08")) && !MySQLNonTransientConnectionException.class.isAssignableFrom(sqlEx.getClass()) && (FabricMySQLConnectionProxy.JDBC4_NON_TRANSIENT_CONN_EXCEPTION == null || !FabricMySQLConnectionProxy.JDBC4_NON_TRANSIENT_CONN_EXCEPTION.isAssignableFrom(sqlEx.getClass()))) || (sqlEx.getCause() != null && FabricCommunicationException.class.isAssignableFrom(sqlEx.getCause().getClass()))) {
            return null;
        }
        final Server currentServer = this.serverGroup.getServer(hostname + ":" + portNumber);
        if (currentServer == null) {
            return null;
        }
        if (this.reportErrors) {
            this.fabricConnection.getClient().reportServerError(currentServer, sqlEx.toString(), true);
        }
        if (FabricMySQLConnectionProxy.replConnGroupLocks.add(this.serverGroup.getName())) {
            try {
                try {
                    this.fabricConnection.refreshStatePassive();
                    this.setCurrentServerGroup(this.serverGroup.getName());
                }
                catch (SQLException ex) {
                    return SQLError.createSQLException("Unable to refresh Fabric state. Failover impossible", "08006", ex, null);
                }
                try {
                    this.syncGroupServersToReplicationConnectionGroup(ReplicationConnectionGroupManager.getConnectionGroup(groupName));
                }
                catch (SQLException ex) {
                    return ex;
                }
            }
            finally {
                FabricMySQLConnectionProxy.replConnGroupLocks.remove(this.serverGroup.getName());
            }
            return null;
        }
        return SQLError.createSQLException("Fabric state syncing already in progress in another thread.", "08006", sqlEx, null);
    }
    
    private void refreshStateIfNecessary() throws SQLException {
        if (this.fabricConnection.isStateExpired()) {
            this.fabricConnection.refreshStatePassive();
            if (this.serverGroup != null) {
                this.setCurrentServerGroup(this.serverGroup.getName());
            }
        }
    }
    
    public void setShardKey(final String shardKey) throws SQLException {
        this.ensureNoTransactionInProgress();
        this.currentConnection = null;
        if (shardKey != null) {
            if (this.serverGroupName != null) {
                throw SQLError.createSQLException("Shard key cannot be provided when server group is chosen directly.", "S1009", null, this.getExceptionInterceptor(), this);
            }
            if (this.shardTable == null) {
                throw SQLError.createSQLException("Shard key cannot be provided without a shard table.", "S1009", null, this.getExceptionInterceptor(), this);
            }
            this.setCurrentServerGroup(this.shardMapping.getGroupNameForKey(shardKey));
        }
        else if (this.shardTable != null) {
            this.setCurrentServerGroup(this.shardMapping.getGlobalGroupName());
        }
        this.shardKey = shardKey;
    }
    
    public String getShardKey() {
        return this.shardKey;
    }
    
    public void setShardTable(final String shardTable) throws SQLException {
        this.ensureNoTransactionInProgress();
        this.currentConnection = null;
        if (this.serverGroupName != null) {
            throw SQLError.createSQLException("Server group and shard table are mutually exclusive. Only one may be provided.", "S1009", null, this.getExceptionInterceptor(), this);
        }
        this.shardKey = null;
        this.serverGroup = null;
        if ((this.shardTable = shardTable) == null) {
            this.shardMapping = null;
        }
        else {
            String table = shardTable;
            String db = this.database;
            if (shardTable.contains(".")) {
                final String[] pair = shardTable.split("\\.");
                db = pair[0];
                table = pair[1];
            }
            this.shardMapping = this.fabricConnection.getShardMapping(db, table);
            if (this.shardMapping == null) {
                throw SQLError.createSQLException("Shard mapping not found for table `" + shardTable + "'", "S1009", null, this.getExceptionInterceptor(), this);
            }
            this.setCurrentServerGroup(this.shardMapping.getGlobalGroupName());
        }
    }
    
    public String getShardTable() {
        return this.shardTable;
    }
    
    public void setServerGroupName(final String serverGroupName) throws SQLException {
        this.ensureNoTransactionInProgress();
        this.currentConnection = null;
        if (serverGroupName != null) {
            this.setCurrentServerGroup(serverGroupName);
        }
        this.serverGroupName = serverGroupName;
    }
    
    public String getServerGroupName() {
        return this.serverGroupName;
    }
    
    public void clearServerSelectionCriteria() throws SQLException {
        this.ensureNoTransactionInProgress();
        this.shardTable = null;
        this.shardKey = null;
        this.serverGroupName = null;
        this.serverGroup = null;
        this.queryTables.clear();
        this.currentConnection = null;
    }
    
    public ServerGroup getCurrentServerGroup() {
        return this.serverGroup;
    }
    
    public void clearQueryTables() throws SQLException {
        this.ensureNoTransactionInProgress();
        this.currentConnection = null;
        this.queryTables.clear();
        this.setShardTable(null);
    }
    
    public void addQueryTable(final String tableName) throws SQLException {
        this.ensureNoTransactionInProgress();
        this.currentConnection = null;
        if (this.shardMapping == null) {
            if (this.fabricConnection.getShardMapping(this.database, tableName) != null) {
                this.setShardTable(tableName);
            }
        }
        else {
            final ShardMapping mappingForTableName = this.fabricConnection.getShardMapping(this.database, tableName);
            if (mappingForTableName != null && !mappingForTableName.equals(this.shardMapping)) {
                throw SQLError.createSQLException("Cross-shard query not allowed", "S1009", null, this.getExceptionInterceptor(), this);
            }
        }
        this.queryTables.add(tableName);
    }
    
    public Set<String> getQueryTables() {
        return this.queryTables;
    }
    
    protected void setCurrentServerGroup(final String serverGroupName) throws SQLException {
        this.serverGroup = this.fabricConnection.getServerGroup(serverGroupName);
        if (this.serverGroup == null) {
            throw SQLError.createSQLException("Cannot find server group: `" + serverGroupName + "'", "S1009", null, this.getExceptionInterceptor(), this);
        }
        final ReplicationConnectionGroup replConnGroup = ReplicationConnectionGroupManager.getConnectionGroup(serverGroupName);
        if (replConnGroup != null && FabricMySQLConnectionProxy.replConnGroupLocks.add(this.serverGroup.getName())) {
            try {
                this.syncGroupServersToReplicationConnectionGroup(replConnGroup);
            }
            finally {
                FabricMySQLConnectionProxy.replConnGroupLocks.remove(this.serverGroup.getName());
            }
        }
    }
    
    protected MySQLConnection getActiveMySQLConnectionChecked() throws SQLException {
        final ReplicationConnection c = (ReplicationConnection)this.getActiveConnection();
        final MySQLConnection mc = (MySQLConnection)c.getCurrentConnection();
        return mc;
    }
    
    public MySQLConnection getActiveMySQLConnection() {
        try {
            return this.getActiveMySQLConnectionChecked();
        }
        catch (SQLException ex) {
            throw new IllegalStateException("Unable to determine active connection", ex);
        }
    }
    
    protected Connection getActiveConnectionPassive() {
        try {
            return this.getActiveConnection();
        }
        catch (SQLException ex) {
            throw new IllegalStateException("Unable to determine active connection", ex);
        }
    }
    
    private void syncGroupServersToReplicationConnectionGroup(final ReplicationConnectionGroup replConnGroup) throws SQLException {
        String currentMasterString = null;
        if (replConnGroup.getMasterHosts().size() == 1) {
            currentMasterString = replConnGroup.getMasterHosts().iterator().next();
        }
        Label_0103: {
            if (currentMasterString != null) {
                if (this.serverGroup.getMaster() != null) {
                    if (currentMasterString.equals(this.serverGroup.getMaster().getHostPortString())) {
                        break Label_0103;
                    }
                }
                try {
                    replConnGroup.removeMasterHost(currentMasterString, false);
                }
                catch (SQLException ex) {
                    this.getLog().logWarn("Unable to remove master: " + currentMasterString, ex);
                }
            }
        }
        final Server newMaster = this.serverGroup.getMaster();
        if (newMaster != null && replConnGroup.getMasterHosts().size() == 0) {
            this.getLog().logInfo("Changing master for group '" + replConnGroup.getGroupName() + "' to: " + newMaster);
            try {
                if (!replConnGroup.getSlaveHosts().contains(newMaster.getHostPortString())) {
                    replConnGroup.addSlaveHost(newMaster.getHostPortString());
                }
                replConnGroup.promoteSlaveToMaster(newMaster.getHostPortString());
            }
            catch (SQLException ex2) {
                throw SQLError.createSQLException("Unable to promote new master '" + newMaster.toString() + "'", ex2.getSQLState(), ex2, null);
            }
        }
        for (final Server s : this.serverGroup.getServers()) {
            if (s.isSlave()) {
                try {
                    replConnGroup.addSlaveHost(s.getHostPortString());
                }
                catch (SQLException ex3) {
                    this.getLog().logWarn("Unable to add slave: " + s.toString(), ex3);
                }
            }
        }
        for (final String hostPortString : replConnGroup.getSlaveHosts()) {
            final Server fabServer = this.serverGroup.getServer(hostPortString);
            if (fabServer != null) {
                if (fabServer.isSlave()) {
                    continue;
                }
            }
            try {
                replConnGroup.removeSlaveHost(hostPortString, true);
            }
            catch (SQLException ex4) {
                this.getLog().logWarn("Unable to remove slave: " + hostPortString, ex4);
            }
        }
    }
    
    protected Connection getActiveConnection() throws SQLException {
        if (!this.transactionInProgress) {
            this.refreshStateIfNecessary();
        }
        if (this.currentConnection != null) {
            return this.currentConnection;
        }
        if (this.getCurrentServerGroup() == null) {
            throw SQLError.createSQLException("No server group selected.", "08004", null, this.getExceptionInterceptor(), this);
        }
        this.currentConnection = this.serverConnections.get(this.serverGroup);
        if (this.currentConnection != null) {
            return this.currentConnection;
        }
        final List<String> masterHost = new ArrayList<String>();
        final List<String> slaveHosts = new ArrayList<String>();
        for (final Server s : this.serverGroup.getServers()) {
            if (s.isMaster()) {
                masterHost.add(s.getHostPortString());
            }
            else {
                if (!s.isSlave()) {
                    continue;
                }
                slaveHosts.add(s.getHostPortString());
            }
        }
        final Properties info = this.exposeAsProperties(null);
        final ReplicationConnectionGroup replConnGroup = ReplicationConnectionGroupManager.getConnectionGroup(this.serverGroup.getName());
        if (replConnGroup != null && FabricMySQLConnectionProxy.replConnGroupLocks.add(this.serverGroup.getName())) {
            try {
                this.syncGroupServersToReplicationConnectionGroup(replConnGroup);
            }
            finally {
                FabricMySQLConnectionProxy.replConnGroupLocks.remove(this.serverGroup.getName());
            }
        }
        info.put("replicationConnectionGroup", this.serverGroup.getName());
        info.setProperty("user", this.username);
        info.setProperty("password", this.password);
        info.setProperty("DBNAME", this.getCatalog());
        info.setProperty("connectionAttributes", "fabricHaGroup:" + this.serverGroup.getName());
        info.setProperty("retriesAllDown", "1");
        info.setProperty("allowMasterDownConnections", "true");
        info.setProperty("allowSlaveDownConnections", "true");
        info.setProperty("readFromMasterWhenNoSlaves", "true");
        this.currentConnection = ReplicationConnectionProxy.createProxyInstance(masterHost, info, slaveHosts, info);
        this.serverConnections.put(this.serverGroup, this.currentConnection);
        this.currentConnection.setProxy(this);
        this.currentConnection.setAutoCommit(this.autoCommit);
        this.currentConnection.setReadOnly(this.readOnly);
        this.currentConnection.setTransactionIsolation(this.transactionIsolation);
        return this.currentConnection;
    }
    
    private void ensureOpen() throws SQLException {
        if (this.closed) {
            throw SQLError.createSQLException("No operations allowed after connection closed.", "08003", this.getExceptionInterceptor());
        }
    }
    
    private void ensureNoTransactionInProgress() throws SQLException {
        this.ensureOpen();
        if (this.transactionInProgress && !this.autoCommit) {
            throw SQLError.createSQLException("Not allow while a transaction is active.", "25000", this.getExceptionInterceptor());
        }
    }
    
    public void close() throws SQLException {
        this.closed = true;
        for (final Connection c : this.serverConnections.values()) {
            try {
                c.close();
            }
            catch (SQLException ex) {}
        }
    }
    
    public boolean isClosed() {
        return this.closed;
    }
    
    public boolean isValid(final int timeout) throws SQLException {
        return !this.closed;
    }
    
    public void setReadOnly(final boolean readOnly) throws SQLException {
        this.readOnly = readOnly;
        for (final ReplicationConnection conn : this.serverConnections.values()) {
            conn.setReadOnly(readOnly);
        }
    }
    
    public boolean isReadOnly() throws SQLException {
        return this.readOnly;
    }
    
    public boolean isReadOnly(final boolean useSessionStatus) throws SQLException {
        return this.readOnly;
    }
    
    public void setCatalog(final String catalog) throws SQLException {
        this.database = catalog;
        for (final Connection c : this.serverConnections.values()) {
            c.setCatalog(catalog);
        }
    }
    
    public String getCatalog() {
        return this.database;
    }
    
    public void rollback() throws SQLException {
        this.getActiveConnection().rollback();
        this.transactionCompleted();
    }
    
    public void rollback(final Savepoint savepoint) throws SQLException {
        this.getActiveConnection().rollback();
        this.transactionCompleted();
    }
    
    public void commit() throws SQLException {
        this.getActiveConnection().commit();
        this.transactionCompleted();
    }
    
    public void setAutoCommit(final boolean autoCommit) throws SQLException {
        this.autoCommit = autoCommit;
        for (final Connection c : this.serverConnections.values()) {
            c.setAutoCommit(this.autoCommit);
        }
    }
    
    public void transactionBegun() throws SQLException {
        if (!this.autoCommit) {
            this.transactionInProgress = true;
        }
    }
    
    public void transactionCompleted() throws SQLException {
        this.transactionInProgress = false;
        this.refreshStateIfNecessary();
    }
    
    public boolean getAutoCommit() {
        return this.autoCommit;
    }
    
    @Deprecated
    public MySQLConnection getLoadBalanceSafeProxy() {
        return this.getMultiHostSafeProxy();
    }
    
    public MySQLConnection getMultiHostSafeProxy() {
        return this.getActiveMySQLConnection();
    }
    
    public void setTransactionIsolation(final int level) throws SQLException {
        this.transactionIsolation = level;
        for (final Connection c : this.serverConnections.values()) {
            c.setTransactionIsolation(level);
        }
    }
    
    public void setTypeMap(final Map<String, Class<?>> map) throws SQLException {
        for (final Connection c : this.serverConnections.values()) {
            c.setTypeMap(map);
        }
    }
    
    public void setHoldability(final int holdability) throws SQLException {
        for (final Connection c : this.serverConnections.values()) {
            c.setHoldability(holdability);
        }
    }
    
    public void setProxy(final MySQLConnection proxy) {
    }
    
    public Savepoint setSavepoint() throws SQLException {
        return this.getActiveConnection().setSavepoint();
    }
    
    public Savepoint setSavepoint(final String name) throws SQLException {
        this.transactionInProgress = true;
        return this.getActiveConnection().setSavepoint(name);
    }
    
    public void releaseSavepoint(final Savepoint savepoint) {
    }
    
    public CallableStatement prepareCall(final String sql) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().prepareCall(sql);
    }
    
    public CallableStatement prepareCall(final String sql, final int resultSetType, final int resultSetConcurrency) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().prepareCall(sql, resultSetType, resultSetConcurrency);
    }
    
    public CallableStatement prepareCall(final String sql, final int resultSetType, final int resultSetConcurrency, final int resultSetHoldability) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().prepareCall(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
    }
    
    public PreparedStatement prepareStatement(final String sql) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().prepareStatement(sql);
    }
    
    public PreparedStatement prepareStatement(final String sql, final int autoGeneratedKeys) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().prepareStatement(sql, autoGeneratedKeys);
    }
    
    public PreparedStatement prepareStatement(final String sql, final int[] columnIndexes) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().prepareStatement(sql, columnIndexes);
    }
    
    public PreparedStatement prepareStatement(final String sql, final int resultSetType, final int resultSetConcurrency) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().prepareStatement(sql, resultSetType, resultSetConcurrency);
    }
    
    public PreparedStatement prepareStatement(final String sql, final int resultSetType, final int resultSetConcurrency, final int resultSetHoldability) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().prepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
    }
    
    public PreparedStatement prepareStatement(final String sql, final String[] columnNames) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().prepareStatement(sql, columnNames);
    }
    
    public PreparedStatement clientPrepareStatement(final String sql) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().clientPrepareStatement(sql);
    }
    
    public PreparedStatement clientPrepareStatement(final String sql, final int autoGenKeyIndex) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().clientPrepareStatement(sql, autoGenKeyIndex);
    }
    
    public PreparedStatement clientPrepareStatement(final String sql, final int resultSetType, final int resultSetConcurrency) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().clientPrepareStatement(sql, resultSetType, resultSetConcurrency);
    }
    
    public PreparedStatement clientPrepareStatement(final String sql, final int[] autoGenKeyIndexes) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().clientPrepareStatement(sql, autoGenKeyIndexes);
    }
    
    public PreparedStatement clientPrepareStatement(final String sql, final int resultSetType, final int resultSetConcurrency, final int resultSetHoldability) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().clientPrepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
    }
    
    public PreparedStatement clientPrepareStatement(final String sql, final String[] autoGenKeyColNames) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().clientPrepareStatement(sql, autoGenKeyColNames);
    }
    
    public PreparedStatement serverPrepareStatement(final String sql) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().serverPrepareStatement(sql);
    }
    
    public PreparedStatement serverPrepareStatement(final String sql, final int autoGenKeyIndex) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().serverPrepareStatement(sql, autoGenKeyIndex);
    }
    
    public PreparedStatement serverPrepareStatement(final String sql, final int resultSetType, final int resultSetConcurrency) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().serverPrepareStatement(sql, resultSetType, resultSetConcurrency);
    }
    
    public PreparedStatement serverPrepareStatement(final String sql, final int resultSetType, final int resultSetConcurrency, final int resultSetHoldability) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().serverPrepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
    }
    
    public PreparedStatement serverPrepareStatement(final String sql, final int[] autoGenKeyIndexes) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().serverPrepareStatement(sql, autoGenKeyIndexes);
    }
    
    public PreparedStatement serverPrepareStatement(final String sql, final String[] autoGenKeyColNames) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().serverPrepareStatement(sql, autoGenKeyColNames);
    }
    
    public Statement createStatement() throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().createStatement();
    }
    
    public Statement createStatement(final int resultSetType, final int resultSetConcurrency) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().createStatement(resultSetType, resultSetConcurrency);
    }
    
    public Statement createStatement(final int resultSetType, final int resultSetConcurrency, final int resultSetHoldability) throws SQLException {
        this.transactionBegun();
        return this.getActiveConnection().createStatement(resultSetType, resultSetConcurrency, resultSetHoldability);
    }
    
    public ResultSetInternalMethods execSQL(final StatementImpl callingStatement, final String sql, final int maxRows, final Buffer packet, final int resultSetType, final int resultSetConcurrency, final boolean streamResults, final String catalog, final Field[] cachedMetadata) throws SQLException {
        return this.getActiveMySQLConnectionChecked().execSQL(callingStatement, sql, maxRows, packet, resultSetType, resultSetConcurrency, streamResults, catalog, cachedMetadata);
    }
    
    public ResultSetInternalMethods execSQL(final StatementImpl callingStatement, final String sql, final int maxRows, final Buffer packet, final int resultSetType, final int resultSetConcurrency, final boolean streamResults, final String catalog, final Field[] cachedMetadata, final boolean isBatch) throws SQLException {
        return this.getActiveMySQLConnectionChecked().execSQL(callingStatement, sql, maxRows, packet, resultSetType, resultSetConcurrency, streamResults, catalog, cachedMetadata, isBatch);
    }
    
    public String extractSqlFromPacket(final String possibleSqlQuery, final Buffer queryPacket, final int endOfQueryPacketPosition) throws SQLException {
        return this.getActiveMySQLConnectionChecked().extractSqlFromPacket(possibleSqlQuery, queryPacket, endOfQueryPacketPosition);
    }
    
    public StringBuilder generateConnectionCommentBlock(final StringBuilder buf) {
        return this.getActiveMySQLConnection().generateConnectionCommentBlock(buf);
    }
    
    public MysqlIO getIO() throws SQLException {
        return this.getActiveMySQLConnectionChecked().getIO();
    }
    
    public Calendar getCalendarInstanceForSessionOrNew() {
        return this.getActiveMySQLConnection().getCalendarInstanceForSessionOrNew();
    }
    
    @Deprecated
    public String getServerCharacterEncoding() {
        return this.getServerCharset();
    }
    
    public String getServerCharset() {
        return this.getActiveMySQLConnection().getServerCharset();
    }
    
    public TimeZone getServerTimezoneTZ() {
        return this.getActiveMySQLConnection().getServerTimezoneTZ();
    }
    
    public boolean versionMeetsMinimum(final int major, final int minor, final int subminor) throws SQLException {
        return this.getActiveConnection().versionMeetsMinimum(major, minor, subminor);
    }
    
    public boolean supportsIsolationLevel() {
        return this.getActiveConnectionPassive().supportsIsolationLevel();
    }
    
    public boolean supportsQuotedIdentifiers() {
        return this.getActiveConnectionPassive().supportsQuotedIdentifiers();
    }
    
    public DatabaseMetaData getMetaData() throws SQLException {
        return this.getActiveConnection().getMetaData();
    }
    
    public String getCharacterSetMetadata() {
        return this.getActiveMySQLConnection().getCharacterSetMetadata();
    }
    
    public Statement getMetadataSafeStatement() throws SQLException {
        return this.getActiveMySQLConnectionChecked().getMetadataSafeStatement();
    }
    
    public boolean isWrapperFor(final Class<?> iface) {
        return false;
    }
    
    public <T> T unwrap(final Class<T> iface) {
        return null;
    }
    
    public void unSafeStatementInterceptors() throws SQLException {
    }
    
    public boolean supportsTransactions() {
        return true;
    }
    
    public boolean isRunningOnJDK13() {
        return false;
    }
    
    public void createNewIO(final boolean isForReconnect) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException();
    }
    
    public void dumpTestcaseQuery(final String query) {
    }
    
    public void abortInternal() throws SQLException {
    }
    
    public boolean isServerLocal() throws SQLException {
        return false;
    }
    
    public void shutdownServer() throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException();
    }
    
    @Deprecated
    public void clearHasTriedMaster() {
    }
    
    @Deprecated
    public boolean hasTriedMaster() {
        return false;
    }
    
    public boolean isInGlobalTx() {
        return false;
    }
    
    public void setInGlobalTx(final boolean flag) {
        throw new RuntimeException("Global transactions not supported.");
    }
    
    public void changeUser(final String userName, final String newPassword) throws SQLException {
        throw SQLError.createSQLException("User change not allowed.", this.getExceptionInterceptor());
    }
    
    public void setFabricShardKey(final String value) {
        this.fabricShardKey = value;
    }
    
    public String getFabricShardKey() {
        return this.fabricShardKey;
    }
    
    public void setFabricShardTable(final String value) {
        this.fabricShardTable = value;
    }
    
    public String getFabricShardTable() {
        return this.fabricShardTable;
    }
    
    public void setFabricServerGroup(final String value) {
        this.fabricServerGroup = value;
    }
    
    public String getFabricServerGroup() {
        return this.fabricServerGroup;
    }
    
    public void setFabricProtocol(final String value) {
        this.fabricProtocol = value;
    }
    
    public String getFabricProtocol() {
        return this.fabricProtocol;
    }
    
    public void setFabricUsername(final String value) {
        this.fabricUsername = value;
    }
    
    public String getFabricUsername() {
        return this.fabricUsername;
    }
    
    public void setFabricPassword(final String value) {
        this.fabricPassword = value;
    }
    
    public String getFabricPassword() {
        return this.fabricPassword;
    }
    
    public void setFabricReportErrors(final boolean value) {
        this.reportErrors = value;
    }
    
    public boolean getFabricReportErrors() {
        return this.reportErrors;
    }
    
    @Override
    public void setAllowLoadLocalInfile(final boolean property) {
        super.setAllowLoadLocalInfile(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setAllowLoadLocalInfile(property);
        }
    }
    
    @Override
    public void setAllowMultiQueries(final boolean property) {
        super.setAllowMultiQueries(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setAllowMultiQueries(property);
        }
    }
    
    @Override
    public void setAllowNanAndInf(final boolean flag) {
        super.setAllowNanAndInf(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setAllowNanAndInf(flag);
        }
    }
    
    @Override
    public void setAllowUrlInLocalInfile(final boolean flag) {
        super.setAllowUrlInLocalInfile(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setAllowUrlInLocalInfile(flag);
        }
    }
    
    @Override
    public void setAlwaysSendSetIsolation(final boolean flag) {
        super.setAlwaysSendSetIsolation(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setAlwaysSendSetIsolation(flag);
        }
    }
    
    @Override
    public void setAutoDeserialize(final boolean flag) {
        super.setAutoDeserialize(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setAutoDeserialize(flag);
        }
    }
    
    @Override
    public void setAutoGenerateTestcaseScript(final boolean flag) {
        super.setAutoGenerateTestcaseScript(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setAutoGenerateTestcaseScript(flag);
        }
    }
    
    @Override
    public void setAutoReconnect(final boolean flag) {
        super.setAutoReconnect(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setAutoReconnect(flag);
        }
    }
    
    @Override
    public void setAutoReconnectForConnectionPools(final boolean property) {
        super.setAutoReconnectForConnectionPools(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setAutoReconnectForConnectionPools(property);
        }
    }
    
    @Override
    public void setAutoReconnectForPools(final boolean flag) {
        super.setAutoReconnectForPools(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setAutoReconnectForPools(flag);
        }
    }
    
    @Override
    public void setBlobSendChunkSize(final String value) throws SQLException {
        super.setBlobSendChunkSize(value);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setBlobSendChunkSize(value);
        }
    }
    
    @Override
    public void setCacheCallableStatements(final boolean flag) {
        super.setCacheCallableStatements(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setCacheCallableStatements(flag);
        }
    }
    
    @Override
    public void setCachePreparedStatements(final boolean flag) {
        super.setCachePreparedStatements(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setCachePreparedStatements(flag);
        }
    }
    
    @Override
    public void setCacheResultSetMetadata(final boolean property) {
        super.setCacheResultSetMetadata(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setCacheResultSetMetadata(property);
        }
    }
    
    @Override
    public void setCacheServerConfiguration(final boolean flag) {
        super.setCacheServerConfiguration(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setCacheServerConfiguration(flag);
        }
    }
    
    @Override
    public void setCallableStatementCacheSize(final int size) throws SQLException {
        super.setCallableStatementCacheSize(size);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setCallableStatementCacheSize(size);
        }
    }
    
    @Override
    public void setCapitalizeDBMDTypes(final boolean property) {
        super.setCapitalizeDBMDTypes(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setCapitalizeDBMDTypes(property);
        }
    }
    
    @Override
    public void setCapitalizeTypeNames(final boolean flag) {
        super.setCapitalizeTypeNames(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setCapitalizeTypeNames(flag);
        }
    }
    
    @Override
    public void setCharacterEncoding(final String encoding) {
        super.setCharacterEncoding(encoding);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setCharacterEncoding(encoding);
        }
    }
    
    @Override
    public void setCharacterSetResults(final String characterSet) {
        super.setCharacterSetResults(characterSet);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setCharacterSetResults(characterSet);
        }
    }
    
    @Override
    public void setClobberStreamingResults(final boolean flag) {
        super.setClobberStreamingResults(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setClobberStreamingResults(flag);
        }
    }
    
    @Override
    public void setClobCharacterEncoding(final String encoding) {
        super.setClobCharacterEncoding(encoding);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setClobCharacterEncoding(encoding);
        }
    }
    
    @Override
    public void setConnectionCollation(final String collation) {
        super.setConnectionCollation(collation);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setConnectionCollation(collation);
        }
    }
    
    @Override
    public void setConnectTimeout(final int timeoutMs) throws SQLException {
        super.setConnectTimeout(timeoutMs);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setConnectTimeout(timeoutMs);
        }
    }
    
    @Override
    public void setContinueBatchOnError(final boolean property) {
        super.setContinueBatchOnError(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setContinueBatchOnError(property);
        }
    }
    
    @Override
    public void setCreateDatabaseIfNotExist(final boolean flag) {
        super.setCreateDatabaseIfNotExist(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setCreateDatabaseIfNotExist(flag);
        }
    }
    
    @Override
    public void setDefaultFetchSize(final int n) throws SQLException {
        super.setDefaultFetchSize(n);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setDefaultFetchSize(n);
        }
    }
    
    @Override
    public void setDetectServerPreparedStmts(final boolean property) {
        super.setDetectServerPreparedStmts(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setDetectServerPreparedStmts(property);
        }
    }
    
    @Override
    public void setDontTrackOpenResources(final boolean flag) {
        super.setDontTrackOpenResources(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setDontTrackOpenResources(flag);
        }
    }
    
    @Override
    public void setDumpQueriesOnException(final boolean flag) {
        super.setDumpQueriesOnException(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setDumpQueriesOnException(flag);
        }
    }
    
    @Override
    public void setDynamicCalendars(final boolean flag) {
        super.setDynamicCalendars(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setDynamicCalendars(flag);
        }
    }
    
    @Override
    public void setElideSetAutoCommits(final boolean flag) {
        super.setElideSetAutoCommits(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setElideSetAutoCommits(flag);
        }
    }
    
    @Override
    public void setEmptyStringsConvertToZero(final boolean flag) {
        super.setEmptyStringsConvertToZero(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setEmptyStringsConvertToZero(flag);
        }
    }
    
    @Override
    public void setEmulateLocators(final boolean property) {
        super.setEmulateLocators(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setEmulateLocators(property);
        }
    }
    
    @Override
    public void setEmulateUnsupportedPstmts(final boolean flag) {
        super.setEmulateUnsupportedPstmts(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setEmulateUnsupportedPstmts(flag);
        }
    }
    
    @Override
    public void setEnablePacketDebug(final boolean flag) {
        super.setEnablePacketDebug(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setEnablePacketDebug(flag);
        }
    }
    
    @Override
    public void setEncoding(final String property) {
        super.setEncoding(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setEncoding(property);
        }
    }
    
    @Override
    public void setExplainSlowQueries(final boolean flag) {
        super.setExplainSlowQueries(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setExplainSlowQueries(flag);
        }
    }
    
    @Override
    public void setFailOverReadOnly(final boolean flag) {
        super.setFailOverReadOnly(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setFailOverReadOnly(flag);
        }
    }
    
    @Override
    public void setGatherPerformanceMetrics(final boolean flag) {
        super.setGatherPerformanceMetrics(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setGatherPerformanceMetrics(flag);
        }
    }
    
    @Override
    public void setHoldResultsOpenOverStatementClose(final boolean flag) {
        super.setHoldResultsOpenOverStatementClose(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setHoldResultsOpenOverStatementClose(flag);
        }
    }
    
    @Override
    public void setIgnoreNonTxTables(final boolean property) {
        super.setIgnoreNonTxTables(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setIgnoreNonTxTables(property);
        }
    }
    
    @Override
    public void setInitialTimeout(final int property) throws SQLException {
        super.setInitialTimeout(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setInitialTimeout(property);
        }
    }
    
    @Override
    public void setIsInteractiveClient(final boolean property) {
        super.setIsInteractiveClient(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setIsInteractiveClient(property);
        }
    }
    
    @Override
    public void setJdbcCompliantTruncation(final boolean flag) {
        super.setJdbcCompliantTruncation(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setJdbcCompliantTruncation(flag);
        }
    }
    
    @Override
    public void setLocatorFetchBufferSize(final String value) throws SQLException {
        super.setLocatorFetchBufferSize(value);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setLocatorFetchBufferSize(value);
        }
    }
    
    @Override
    public void setLogger(final String property) {
        super.setLogger(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setLogger(property);
        }
    }
    
    @Override
    public void setLoggerClassName(final String className) {
        super.setLoggerClassName(className);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setLoggerClassName(className);
        }
    }
    
    @Override
    public void setLogSlowQueries(final boolean flag) {
        super.setLogSlowQueries(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setLogSlowQueries(flag);
        }
    }
    
    @Override
    public void setMaintainTimeStats(final boolean flag) {
        super.setMaintainTimeStats(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setMaintainTimeStats(flag);
        }
    }
    
    @Override
    public void setMaxQuerySizeToLog(final int sizeInBytes) throws SQLException {
        super.setMaxQuerySizeToLog(sizeInBytes);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setMaxQuerySizeToLog(sizeInBytes);
        }
    }
    
    @Override
    public void setMaxReconnects(final int property) throws SQLException {
        super.setMaxReconnects(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setMaxReconnects(property);
        }
    }
    
    @Override
    public void setMaxRows(final int property) throws SQLException {
        super.setMaxRows(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setMaxRows(property);
        }
    }
    
    @Override
    public void setMetadataCacheSize(final int value) throws SQLException {
        super.setMetadataCacheSize(value);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setMetadataCacheSize(value);
        }
    }
    
    @Override
    public void setNoDatetimeStringSync(final boolean flag) {
        super.setNoDatetimeStringSync(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setNoDatetimeStringSync(flag);
        }
    }
    
    @Override
    public void setNullCatalogMeansCurrent(final boolean value) {
        super.setNullCatalogMeansCurrent(value);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setNullCatalogMeansCurrent(value);
        }
    }
    
    @Override
    public void setNullNamePatternMatchesAll(final boolean value) {
        super.setNullNamePatternMatchesAll(value);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setNullNamePatternMatchesAll(value);
        }
    }
    
    @Override
    public void setPacketDebugBufferSize(final int size) throws SQLException {
        super.setPacketDebugBufferSize(size);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setPacketDebugBufferSize(size);
        }
    }
    
    @Override
    public void setParanoid(final boolean property) {
        super.setParanoid(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setParanoid(property);
        }
    }
    
    @Override
    public void setPedantic(final boolean property) {
        super.setPedantic(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setPedantic(property);
        }
    }
    
    @Override
    public void setPreparedStatementCacheSize(final int cacheSize) throws SQLException {
        super.setPreparedStatementCacheSize(cacheSize);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setPreparedStatementCacheSize(cacheSize);
        }
    }
    
    @Override
    public void setPreparedStatementCacheSqlLimit(final int cacheSqlLimit) throws SQLException {
        super.setPreparedStatementCacheSqlLimit(cacheSqlLimit);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setPreparedStatementCacheSqlLimit(cacheSqlLimit);
        }
    }
    
    @Override
    public void setProfileSql(final boolean property) {
        super.setProfileSql(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setProfileSql(property);
        }
    }
    
    @Override
    public void setProfileSQL(final boolean flag) {
        super.setProfileSQL(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setProfileSQL(flag);
        }
    }
    
    @Override
    public void setPropertiesTransform(final String value) {
        super.setPropertiesTransform(value);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setPropertiesTransform(value);
        }
    }
    
    @Override
    public void setQueriesBeforeRetryMaster(final int property) throws SQLException {
        super.setQueriesBeforeRetryMaster(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setQueriesBeforeRetryMaster(property);
        }
    }
    
    @Override
    public void setReconnectAtTxEnd(final boolean property) {
        super.setReconnectAtTxEnd(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setReconnectAtTxEnd(property);
        }
    }
    
    @Override
    public void setRelaxAutoCommit(final boolean property) {
        super.setRelaxAutoCommit(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setRelaxAutoCommit(property);
        }
    }
    
    @Override
    public void setReportMetricsIntervalMillis(final int millis) throws SQLException {
        super.setReportMetricsIntervalMillis(millis);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setReportMetricsIntervalMillis(millis);
        }
    }
    
    @Override
    public void setRequireSSL(final boolean property) {
        super.setRequireSSL(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setRequireSSL(property);
        }
    }
    
    @Override
    public void setRetainStatementAfterResultSetClose(final boolean flag) {
        super.setRetainStatementAfterResultSetClose(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setRetainStatementAfterResultSetClose(flag);
        }
    }
    
    @Override
    public void setRollbackOnPooledClose(final boolean flag) {
        super.setRollbackOnPooledClose(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setRollbackOnPooledClose(flag);
        }
    }
    
    @Override
    public void setRoundRobinLoadBalance(final boolean flag) {
        super.setRoundRobinLoadBalance(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setRoundRobinLoadBalance(flag);
        }
    }
    
    @Override
    public void setRunningCTS13(final boolean flag) {
        super.setRunningCTS13(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setRunningCTS13(flag);
        }
    }
    
    @Override
    public void setSecondsBeforeRetryMaster(final int property) throws SQLException {
        super.setSecondsBeforeRetryMaster(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setSecondsBeforeRetryMaster(property);
        }
    }
    
    @Override
    public void setServerTimezone(final String property) {
        super.setServerTimezone(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setServerTimezone(property);
        }
    }
    
    @Override
    public void setSessionVariables(final String variables) {
        super.setSessionVariables(variables);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setSessionVariables(variables);
        }
    }
    
    @Override
    public void setSlowQueryThresholdMillis(final int millis) throws SQLException {
        super.setSlowQueryThresholdMillis(millis);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setSlowQueryThresholdMillis(millis);
        }
    }
    
    @Override
    public void setSocketFactoryClassName(final String property) {
        super.setSocketFactoryClassName(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setSocketFactoryClassName(property);
        }
    }
    
    @Override
    public void setSocketTimeout(final int property) throws SQLException {
        super.setSocketTimeout(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setSocketTimeout(property);
        }
    }
    
    @Override
    public void setStrictFloatingPoint(final boolean property) {
        super.setStrictFloatingPoint(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setStrictFloatingPoint(property);
        }
    }
    
    @Override
    public void setStrictUpdates(final boolean property) {
        super.setStrictUpdates(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setStrictUpdates(property);
        }
    }
    
    @Override
    public void setTinyInt1isBit(final boolean flag) {
        super.setTinyInt1isBit(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setTinyInt1isBit(flag);
        }
    }
    
    @Override
    public void setTraceProtocol(final boolean flag) {
        super.setTraceProtocol(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setTraceProtocol(flag);
        }
    }
    
    @Override
    public void setTransformedBitIsBoolean(final boolean flag) {
        super.setTransformedBitIsBoolean(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setTransformedBitIsBoolean(flag);
        }
    }
    
    @Override
    public void setUseCompression(final boolean property) {
        super.setUseCompression(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseCompression(property);
        }
    }
    
    @Override
    public void setUseFastIntParsing(final boolean flag) {
        super.setUseFastIntParsing(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseFastIntParsing(flag);
        }
    }
    
    @Override
    public void setUseHostsInPrivileges(final boolean property) {
        super.setUseHostsInPrivileges(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseHostsInPrivileges(property);
        }
    }
    
    @Override
    public void setUseInformationSchema(final boolean flag) {
        super.setUseInformationSchema(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseInformationSchema(flag);
        }
    }
    
    @Override
    public void setUseLocalSessionState(final boolean flag) {
        super.setUseLocalSessionState(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseLocalSessionState(flag);
        }
    }
    
    @Override
    public void setUseOldUTF8Behavior(final boolean flag) {
        super.setUseOldUTF8Behavior(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseOldUTF8Behavior(flag);
        }
    }
    
    @Override
    public void setUseOnlyServerErrorMessages(final boolean flag) {
        super.setUseOnlyServerErrorMessages(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseOnlyServerErrorMessages(flag);
        }
    }
    
    @Override
    public void setUseReadAheadInput(final boolean flag) {
        super.setUseReadAheadInput(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseReadAheadInput(flag);
        }
    }
    
    @Override
    public void setUseServerPreparedStmts(final boolean flag) {
        super.setUseServerPreparedStmts(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseServerPreparedStmts(flag);
        }
    }
    
    @Override
    public void setUseSqlStateCodes(final boolean flag) {
        super.setUseSqlStateCodes(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseSqlStateCodes(flag);
        }
    }
    
    @Override
    public void setUseSSL(final boolean property) {
        super.setUseSSL(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseSSL(property);
        }
    }
    
    @Override
    public void setUseStreamLengthsInPrepStmts(final boolean property) {
        super.setUseStreamLengthsInPrepStmts(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseStreamLengthsInPrepStmts(property);
        }
    }
    
    @Override
    public void setUseTimezone(final boolean property) {
        super.setUseTimezone(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseTimezone(property);
        }
    }
    
    @Override
    public void setUseUltraDevWorkAround(final boolean property) {
        super.setUseUltraDevWorkAround(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseUltraDevWorkAround(property);
        }
    }
    
    @Override
    public void setUseUnbufferedInput(final boolean flag) {
        super.setUseUnbufferedInput(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseUnbufferedInput(flag);
        }
    }
    
    @Override
    public void setUseUnicode(final boolean flag) {
        super.setUseUnicode(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseUnicode(flag);
        }
    }
    
    @Override
    public void setUseUsageAdvisor(final boolean useUsageAdvisorFlag) {
        super.setUseUsageAdvisor(useUsageAdvisorFlag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseUsageAdvisor(useUsageAdvisorFlag);
        }
    }
    
    @Override
    public void setYearIsDateType(final boolean flag) {
        super.setYearIsDateType(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setYearIsDateType(flag);
        }
    }
    
    @Override
    public void setZeroDateTimeBehavior(final String behavior) {
        super.setZeroDateTimeBehavior(behavior);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setZeroDateTimeBehavior(behavior);
        }
    }
    
    @Override
    public void setUseCursorFetch(final boolean flag) {
        super.setUseCursorFetch(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseCursorFetch(flag);
        }
    }
    
    @Override
    public void setOverrideSupportsIntegrityEnhancementFacility(final boolean flag) {
        super.setOverrideSupportsIntegrityEnhancementFacility(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setOverrideSupportsIntegrityEnhancementFacility(flag);
        }
    }
    
    @Override
    public void setNoTimezoneConversionForTimeType(final boolean flag) {
        super.setNoTimezoneConversionForTimeType(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setNoTimezoneConversionForTimeType(flag);
        }
    }
    
    @Override
    public void setUseJDBCCompliantTimezoneShift(final boolean flag) {
        super.setUseJDBCCompliantTimezoneShift(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseJDBCCompliantTimezoneShift(flag);
        }
    }
    
    @Override
    public void setAutoClosePStmtStreams(final boolean flag) {
        super.setAutoClosePStmtStreams(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setAutoClosePStmtStreams(flag);
        }
    }
    
    @Override
    public void setProcessEscapeCodesForPrepStmts(final boolean flag) {
        super.setProcessEscapeCodesForPrepStmts(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setProcessEscapeCodesForPrepStmts(flag);
        }
    }
    
    @Override
    public void setUseGmtMillisForDatetimes(final boolean flag) {
        super.setUseGmtMillisForDatetimes(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseGmtMillisForDatetimes(flag);
        }
    }
    
    @Override
    public void setDumpMetadataOnColumnNotFound(final boolean flag) {
        super.setDumpMetadataOnColumnNotFound(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setDumpMetadataOnColumnNotFound(flag);
        }
    }
    
    @Override
    public void setResourceId(final String resourceId) {
        super.setResourceId(resourceId);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setResourceId(resourceId);
        }
    }
    
    @Override
    public void setRewriteBatchedStatements(final boolean flag) {
        super.setRewriteBatchedStatements(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setRewriteBatchedStatements(flag);
        }
    }
    
    @Override
    public void setJdbcCompliantTruncationForReads(final boolean jdbcCompliantTruncationForReads) {
        super.setJdbcCompliantTruncationForReads(jdbcCompliantTruncationForReads);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setJdbcCompliantTruncationForReads(jdbcCompliantTruncationForReads);
        }
    }
    
    @Override
    public void setUseJvmCharsetConverters(final boolean flag) {
        super.setUseJvmCharsetConverters(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseJvmCharsetConverters(flag);
        }
    }
    
    @Override
    public void setPinGlobalTxToPhysicalConnection(final boolean flag) {
        super.setPinGlobalTxToPhysicalConnection(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setPinGlobalTxToPhysicalConnection(flag);
        }
    }
    
    @Override
    public void setGatherPerfMetrics(final boolean flag) {
        super.setGatherPerfMetrics(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setGatherPerfMetrics(flag);
        }
    }
    
    @Override
    public void setUltraDevHack(final boolean flag) {
        super.setUltraDevHack(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUltraDevHack(flag);
        }
    }
    
    @Override
    public void setInteractiveClient(final boolean property) {
        super.setInteractiveClient(property);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setInteractiveClient(property);
        }
    }
    
    @Override
    public void setSocketFactory(final String name) {
        super.setSocketFactory(name);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setSocketFactory(name);
        }
    }
    
    @Override
    public void setUseServerPrepStmts(final boolean flag) {
        super.setUseServerPrepStmts(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseServerPrepStmts(flag);
        }
    }
    
    @Override
    public void setCacheCallableStmts(final boolean flag) {
        super.setCacheCallableStmts(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setCacheCallableStmts(flag);
        }
    }
    
    @Override
    public void setCachePrepStmts(final boolean flag) {
        super.setCachePrepStmts(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setCachePrepStmts(flag);
        }
    }
    
    @Override
    public void setCallableStmtCacheSize(final int cacheSize) throws SQLException {
        super.setCallableStmtCacheSize(cacheSize);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setCallableStmtCacheSize(cacheSize);
        }
    }
    
    @Override
    public void setPrepStmtCacheSize(final int cacheSize) throws SQLException {
        super.setPrepStmtCacheSize(cacheSize);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setPrepStmtCacheSize(cacheSize);
        }
    }
    
    @Override
    public void setPrepStmtCacheSqlLimit(final int sqlLimit) throws SQLException {
        super.setPrepStmtCacheSqlLimit(sqlLimit);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setPrepStmtCacheSqlLimit(sqlLimit);
        }
    }
    
    @Override
    public void setNoAccessToProcedureBodies(final boolean flag) {
        super.setNoAccessToProcedureBodies(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setNoAccessToProcedureBodies(flag);
        }
    }
    
    @Override
    public void setUseOldAliasMetadataBehavior(final boolean flag) {
        super.setUseOldAliasMetadataBehavior(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseOldAliasMetadataBehavior(flag);
        }
    }
    
    @Override
    public void setClientCertificateKeyStorePassword(final String value) {
        super.setClientCertificateKeyStorePassword(value);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setClientCertificateKeyStorePassword(value);
        }
    }
    
    @Override
    public void setClientCertificateKeyStoreType(final String value) {
        super.setClientCertificateKeyStoreType(value);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setClientCertificateKeyStoreType(value);
        }
    }
    
    @Override
    public void setClientCertificateKeyStoreUrl(final String value) {
        super.setClientCertificateKeyStoreUrl(value);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setClientCertificateKeyStoreUrl(value);
        }
    }
    
    @Override
    public void setTrustCertificateKeyStorePassword(final String value) {
        super.setTrustCertificateKeyStorePassword(value);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setTrustCertificateKeyStorePassword(value);
        }
    }
    
    @Override
    public void setTrustCertificateKeyStoreType(final String value) {
        super.setTrustCertificateKeyStoreType(value);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setTrustCertificateKeyStoreType(value);
        }
    }
    
    @Override
    public void setTrustCertificateKeyStoreUrl(final String value) {
        super.setTrustCertificateKeyStoreUrl(value);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setTrustCertificateKeyStoreUrl(value);
        }
    }
    
    @Override
    public void setUseSSPSCompatibleTimezoneShift(final boolean flag) {
        super.setUseSSPSCompatibleTimezoneShift(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseSSPSCompatibleTimezoneShift(flag);
        }
    }
    
    @Override
    public void setTreatUtilDateAsTimestamp(final boolean flag) {
        super.setTreatUtilDateAsTimestamp(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setTreatUtilDateAsTimestamp(flag);
        }
    }
    
    @Override
    public void setUseFastDateParsing(final boolean flag) {
        super.setUseFastDateParsing(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseFastDateParsing(flag);
        }
    }
    
    @Override
    public void setLocalSocketAddress(final String address) {
        super.setLocalSocketAddress(address);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setLocalSocketAddress(address);
        }
    }
    
    @Override
    public void setUseConfigs(final String configs) {
        super.setUseConfigs(configs);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseConfigs(configs);
        }
    }
    
    @Override
    public void setGenerateSimpleParameterMetadata(final boolean flag) {
        super.setGenerateSimpleParameterMetadata(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setGenerateSimpleParameterMetadata(flag);
        }
    }
    
    @Override
    public void setLogXaCommands(final boolean flag) {
        super.setLogXaCommands(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setLogXaCommands(flag);
        }
    }
    
    @Override
    public void setResultSetSizeThreshold(final int threshold) throws SQLException {
        super.setResultSetSizeThreshold(threshold);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setResultSetSizeThreshold(threshold);
        }
    }
    
    @Override
    public void setNetTimeoutForStreamingResults(final int value) throws SQLException {
        super.setNetTimeoutForStreamingResults(value);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setNetTimeoutForStreamingResults(value);
        }
    }
    
    @Override
    public void setEnableQueryTimeouts(final boolean flag) {
        super.setEnableQueryTimeouts(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setEnableQueryTimeouts(flag);
        }
    }
    
    @Override
    public void setPadCharsWithSpace(final boolean flag) {
        super.setPadCharsWithSpace(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setPadCharsWithSpace(flag);
        }
    }
    
    @Override
    public void setUseDynamicCharsetInfo(final boolean flag) {
        super.setUseDynamicCharsetInfo(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseDynamicCharsetInfo(flag);
        }
    }
    
    @Override
    public void setClientInfoProvider(final String classname) {
        super.setClientInfoProvider(classname);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setClientInfoProvider(classname);
        }
    }
    
    @Override
    public void setPopulateInsertRowWithDefaultValues(final boolean flag) {
        super.setPopulateInsertRowWithDefaultValues(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setPopulateInsertRowWithDefaultValues(flag);
        }
    }
    
    @Override
    public void setLoadBalanceStrategy(final String strategy) {
        super.setLoadBalanceStrategy(strategy);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setLoadBalanceStrategy(strategy);
        }
    }
    
    @Override
    public void setTcpNoDelay(final boolean flag) {
        super.setTcpNoDelay(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setTcpNoDelay(flag);
        }
    }
    
    @Override
    public void setTcpKeepAlive(final boolean flag) {
        super.setTcpKeepAlive(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setTcpKeepAlive(flag);
        }
    }
    
    @Override
    public void setTcpRcvBuf(final int bufSize) throws SQLException {
        super.setTcpRcvBuf(bufSize);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setTcpRcvBuf(bufSize);
        }
    }
    
    @Override
    public void setTcpSndBuf(final int bufSize) throws SQLException {
        super.setTcpSndBuf(bufSize);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setTcpSndBuf(bufSize);
        }
    }
    
    @Override
    public void setTcpTrafficClass(final int classFlags) throws SQLException {
        super.setTcpTrafficClass(classFlags);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setTcpTrafficClass(classFlags);
        }
    }
    
    @Override
    public void setUseNanosForElapsedTime(final boolean flag) {
        super.setUseNanosForElapsedTime(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseNanosForElapsedTime(flag);
        }
    }
    
    @Override
    public void setSlowQueryThresholdNanos(final long nanos) throws SQLException {
        super.setSlowQueryThresholdNanos(nanos);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setSlowQueryThresholdNanos(nanos);
        }
    }
    
    @Override
    public void setStatementInterceptors(final String value) {
        super.setStatementInterceptors(value);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setStatementInterceptors(value);
        }
    }
    
    @Override
    public void setUseDirectRowUnpack(final boolean flag) {
        super.setUseDirectRowUnpack(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseDirectRowUnpack(flag);
        }
    }
    
    @Override
    public void setLargeRowSizeThreshold(final String value) throws SQLException {
        super.setLargeRowSizeThreshold(value);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setLargeRowSizeThreshold(value);
        }
    }
    
    @Override
    public void setUseBlobToStoreUTF8OutsideBMP(final boolean flag) {
        super.setUseBlobToStoreUTF8OutsideBMP(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseBlobToStoreUTF8OutsideBMP(flag);
        }
    }
    
    @Override
    public void setUtf8OutsideBmpExcludedColumnNamePattern(final String regexPattern) {
        super.setUtf8OutsideBmpExcludedColumnNamePattern(regexPattern);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUtf8OutsideBmpExcludedColumnNamePattern(regexPattern);
        }
    }
    
    @Override
    public void setUtf8OutsideBmpIncludedColumnNamePattern(final String regexPattern) {
        super.setUtf8OutsideBmpIncludedColumnNamePattern(regexPattern);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUtf8OutsideBmpIncludedColumnNamePattern(regexPattern);
        }
    }
    
    @Override
    public void setIncludeInnodbStatusInDeadlockExceptions(final boolean flag) {
        super.setIncludeInnodbStatusInDeadlockExceptions(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setIncludeInnodbStatusInDeadlockExceptions(flag);
        }
    }
    
    @Override
    public void setIncludeThreadDumpInDeadlockExceptions(final boolean flag) {
        super.setIncludeThreadDumpInDeadlockExceptions(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setIncludeThreadDumpInDeadlockExceptions(flag);
        }
    }
    
    @Override
    public void setIncludeThreadNamesAsStatementComment(final boolean flag) {
        super.setIncludeThreadNamesAsStatementComment(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setIncludeThreadNamesAsStatementComment(flag);
        }
    }
    
    @Override
    public void setBlobsAreStrings(final boolean flag) {
        super.setBlobsAreStrings(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setBlobsAreStrings(flag);
        }
    }
    
    @Override
    public void setFunctionsNeverReturnBlobs(final boolean flag) {
        super.setFunctionsNeverReturnBlobs(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setFunctionsNeverReturnBlobs(flag);
        }
    }
    
    @Override
    public void setAutoSlowLog(final boolean flag) {
        super.setAutoSlowLog(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setAutoSlowLog(flag);
        }
    }
    
    @Override
    public void setConnectionLifecycleInterceptors(final String interceptors) {
        super.setConnectionLifecycleInterceptors(interceptors);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setConnectionLifecycleInterceptors(interceptors);
        }
    }
    
    @Override
    public void setProfilerEventHandler(final String handler) {
        super.setProfilerEventHandler(handler);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setProfilerEventHandler(handler);
        }
    }
    
    @Override
    public void setVerifyServerCertificate(final boolean flag) {
        super.setVerifyServerCertificate(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setVerifyServerCertificate(flag);
        }
    }
    
    @Override
    public void setUseLegacyDatetimeCode(final boolean flag) {
        super.setUseLegacyDatetimeCode(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseLegacyDatetimeCode(flag);
        }
    }
    
    @Override
    public void setSelfDestructOnPingSecondsLifetime(final int seconds) throws SQLException {
        super.setSelfDestructOnPingSecondsLifetime(seconds);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setSelfDestructOnPingSecondsLifetime(seconds);
        }
    }
    
    @Override
    public void setSelfDestructOnPingMaxOperations(final int maxOperations) throws SQLException {
        super.setSelfDestructOnPingMaxOperations(maxOperations);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setSelfDestructOnPingMaxOperations(maxOperations);
        }
    }
    
    @Override
    public void setUseColumnNamesInFindColumn(final boolean flag) {
        super.setUseColumnNamesInFindColumn(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseColumnNamesInFindColumn(flag);
        }
    }
    
    @Override
    public void setUseLocalTransactionState(final boolean flag) {
        super.setUseLocalTransactionState(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseLocalTransactionState(flag);
        }
    }
    
    @Override
    public void setCompensateOnDuplicateKeyUpdateCounts(final boolean flag) {
        super.setCompensateOnDuplicateKeyUpdateCounts(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setCompensateOnDuplicateKeyUpdateCounts(flag);
        }
    }
    
    @Override
    public void setUseAffectedRows(final boolean flag) {
        super.setUseAffectedRows(flag);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setUseAffectedRows(flag);
        }
    }
    
    @Override
    public void setPasswordCharacterEncoding(final String characterSet) {
        super.setPasswordCharacterEncoding(characterSet);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setPasswordCharacterEncoding(characterSet);
        }
    }
    
    @Override
    public void setLoadBalanceBlacklistTimeout(final int loadBalanceBlacklistTimeout) throws SQLException {
        super.setLoadBalanceBlacklistTimeout(loadBalanceBlacklistTimeout);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setLoadBalanceBlacklistTimeout(loadBalanceBlacklistTimeout);
        }
    }
    
    @Override
    public void setRetriesAllDown(final int retriesAllDown) throws SQLException {
        super.setRetriesAllDown(retriesAllDown);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setRetriesAllDown(retriesAllDown);
        }
    }
    
    @Override
    public void setExceptionInterceptors(final String exceptionInterceptors) {
        super.setExceptionInterceptors(exceptionInterceptors);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setExceptionInterceptors(exceptionInterceptors);
        }
    }
    
    @Override
    public void setQueryTimeoutKillsConnection(final boolean queryTimeoutKillsConnection) {
        super.setQueryTimeoutKillsConnection(queryTimeoutKillsConnection);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setQueryTimeoutKillsConnection(queryTimeoutKillsConnection);
        }
    }
    
    @Override
    public void setLoadBalancePingTimeout(final int loadBalancePingTimeout) throws SQLException {
        super.setLoadBalancePingTimeout(loadBalancePingTimeout);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setLoadBalancePingTimeout(loadBalancePingTimeout);
        }
    }
    
    @Override
    public void setLoadBalanceValidateConnectionOnSwapServer(final boolean loadBalanceValidateConnectionOnSwapServer) {
        super.setLoadBalanceValidateConnectionOnSwapServer(loadBalanceValidateConnectionOnSwapServer);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setLoadBalanceValidateConnectionOnSwapServer(loadBalanceValidateConnectionOnSwapServer);
        }
    }
    
    @Override
    public void setLoadBalanceConnectionGroup(final String loadBalanceConnectionGroup) {
        super.setLoadBalanceConnectionGroup(loadBalanceConnectionGroup);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setLoadBalanceConnectionGroup(loadBalanceConnectionGroup);
        }
    }
    
    @Override
    public void setLoadBalanceExceptionChecker(final String loadBalanceExceptionChecker) {
        super.setLoadBalanceExceptionChecker(loadBalanceExceptionChecker);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setLoadBalanceExceptionChecker(loadBalanceExceptionChecker);
        }
    }
    
    @Override
    public void setLoadBalanceSQLStateFailover(final String loadBalanceSQLStateFailover) {
        super.setLoadBalanceSQLStateFailover(loadBalanceSQLStateFailover);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setLoadBalanceSQLStateFailover(loadBalanceSQLStateFailover);
        }
    }
    
    @Override
    public void setLoadBalanceSQLExceptionSubclassFailover(final String loadBalanceSQLExceptionSubclassFailover) {
        super.setLoadBalanceSQLExceptionSubclassFailover(loadBalanceSQLExceptionSubclassFailover);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setLoadBalanceSQLExceptionSubclassFailover(loadBalanceSQLExceptionSubclassFailover);
        }
    }
    
    @Override
    public void setLoadBalanceEnableJMX(final boolean loadBalanceEnableJMX) {
        super.setLoadBalanceEnableJMX(loadBalanceEnableJMX);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setLoadBalanceEnableJMX(loadBalanceEnableJMX);
        }
    }
    
    @Override
    public void setLoadBalanceAutoCommitStatementThreshold(final int loadBalanceAutoCommitStatementThreshold) throws SQLException {
        super.setLoadBalanceAutoCommitStatementThreshold(loadBalanceAutoCommitStatementThreshold);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setLoadBalanceAutoCommitStatementThreshold(loadBalanceAutoCommitStatementThreshold);
        }
    }
    
    @Override
    public void setLoadBalanceAutoCommitStatementRegex(final String loadBalanceAutoCommitStatementRegex) {
        super.setLoadBalanceAutoCommitStatementRegex(loadBalanceAutoCommitStatementRegex);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setLoadBalanceAutoCommitStatementRegex(loadBalanceAutoCommitStatementRegex);
        }
    }
    
    @Override
    public void setAuthenticationPlugins(final String authenticationPlugins) {
        super.setAuthenticationPlugins(authenticationPlugins);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setAuthenticationPlugins(authenticationPlugins);
        }
    }
    
    @Override
    public void setDisabledAuthenticationPlugins(final String disabledAuthenticationPlugins) {
        super.setDisabledAuthenticationPlugins(disabledAuthenticationPlugins);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setDisabledAuthenticationPlugins(disabledAuthenticationPlugins);
        }
    }
    
    @Override
    public void setDefaultAuthenticationPlugin(final String defaultAuthenticationPlugin) {
        super.setDefaultAuthenticationPlugin(defaultAuthenticationPlugin);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setDefaultAuthenticationPlugin(defaultAuthenticationPlugin);
        }
    }
    
    @Override
    public void setParseInfoCacheFactory(final String factoryClassname) {
        super.setParseInfoCacheFactory(factoryClassname);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setParseInfoCacheFactory(factoryClassname);
        }
    }
    
    @Override
    public void setServerConfigCacheFactory(final String factoryClassname) {
        super.setServerConfigCacheFactory(factoryClassname);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setServerConfigCacheFactory(factoryClassname);
        }
    }
    
    @Override
    public void setDisconnectOnExpiredPasswords(final boolean disconnectOnExpiredPasswords) {
        super.setDisconnectOnExpiredPasswords(disconnectOnExpiredPasswords);
        for (final ConnectionProperties cp : this.serverConnections.values()) {
            cp.setDisconnectOnExpiredPasswords(disconnectOnExpiredPasswords);
        }
    }
    
    @Override
    public void setGetProceduresReturnsFunctions(final boolean getProcedureReturnsFunctions) {
        super.setGetProceduresReturnsFunctions(getProcedureReturnsFunctions);
    }
    
    public int getActiveStatementCount() {
        return -1;
    }
    
    public long getIdleFor() {
        return -1L;
    }
    
    public Log getLog() {
        return this.log;
    }
    
    public boolean isMasterConnection() {
        return false;
    }
    
    public boolean isNoBackslashEscapesSet() {
        return false;
    }
    
    public boolean isSameResource(final Connection c) {
        return false;
    }
    
    public boolean parserKnowsUnicode() {
        return false;
    }
    
    public void ping() throws SQLException {
    }
    
    public void resetServerState() throws SQLException {
    }
    
    public void setFailedOver(final boolean flag) {
    }
    
    @Deprecated
    public void setPreferSlaveDuringFailover(final boolean flag) {
    }
    
    public void setStatementComment(final String comment) {
    }
    
    public void reportQueryTime(final long millisOrNanos) {
    }
    
    public boolean isAbonormallyLongQuery(final long millisOrNanos) {
        return false;
    }
    
    public void initializeExtension(final Extension ex) throws SQLException {
    }
    
    public int getAutoIncrementIncrement() {
        return -1;
    }
    
    public boolean hasSameProperties(final Connection c) {
        return false;
    }
    
    public Properties getProperties() {
        return null;
    }
    
    public void setSchema(final String schema) throws SQLException {
    }
    
    public String getSchema() throws SQLException {
        return null;
    }
    
    public void abort(final Executor executor) throws SQLException {
    }
    
    public void setNetworkTimeout(final Executor executor, final int milliseconds) throws SQLException {
    }
    
    public int getNetworkTimeout() throws SQLException {
        return -1;
    }
    
    public void checkClosed() throws SQLException {
    }
    
    public Object getConnectionMutex() {
        return this;
    }
    
    public void setSessionMaxRows(final int max) throws SQLException {
        for (final Connection c : this.serverConnections.values()) {
            c.setSessionMaxRows(max);
        }
    }
    
    public int getSessionMaxRows() {
        return this.getActiveConnectionPassive().getSessionMaxRows();
    }
    
    public boolean isProxySet() {
        return false;
    }
    
    public Connection duplicate() throws SQLException {
        return null;
    }
    
    public CachedResultSetMetaData getCachedMetaData(final String sql) {
        return null;
    }
    
    public Timer getCancelTimer() {
        return null;
    }
    
    public SingleByteCharsetConverter getCharsetConverter(final String javaEncodingName) throws SQLException {
        return null;
    }
    
    @Deprecated
    public String getCharsetNameForIndex(final int charsetIndex) throws SQLException {
        return this.getEncodingForIndex(charsetIndex);
    }
    
    public String getEncodingForIndex(final int charsetIndex) throws SQLException {
        return null;
    }
    
    public TimeZone getDefaultTimeZone() {
        return null;
    }
    
    public String getErrorMessageEncoding() {
        return null;
    }
    
    @Override
    public ExceptionInterceptor getExceptionInterceptor() {
        if (this.currentConnection == null) {
            return null;
        }
        return this.currentConnection.getExceptionInterceptor();
    }
    
    public String getHost() {
        return null;
    }
    
    public String getHostPortPair() {
        return this.getActiveMySQLConnection().getHostPortPair();
    }
    
    public long getId() {
        return -1L;
    }
    
    public int getMaxBytesPerChar(final String javaCharsetName) throws SQLException {
        return -1;
    }
    
    public int getMaxBytesPerChar(final Integer charsetIndex, final String javaCharsetName) throws SQLException {
        return -1;
    }
    
    public int getNetBufferLength() {
        return -1;
    }
    
    public boolean getRequiresEscapingEncoder() {
        return false;
    }
    
    public int getServerMajorVersion() {
        return -1;
    }
    
    public int getServerMinorVersion() {
        return -1;
    }
    
    public int getServerSubMinorVersion() {
        return -1;
    }
    
    public String getServerVariable(final String variableName) {
        return null;
    }
    
    public String getServerVersion() {
        return null;
    }
    
    public Calendar getSessionLockedCalendar() {
        return null;
    }
    
    public String getStatementComment() {
        return null;
    }
    
    public List<StatementInterceptorV2> getStatementInterceptorsInstances() {
        return null;
    }
    
    public String getURL() {
        return null;
    }
    
    public String getUser() {
        return null;
    }
    
    public Calendar getUtcCalendar() {
        return null;
    }
    
    public void incrementNumberOfPreparedExecutes() {
    }
    
    public void incrementNumberOfPrepares() {
    }
    
    public void incrementNumberOfResultSetsCreated() {
    }
    
    public void initializeResultsMetadataFromCache(final String sql, final CachedResultSetMetaData cachedMetaData, final ResultSetInternalMethods resultSet) throws SQLException {
    }
    
    public void initializeSafeStatementInterceptors() throws SQLException {
    }
    
    public boolean isClientTzUTC() {
        return false;
    }
    
    public boolean isCursorFetchEnabled() throws SQLException {
        return false;
    }
    
    public boolean isReadInfoMsgEnabled() {
        return false;
    }
    
    public boolean isServerTzUTC() {
        return false;
    }
    
    public boolean lowerCaseTableNames() {
        return this.getActiveMySQLConnection().lowerCaseTableNames();
    }
    
    public void maxRowsChanged(final com.mysql.jdbc.Statement stmt) {
    }
    
    public void pingInternal(final boolean checkForClosedConnection, final int timeoutMillis) throws SQLException {
    }
    
    public void realClose(final boolean calledExplicitly, final boolean issueRollback, final boolean skipLocalTeardown, final Throwable reason) throws SQLException {
    }
    
    public void recachePreparedStatement(final ServerPreparedStatement pstmt) throws SQLException {
    }
    
    public void registerQueryExecutionTime(final long queryTimeMs) {
    }
    
    public void registerStatement(final com.mysql.jdbc.Statement stmt) {
    }
    
    public void reportNumberOfTablesAccessed(final int numTablesAccessed) {
    }
    
    public boolean serverSupportsConvertFn() throws SQLException {
        return this.getActiveMySQLConnectionChecked().serverSupportsConvertFn();
    }
    
    public void setReadInfoMsgEnabled(final boolean flag) {
    }
    
    public void setReadOnlyInternal(final boolean readOnlyFlag) throws SQLException {
    }
    
    public boolean storesLowerCaseTableName() {
        return this.getActiveMySQLConnection().storesLowerCaseTableName();
    }
    
    public void throwConnectionClosedException() throws SQLException {
    }
    
    public void unregisterStatement(final com.mysql.jdbc.Statement stmt) {
    }
    
    public void unsetMaxRows(final com.mysql.jdbc.Statement stmt) throws SQLException {
    }
    
    public boolean useAnsiQuotedIdentifiers() {
        return false;
    }
    
    public boolean useMaxRows() {
        return false;
    }
    
    public void clearWarnings() {
    }
    
    public Properties getClientInfo() {
        return null;
    }
    
    public String getClientInfo(final String name) {
        return null;
    }
    
    public int getHoldability() {
        return -1;
    }
    
    public int getTransactionIsolation() {
        return -1;
    }
    
    public Map<String, Class<?>> getTypeMap() {
        return null;
    }
    
    public SQLWarning getWarnings() throws SQLException {
        return this.getActiveMySQLConnectionChecked().getWarnings();
    }
    
    public String nativeSQL(final String sql) throws SQLException {
        return this.getActiveMySQLConnectionChecked().nativeSQL(sql);
    }
    
    public ProfilerEventHandler getProfilerEventHandlerInstance() {
        return null;
    }
    
    public void setProfilerEventHandlerInstance(final ProfilerEventHandler h) {
    }
    
    public void decachePreparedStatement(final ServerPreparedStatement pstmt) throws SQLException {
    }
    
    static {
        replConnGroupLocks = Collections.synchronizedSet(new HashSet<String>());
        Class<?> clazz = null;
        try {
            if (Util.isJdbc4()) {
                clazz = Class.forName("com.mysql.jdbc.exceptions.jdbc4.MySQLNonTransientConnectionException");
            }
        }
        catch (ClassNotFoundException ex) {}
        JDBC4_NON_TRANSIENT_CONN_EXCEPTION = clazz;
    }
}
