// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.jdbc;

import java.sql.SQLException;
import java.util.Iterator;
import java.sql.Connection;
import java.util.Properties;
import java.sql.Driver;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

public class FabricMySQLDataSource extends MysqlDataSource implements FabricMySQLConnectionProperties
{
    private static final long serialVersionUID = 1L;
    private static final Driver driver;
    private String fabricShardKey;
    private String fabricShardTable;
    private String fabricServerGroup;
    private String fabricProtocol;
    private String fabricUsername;
    private String fabricPassword;
    private boolean fabricReportErrors;
    
    public FabricMySQLDataSource() {
        this.fabricProtocol = "http";
        this.fabricReportErrors = false;
    }
    
    @Override
    protected Connection getConnection(final Properties props) throws SQLException {
        String jdbcUrlToUse = null;
        if (!this.explicitUrl) {
            final StringBuilder jdbcUrl = new StringBuilder("jdbc:mysql:fabric://");
            if (this.hostName != null) {
                jdbcUrl.append(this.hostName);
            }
            jdbcUrl.append(":");
            jdbcUrl.append(this.port);
            jdbcUrl.append("/");
            if (this.databaseName != null) {
                jdbcUrl.append(this.databaseName);
            }
            jdbcUrlToUse = jdbcUrl.toString();
        }
        else {
            jdbcUrlToUse = this.url;
        }
        final Properties urlProps = ((FabricMySQLDriver)FabricMySQLDataSource.driver).parseFabricURL(jdbcUrlToUse, null);
        urlProps.remove("DBNAME");
        urlProps.remove("HOST");
        urlProps.remove("PORT");
        for (final String key : urlProps.keySet()) {
            props.setProperty(key, urlProps.getProperty(key));
        }
        if (this.fabricShardKey != null) {
            props.setProperty("fabricShardKey", this.fabricShardKey);
        }
        if (this.fabricShardTable != null) {
            props.setProperty("fabricShardTable", this.fabricShardTable);
        }
        if (this.fabricServerGroup != null) {
            props.setProperty("fabricServerGroup", this.fabricServerGroup);
        }
        props.setProperty("fabricProtocol", this.fabricProtocol);
        if (this.fabricUsername != null) {
            props.setProperty("fabricUsername", this.fabricUsername);
        }
        if (this.fabricPassword != null) {
            props.setProperty("fabricPassword", this.fabricPassword);
        }
        props.setProperty("fabricReportErrors", Boolean.toString(this.fabricReportErrors));
        return FabricMySQLDataSource.driver.connect(jdbcUrlToUse, props);
    }
    
    public void setFabricShardKey(final String value) {
        this.fabricShardKey = value;
    }
    
    public String getFabricShardKey() {
        return this.fabricShardKey;
    }
    
    public void setFabricShardTable(final String value) {
        this.fabricShardTable = value;
    }
    
    public String getFabricShardTable() {
        return this.fabricShardTable;
    }
    
    public void setFabricServerGroup(final String value) {
        this.fabricServerGroup = value;
    }
    
    public String getFabricServerGroup() {
        return this.fabricServerGroup;
    }
    
    public void setFabricProtocol(final String value) {
        this.fabricProtocol = value;
    }
    
    public String getFabricProtocol() {
        return this.fabricProtocol;
    }
    
    public void setFabricUsername(final String value) {
        this.fabricUsername = value;
    }
    
    public String getFabricUsername() {
        return this.fabricUsername;
    }
    
    public void setFabricPassword(final String value) {
        this.fabricPassword = value;
    }
    
    public String getFabricPassword() {
        return this.fabricPassword;
    }
    
    public void setFabricReportErrors(final boolean value) {
        this.fabricReportErrors = value;
    }
    
    public boolean getFabricReportErrors() {
        return this.fabricReportErrors;
    }
    
    static {
        try {
            driver = new FabricMySQLDriver();
        }
        catch (Exception ex) {
            throw new RuntimeException("Can create driver", ex);
        }
    }
}
