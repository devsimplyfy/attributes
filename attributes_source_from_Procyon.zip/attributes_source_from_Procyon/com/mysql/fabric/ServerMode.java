// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric;

public enum ServerMode
{
    OFFLINE, 
    READ_ONLY, 
    WRITE_ONLY, 
    READ_WRITE;
    
    public static ServerMode getFromConstant(final Integer constant) {
        return values()[constant];
    }
}
