// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric;

import java.util.Iterator;
import java.util.Collection;
import java.util.Comparator;
import java.util.TreeSet;
import java.util.Set;

public class RangeShardMapping extends ShardMapping
{
    public RangeShardMapping(final int mappingId, final ShardingType shardingType, final String globalGroupName, final Set<ShardTable> shardTables, final Set<ShardIndex> shardIndices) {
        super(mappingId, shardingType, globalGroupName, shardTables, new TreeSet<ShardIndex>(RangeShardIndexSorter.instance));
        this.shardIndices.addAll(shardIndices);
    }
    
    @Override
    protected ShardIndex getShardIndexForKey(final String stringKey) {
        Integer key = -1;
        key = Integer.parseInt(stringKey);
        for (final ShardIndex i : this.shardIndices) {
            final Integer lowerBound = Integer.valueOf(i.getBound());
            if (key >= lowerBound) {
                return i;
            }
        }
        return null;
    }
    
    private static class RangeShardIndexSorter implements Comparator<ShardIndex>
    {
        public static final RangeShardIndexSorter instance;
        
        public int compare(final ShardIndex i1, final ShardIndex i2) {
            final Integer bound1 = Integer.parseInt(i1.getBound());
            final Integer bound2 = Integer.parseInt(i2.getBound());
            return bound2.compareTo(bound1);
        }
        
        static {
            instance = new RangeShardIndexSorter();
        }
    }
}
