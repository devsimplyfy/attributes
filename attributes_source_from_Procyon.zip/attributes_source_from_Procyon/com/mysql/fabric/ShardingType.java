// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric;

public enum ShardingType
{
    LIST, 
    RANGE, 
    HASH;
}
