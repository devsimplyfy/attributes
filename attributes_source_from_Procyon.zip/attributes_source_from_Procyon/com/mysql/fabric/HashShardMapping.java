// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric;

import java.security.NoSuchAlgorithmException;
import java.util.Iterator;
import java.math.BigInteger;
import java.util.Collection;
import java.util.Comparator;
import java.util.TreeSet;
import java.util.Set;
import java.security.MessageDigest;

public class HashShardMapping extends ShardMapping
{
    private static final MessageDigest md5Hasher;
    
    public HashShardMapping(final int mappingId, final ShardingType shardingType, final String globalGroupName, final Set<ShardTable> shardTables, final Set<ShardIndex> shardIndices) {
        super(mappingId, shardingType, globalGroupName, shardTables, new TreeSet<ShardIndex>(ReverseShardIndexSorter.instance));
        this.shardIndices.addAll(shardIndices);
    }
    
    @Override
    protected ShardIndex getShardIndexForKey(final String stringKey) {
        String hashedKey;
        synchronized (HashShardMapping.md5Hasher) {
            hashedKey = new BigInteger(1, HashShardMapping.md5Hasher.digest(stringKey.getBytes())).toString(16).toUpperCase();
        }
        for (int i = 0; i < 32 - hashedKey.length(); hashedKey = "0" + hashedKey, ++i) {}
        for (final ShardIndex j : this.shardIndices) {
            if (j.getBound().compareTo(hashedKey) <= 0) {
                return j;
            }
        }
        return this.shardIndices.iterator().next();
    }
    
    static {
        try {
            md5Hasher = MessageDigest.getInstance("MD5");
        }
        catch (NoSuchAlgorithmException ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }
    
    private static class ReverseShardIndexSorter implements Comparator<ShardIndex>
    {
        public static final ReverseShardIndexSorter instance;
        
        public int compare(final ShardIndex i1, final ShardIndex i2) {
            return i2.getBound().compareTo(i1.getBound());
        }
        
        static {
            instance = new ReverseShardIndexSorter();
        }
    }
}
