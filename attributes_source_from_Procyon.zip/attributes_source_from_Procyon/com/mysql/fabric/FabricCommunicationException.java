// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric;

public class FabricCommunicationException extends Exception
{
    private static final long serialVersionUID = 1L;
    
    public FabricCommunicationException(final Throwable cause) {
        super(cause);
    }
    
    public FabricCommunicationException(final String message) {
        super(message);
    }
    
    public FabricCommunicationException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
