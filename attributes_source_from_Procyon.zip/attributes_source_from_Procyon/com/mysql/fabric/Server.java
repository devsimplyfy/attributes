// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric;

public class Server implements Comparable<Server>
{
    private String groupName;
    private String uuid;
    private String hostname;
    private int port;
    private ServerMode mode;
    private ServerRole role;
    private double weight;
    
    public Server(final String groupName, final String uuid, final String hostname, final int port, final ServerMode mode, final ServerRole role, final double weight) {
        this.groupName = groupName;
        this.uuid = uuid;
        this.hostname = hostname;
        this.port = port;
        this.mode = mode;
        this.role = role;
        this.weight = weight;
        assert uuid != null && !"".equals(uuid);
        assert hostname != null && !"".equals(hostname);
        assert port > 0;
        assert mode != null;
        assert role != null;
        assert weight > 0.0;
    }
    
    public String getGroupName() {
        return this.groupName;
    }
    
    public String getUuid() {
        return this.uuid;
    }
    
    public String getHostname() {
        return this.hostname;
    }
    
    public int getPort() {
        return this.port;
    }
    
    public ServerMode getMode() {
        return this.mode;
    }
    
    public ServerRole getRole() {
        return this.role;
    }
    
    public double getWeight() {
        return this.weight;
    }
    
    public String getHostPortString() {
        return this.hostname + ":" + this.port;
    }
    
    public boolean isMaster() {
        return this.role == ServerRole.PRIMARY;
    }
    
    public boolean isSlave() {
        return this.role == ServerRole.SECONDARY || this.role == ServerRole.SPARE;
    }
    
    @Override
    public String toString() {
        return String.format("Server[%s, %s:%d, %s, %s, weight=%s]", this.uuid, this.hostname, this.port, this.mode, this.role, this.weight);
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof Server)) {
            return false;
        }
        final Server s = (Server)o;
        return s.getUuid().equals(this.getUuid());
    }
    
    @Override
    public int hashCode() {
        return this.getUuid().hashCode();
    }
    
    public int compareTo(final Server other) {
        return this.getUuid().compareTo(other.getUuid());
    }
}
