// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric;

import java.util.Iterator;
import java.util.Set;

public class ServerGroup
{
    private String name;
    private Set<Server> servers;
    
    public ServerGroup(final String name, final Set<Server> servers) {
        this.name = name;
        this.servers = servers;
    }
    
    public String getName() {
        return this.name;
    }
    
    public Set<Server> getServers() {
        return this.servers;
    }
    
    public Server getMaster() {
        for (final Server s : this.servers) {
            if (s.getRole() == ServerRole.PRIMARY) {
                return s;
            }
        }
        return null;
    }
    
    public Server getServer(final String hostPortString) {
        for (final Server s : this.servers) {
            if (s.getHostPortString().equals(hostPortString)) {
                return s;
            }
        }
        return null;
    }
    
    @Override
    public String toString() {
        return String.format("Group[name=%s, servers=%s]", this.name, this.servers);
    }
}
