// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric;

import com.mysql.fabric.proto.xmlrpc.ResultSetParser;
import java.util.Map;
import java.util.List;

public class Response
{
    private int protocolVersion;
    private String fabricUuid;
    private int ttl;
    private String errorMessage;
    private List<Map<String, ?>> resultSet;
    
    public Response(final List<?> responseData) throws FabricCommunicationException {
        this.protocolVersion = (int)responseData.get(0);
        if (this.protocolVersion != 1) {
            throw new FabricCommunicationException("Unknown protocol version: " + this.protocolVersion);
        }
        this.fabricUuid = (String)responseData.get(1);
        this.ttl = (int)responseData.get(2);
        this.errorMessage = (String)responseData.get(3);
        if ("".equals(this.errorMessage)) {
            this.errorMessage = null;
        }
        final List<Map<String, ?>> resultSets = (List<Map<String, ?>>)responseData.get(4);
        if (resultSets.size() > 0) {
            final Map<String, ?> resultData = resultSets.get(0);
            this.resultSet = new ResultSetParser().parse((Map<String, ?>)resultData.get("info"), (List<List<Object>>)resultData.get("rows"));
        }
    }
    
    public int getProtocolVersion() {
        return this.protocolVersion;
    }
    
    public String getFabricUuid() {
        return this.fabricUuid;
    }
    
    public int getTtl() {
        return this.ttl;
    }
    
    public String getErrorMessage() {
        return this.errorMessage;
    }
    
    public List<Map<String, ?>> getResultSet() {
        return this.resultSet;
    }
}
