// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.proto.xmlrpc;

import com.mysql.fabric.FabricCommunicationException;
import java.util.List;

public interface XmlRpcMethodCaller
{
    List<?> call(final String p0, final Object[] p1) throws FabricCommunicationException;
    
    void setHeader(final String p0, final String p1);
    
    void clearHeader(final String p0);
}
