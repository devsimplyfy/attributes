// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.proto.xmlrpc;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.security.NoSuchAlgorithmException;
import java.security.MessageDigest;
import java.io.IOException;
import java.net.URL;
import java.net.HttpURLConnection;
import java.util.Random;

public class DigestAuthentication
{
    private static Random random;
    
    public static String getChallengeHeader(final String url) throws IOException {
        final HttpURLConnection conn = (HttpURLConnection)new URL(url).openConnection();
        conn.setDoOutput(true);
        conn.getOutputStream().close();
        try {
            conn.getInputStream().close();
        }
        catch (IOException ex) {
            if (401 == conn.getResponseCode()) {
                final String hdr = conn.getHeaderField("WWW-Authenticate");
                if (hdr != null && !"".equals(hdr)) {
                    return hdr;
                }
            }
            else {
                if (400 == conn.getResponseCode()) {
                    throw new IOException("Fabric returns status 400. If authentication is disabled on the Fabric node, omit the `fabricUsername' and `fabricPassword' properties from your connection.");
                }
                throw ex;
            }
        }
        return null;
    }
    
    public static String calculateMD5RequestDigest(final String uri, final String username, final String password, final String realm, final String nonce, final String nc, final String cnonce, final String qop) {
        final String reqA1 = username + ":" + realm + ":" + password;
        final String reqA2 = "POST:" + uri;
        final String hashA1 = checksumMD5(reqA1);
        final String hashA2 = checksumMD5(reqA2);
        final String requestDigest = digestMD5(hashA1, nonce + ":" + nc + ":" + cnonce + ":" + qop + ":" + hashA2);
        return requestDigest;
    }
    
    private static String checksumMD5(final String data) {
        MessageDigest md5 = null;
        try {
            md5 = MessageDigest.getInstance("MD5");
        }
        catch (NoSuchAlgorithmException ex) {
            throw new RuntimeException("Unable to create MD5 instance", ex);
        }
        return hexEncode(md5.digest(data.getBytes()));
    }
    
    private static String digestMD5(final String secret, final String data) {
        return checksumMD5(secret + ":" + data);
    }
    
    private static String hexEncode(final byte[] data) {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < data.length; ++i) {
            sb.append(String.format("%02x", data[i]));
        }
        return sb.toString();
    }
    
    public static String serializeDigestResponse(final Map<String, String> paramMap) {
        final StringBuilder sb = new StringBuilder("Digest ");
        boolean prefixComma = false;
        for (final Map.Entry<String, String> entry : paramMap.entrySet()) {
            if (!prefixComma) {
                prefixComma = true;
            }
            else {
                sb.append(", ");
            }
            sb.append(entry.getKey());
            sb.append("=");
            sb.append(entry.getValue());
        }
        return sb.toString();
    }
    
    public static Map<String, String> parseDigestChallenge(final String headerValue) {
        if (!headerValue.startsWith("Digest ")) {
            throw new IllegalArgumentException("Header is not a digest challenge");
        }
        final String params = headerValue.substring(7);
        final Map<String, String> paramMap = new HashMap<String, String>();
        for (final String param : params.split(",\\s*")) {
            final String[] pieces = param.split("=");
            paramMap.put(pieces[0], pieces[1].replaceAll("^\"(.*)\"$", "$1"));
        }
        return paramMap;
    }
    
    public static String generateCnonce(final String nonce, final String nc) {
        final byte[] buf = new byte[8];
        DigestAuthentication.random.nextBytes(buf);
        for (int i = 0; i < 8; ++i) {
            buf[i] = (byte)(32 + buf[i] % 95);
        }
        final String combo = String.format("%s:%s:%s:%s", nonce, nc, new Date().toGMTString(), new String(buf));
        MessageDigest sha1 = null;
        try {
            sha1 = MessageDigest.getInstance("SHA-1");
        }
        catch (NoSuchAlgorithmException ex) {
            throw new RuntimeException("Unable to create SHA-1 instance", ex);
        }
        return hexEncode(sha1.digest(combo.getBytes()));
    }
    
    private static String quoteParam(final String param) {
        if (param.contains("\"") || param.contains("'")) {
            throw new IllegalArgumentException("Invalid character in parameter");
        }
        return "\"" + param + "\"";
    }
    
    public static String generateAuthorizationHeader(final Map<String, String> digestChallenge, final String username, final String password) {
        final String nonce = digestChallenge.get("nonce");
        final String nc = "00000001";
        final String cnonce = generateCnonce(nonce, nc);
        final String qop = "auth";
        final String uri = "/RPC2";
        final String realm = digestChallenge.get("realm");
        final String opaque = digestChallenge.get("opaque");
        final String requestDigest = calculateMD5RequestDigest(uri, username, password, realm, nonce, nc, cnonce, qop);
        final Map<String, String> digestResponseMap = new HashMap<String, String>();
        digestResponseMap.put("algorithm", "MD5");
        digestResponseMap.put("username", quoteParam(username));
        digestResponseMap.put("realm", quoteParam(realm));
        digestResponseMap.put("nonce", quoteParam(nonce));
        digestResponseMap.put("uri", quoteParam(uri));
        digestResponseMap.put("qop", qop);
        digestResponseMap.put("nc", nc);
        digestResponseMap.put("cnonce", quoteParam(cnonce));
        digestResponseMap.put("response", quoteParam(requestDigest));
        digestResponseMap.put("opaque", quoteParam(opaque));
        return serializeDigestResponse(digestResponseMap);
    }
    
    static {
        DigestAuthentication.random = new Random();
    }
}
