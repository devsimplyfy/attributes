// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.proto.xmlrpc;

import com.mysql.fabric.xmlrpc.base.MethodResponse;
import java.util.Arrays;
import com.mysql.fabric.xmlrpc.base.Param;
import com.mysql.fabric.xmlrpc.base.Params;
import com.mysql.fabric.xmlrpc.base.MethodCall;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.Map;
import com.mysql.fabric.xmlrpc.base.Member;
import com.mysql.fabric.xmlrpc.base.Struct;
import java.util.HashMap;
import com.mysql.fabric.xmlrpc.base.Array;
import com.mysql.fabric.xmlrpc.base.Value;
import java.net.MalformedURLException;
import com.mysql.fabric.FabricCommunicationException;
import com.mysql.fabric.xmlrpc.Client;

public class InternalXmlRpcMethodCaller implements XmlRpcMethodCaller
{
    private Client xmlRpcClient;
    
    public InternalXmlRpcMethodCaller(final String url) throws FabricCommunicationException {
        try {
            this.xmlRpcClient = new Client(url);
        }
        catch (MalformedURLException ex) {
            throw new FabricCommunicationException(ex);
        }
    }
    
    private Object unwrapValue(final Value v) {
        if (v.getType() == 8) {
            return this.methodResponseArrayToList((Array)v.getValue());
        }
        if (v.getType() == 7) {
            final Map<String, Object> s = new HashMap<String, Object>();
            for (final Member m : ((Struct)v.getValue()).getMember()) {
                s.put(m.getName(), this.unwrapValue(m.getValue()));
            }
            return s;
        }
        return v.getValue();
    }
    
    private List<Object> methodResponseArrayToList(final Array array) {
        final List<Object> result = new ArrayList<Object>();
        for (final Value v : array.getData().getValue()) {
            result.add(this.unwrapValue(v));
        }
        return result;
    }
    
    public void setHeader(final String name, final String value) {
        this.xmlRpcClient.setHeader(name, value);
    }
    
    public void clearHeader(final String name) {
        this.xmlRpcClient.clearHeader(name);
    }
    
    public List<Object> call(final String methodName, Object[] args) throws FabricCommunicationException {
        final MethodCall methodCall = new MethodCall();
        final Params p = new Params();
        if (args == null) {
            args = new Object[0];
        }
        for (int i = 0; i < args.length; ++i) {
            if (args[i] == null) {
                throw new NullPointerException("nil args unsupported");
            }
            if (String.class.isAssignableFrom(args[i].getClass())) {
                p.addParam(new Param(new Value((String)args[i])));
            }
            else if (Double.class.isAssignableFrom(args[i].getClass())) {
                p.addParam(new Param(new Value((double)args[i])));
            }
            else {
                if (!Integer.class.isAssignableFrom(args[i].getClass())) {
                    throw new IllegalArgumentException("Unknown argument type: " + args[i].getClass());
                }
                p.addParam(new Param(new Value((int)args[i])));
            }
        }
        methodCall.setMethodName(methodName);
        methodCall.setParams(p);
        try {
            final MethodResponse resp = this.xmlRpcClient.execute(methodCall);
            return this.methodResponseArrayToList((Array)resp.getParams().getParam().get(0).getValue().getValue());
        }
        catch (Exception ex) {
            throw new FabricCommunicationException("Error during call to `" + methodName + "' (args=" + Arrays.toString(args) + ")", ex);
        }
    }
}
