// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.proto.xmlrpc;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ResultSetParser
{
    public List<Map<String, ?>> parse(final Map<String, ?> info, final List<List<Object>> rows) {
        final List<String> fieldNames = (List<String>)info.get("names");
        final Map<String, Integer> fieldNameIndexes = new HashMap<String, Integer>();
        for (int i = 0; i < fieldNames.size(); ++i) {
            fieldNameIndexes.put(fieldNames.get(i), i);
        }
        final List<Map<String, ?>> result = new ArrayList<Map<String, ?>>(rows.size());
        for (final List<Object> r : rows) {
            final Map<String, Object> resultRow = new HashMap<String, Object>();
            for (final Map.Entry<String, Integer> f : fieldNameIndexes.entrySet()) {
                resultRow.put(f.getKey(), r.get(f.getValue()));
            }
            result.add(resultRow);
        }
        return result;
    }
}
