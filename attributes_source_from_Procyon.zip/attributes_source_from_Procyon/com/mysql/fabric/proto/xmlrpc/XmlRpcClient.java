// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.proto.xmlrpc;

import com.mysql.fabric.ShardMappingFactory;
import com.mysql.fabric.ShardingType;
import java.util.concurrent.TimeUnit;
import com.mysql.fabric.ShardMapping;
import com.mysql.fabric.ShardIndex;
import com.mysql.fabric.ShardTable;
import java.util.HashMap;
import com.mysql.fabric.FabricStateResponse;
import com.mysql.fabric.ServerGroup;
import com.mysql.fabric.Response;
import java.util.Iterator;
import java.util.HashSet;
import java.util.Set;
import java.util.List;
import com.mysql.fabric.ServerRole;
import com.mysql.fabric.ServerMode;
import com.mysql.fabric.Server;
import java.util.Map;
import com.mysql.fabric.FabricCommunicationException;

public class XmlRpcClient
{
    private static final String THREAT_REPORTER_NAME = "MySQL Connector/J";
    private static final String METHOD_DUMP_FABRIC_NODES = "dump.fabric_nodes";
    private static final String METHOD_DUMP_SERVERS = "dump.servers";
    private static final String METHOD_DUMP_SHARD_TABLES = "dump.shard_tables";
    private static final String METHOD_DUMP_SHARD_INDEX = "dump.shard_index";
    private static final String METHOD_DUMP_SHARD_MAPS = "dump.shard_maps";
    private static final String METHOD_SHARDING_LOOKUP_SERVERS = "sharding.lookup_servers";
    private static final String METHOD_SHARDING_CREATE_DEFINITION = "sharding.create_definition";
    private static final String METHOD_SHARDING_ADD_TABLE = "sharding.add_table";
    private static final String METHOD_SHARDING_ADD_SHARD = "sharding.add_shard";
    private static final String METHOD_GROUP_LOOKUP_GROUPS = "group.lookup_groups";
    private static final String METHOD_GROUP_CREATE = "group.create";
    private static final String METHOD_GROUP_ADD = "group.add";
    private static final String METHOD_GROUP_REMOVE = "group.remove";
    private static final String METHOD_GROUP_PROMOTE = "group.promote";
    private static final String METHOD_GROUP_DESTROY = "group.destroy";
    private static final String METHOD_THREAT_REPORT_ERROR = "threat.report_error";
    private static final String METHOD_THREAT_REPORT_FAILURE = "threat.report_failure";
    private static final String FIELD_MODE = "mode";
    private static final String FIELD_STATUS = "status";
    private static final String FIELD_HOST = "host";
    private static final String FIELD_PORT = "port";
    private static final String FIELD_ADDRESS = "address";
    private static final String FIELD_GROUP_ID = "group_id";
    private static final String FIELD_SERVER_UUID = "server_uuid";
    private static final String FIELD_WEIGHT = "weight";
    private static final String FIELD_SCHEMA_NAME = "schema_name";
    private static final String FIELD_TABLE_NAME = "table_name";
    private static final String FIELD_COLUMN_NAME = "column_name";
    private static final String FIELD_LOWER_BOUND = "lower_bound";
    private static final String FIELD_SHARD_ID = "shard_id";
    private static final String FIELD_MAPPING_ID = "mapping_id";
    private static final String FIELD_GLOBAL_GROUP_ID = "global_group_id";
    private static final String FIELD_TYPE_NAME = "type_name";
    private static final String FIELD_RESULT = "result";
    private XmlRpcMethodCaller methodCaller;
    
    public XmlRpcClient(final String url, final String username, final String password) throws FabricCommunicationException {
        this.methodCaller = new InternalXmlRpcMethodCaller(url);
        if (username != null && !"".equals(username) && password != null) {
            this.methodCaller = new AuthenticatedXmlRpcMethodCaller(this.methodCaller, url, username, password);
        }
    }
    
    private static Server unmarshallServer(final Map<String, ?> serverData) throws FabricCommunicationException {
        try {
            ServerMode mode;
            ServerRole role;
            String host;
            int port;
            if (Integer.class.equals(serverData.get("mode").getClass())) {
                mode = ServerMode.getFromConstant((Integer)serverData.get("mode"));
                role = ServerRole.getFromConstant((Integer)serverData.get("status"));
                host = (String)serverData.get("host");
                port = (int)serverData.get("port");
            }
            else {
                mode = ServerMode.valueOf((String)serverData.get("mode"));
                role = ServerRole.valueOf((String)serverData.get("status"));
                final String[] hostnameAndPort = ((String)serverData.get("address")).split(":");
                host = hostnameAndPort[0];
                port = Integer.valueOf(hostnameAndPort[1]);
            }
            final Server s = new Server((String)serverData.get("group_id"), (String)serverData.get("server_uuid"), host, port, mode, role, (double)serverData.get("weight"));
            return s;
        }
        catch (Exception ex) {
            throw new FabricCommunicationException("Unable to parse server definition", ex);
        }
    }
    
    private static Set<Server> toServerSet(final List<Map<String, ?>> l) throws FabricCommunicationException {
        final Set<Server> servers = new HashSet<Server>();
        for (final Map<String, ?> serverData : l) {
            servers.add(unmarshallServer(serverData));
        }
        return servers;
    }
    
    private Response errorSafeCallMethod(final String methodName, final Object[] args) throws FabricCommunicationException {
        final List<?> responseData = this.methodCaller.call(methodName, args);
        final Response response = new Response(responseData);
        if (response.getErrorMessage() != null) {
            throw new FabricCommunicationException("Call failed to method `" + methodName + "':\n" + response.getErrorMessage());
        }
        return response;
    }
    
    public Set<String> getFabricNames() throws FabricCommunicationException {
        final Response resp = this.errorSafeCallMethod("dump.fabric_nodes", new Object[0]);
        final Set<String> names = new HashSet<String>();
        for (final Map<String, ?> node : resp.getResultSet()) {
            names.add(node.get("host") + ":" + node.get("port"));
        }
        return names;
    }
    
    public Set<String> getGroupNames() throws FabricCommunicationException {
        final Set<String> groupNames = new HashSet<String>();
        for (final Map<String, ?> row : this.errorSafeCallMethod("group.lookup_groups", null).getResultSet()) {
            groupNames.add((String)row.get("group_id"));
        }
        return groupNames;
    }
    
    public ServerGroup getServerGroup(final String groupName) throws FabricCommunicationException {
        final Set<ServerGroup> groups = this.getServerGroups(groupName).getData();
        if (groups.size() == 1) {
            return groups.iterator().next();
        }
        return null;
    }
    
    public Set<Server> getServersForKey(final String tableName, final int key) throws FabricCommunicationException {
        final Response r = this.errorSafeCallMethod("sharding.lookup_servers", new Object[] { tableName, key });
        return toServerSet(r.getResultSet());
    }
    
    public FabricStateResponse<Set<ServerGroup>> getServerGroups(final String groupPattern) throws FabricCommunicationException {
        final int version = 0;
        final Response response = this.errorSafeCallMethod("dump.servers", new Object[] { version, groupPattern });
        final Map<String, Set<Server>> serversByGroupName = new HashMap<String, Set<Server>>();
        for (final Map<String, ?> server : response.getResultSet()) {
            final Server s = unmarshallServer(server);
            if (serversByGroupName.get(s.getGroupName()) == null) {
                serversByGroupName.put(s.getGroupName(), new HashSet<Server>());
            }
            serversByGroupName.get(s.getGroupName()).add(s);
        }
        final Set<ServerGroup> serverGroups = new HashSet<ServerGroup>();
        for (final Map.Entry<String, Set<Server>> entry : serversByGroupName.entrySet()) {
            final ServerGroup g = new ServerGroup(entry.getKey(), entry.getValue());
            serverGroups.add(g);
        }
        return new FabricStateResponse<Set<ServerGroup>>(serverGroups, response.getTtl());
    }
    
    public FabricStateResponse<Set<ServerGroup>> getServerGroups() throws FabricCommunicationException {
        return this.getServerGroups("");
    }
    
    private FabricStateResponse<Set<ShardTable>> getShardTables(final int shardMappingId) throws FabricCommunicationException {
        final int version = 0;
        final Object[] args = { version, String.valueOf(shardMappingId) };
        final Response tablesResponse = this.errorSafeCallMethod("dump.shard_tables", args);
        final Set<ShardTable> tables = new HashSet<ShardTable>();
        for (final Map<String, ?> rawTable : tablesResponse.getResultSet()) {
            final String database = (String)rawTable.get("schema_name");
            final String table = (String)rawTable.get("table_name");
            final String column = (String)rawTable.get("column_name");
            final ShardTable st = new ShardTable(database, table, column);
            tables.add(st);
        }
        return new FabricStateResponse<Set<ShardTable>>(tables, tablesResponse.getTtl());
    }
    
    private FabricStateResponse<Set<ShardIndex>> getShardIndices(final int shardMappingId) throws FabricCommunicationException {
        final int version = 0;
        final Object[] args = { version, String.valueOf(shardMappingId) };
        final Response indexResponse = this.errorSafeCallMethod("dump.shard_index", args);
        final Set<ShardIndex> indices = new HashSet<ShardIndex>();
        for (final Map<String, ?> rawIndexEntry : indexResponse.getResultSet()) {
            final String bound = (String)rawIndexEntry.get("lower_bound");
            final int shardId = (int)rawIndexEntry.get("shard_id");
            final String groupName = (String)rawIndexEntry.get("group_id");
            final ShardIndex si = new ShardIndex(bound, shardId, groupName);
            indices.add(si);
        }
        return new FabricStateResponse<Set<ShardIndex>>(indices, indexResponse.getTtl());
    }
    
    public FabricStateResponse<Set<ShardMapping>> getShardMappings(final String shardMappingIdPattern) throws FabricCommunicationException {
        final int version = 0;
        final Object[] args = { version, shardMappingIdPattern };
        final Response mapsResponse = this.errorSafeCallMethod("dump.shard_maps", args);
        long minExpireTimeMillis = System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(mapsResponse.getTtl());
        final int baseTtl = mapsResponse.getTtl();
        final Set<ShardMapping> mappings = new HashSet<ShardMapping>();
        for (final Map<String, ?> rawMapping : mapsResponse.getResultSet()) {
            final int mappingId = (int)rawMapping.get("mapping_id");
            final ShardingType shardingType = ShardingType.valueOf((String)rawMapping.get("type_name"));
            final String globalGroupName = (String)rawMapping.get("global_group_id");
            final FabricStateResponse<Set<ShardTable>> tables = this.getShardTables(mappingId);
            final FabricStateResponse<Set<ShardIndex>> indices = this.getShardIndices(mappingId);
            if (tables.getExpireTimeMillis() < minExpireTimeMillis) {
                minExpireTimeMillis = tables.getExpireTimeMillis();
            }
            if (indices.getExpireTimeMillis() < minExpireTimeMillis) {
                minExpireTimeMillis = indices.getExpireTimeMillis();
            }
            final ShardMapping m = new ShardMappingFactory().createShardMapping(mappingId, shardingType, globalGroupName, tables.getData(), indices.getData());
            mappings.add(m);
        }
        return new FabricStateResponse<Set<ShardMapping>>(mappings, baseTtl, minExpireTimeMillis);
    }
    
    public FabricStateResponse<Set<ShardMapping>> getShardMappings() throws FabricCommunicationException {
        return this.getShardMappings("");
    }
    
    public void createGroup(final String groupName) throws FabricCommunicationException {
        this.errorSafeCallMethod("group.create", new Object[] { groupName });
    }
    
    public void destroyGroup(final String groupName) throws FabricCommunicationException {
        this.errorSafeCallMethod("group.destroy", new Object[] { groupName });
    }
    
    public void createServerInGroup(final String groupName, final String hostname, final int port) throws FabricCommunicationException {
        this.errorSafeCallMethod("group.add", new Object[] { groupName, hostname + ":" + port });
    }
    
    public int createShardMapping(final ShardingType type, final String globalGroupName) throws FabricCommunicationException {
        final Response r = this.errorSafeCallMethod("sharding.create_definition", new Object[] { type.toString(), globalGroupName });
        return (int)r.getResultSet().get(0).get("result");
    }
    
    public void createShardTable(final int shardMappingId, final String database, final String table, final String column) throws FabricCommunicationException {
        this.errorSafeCallMethod("sharding.add_table", new Object[] { shardMappingId, database + "." + table, column });
    }
    
    public void createShardIndex(final int shardMappingId, final String groupNameLowerBoundList) throws FabricCommunicationException {
        final String status = "ENABLED";
        this.errorSafeCallMethod("sharding.add_shard", new Object[] { shardMappingId, groupNameLowerBoundList, status });
    }
    
    public void addServerToGroup(final String groupName, final String hostname, final int port) throws FabricCommunicationException {
        this.errorSafeCallMethod("group.add", new Object[] { groupName, hostname + ":" + port });
    }
    
    public void removeServerFromGroup(final String groupName, final String hostname, final int port) throws FabricCommunicationException {
        this.errorSafeCallMethod("group.remove", new Object[] { groupName, hostname + ":" + port });
    }
    
    public void promoteServerInGroup(final String groupName, final String hostname, final int port) throws FabricCommunicationException {
        final ServerGroup serverGroup = this.getServerGroup(groupName);
        for (final Server s : serverGroup.getServers()) {
            if (s.getHostname().equals(hostname) && s.getPort() == port) {
                this.errorSafeCallMethod("group.promote", new Object[] { groupName, s.getUuid() });
                break;
            }
        }
    }
    
    public void reportServerError(final Server server, final String errorDescription, final boolean forceFaulty) throws FabricCommunicationException {
        final String reporter = "MySQL Connector/J";
        String command = "threat.report_error";
        if (forceFaulty) {
            command = "threat.report_failure";
        }
        this.errorSafeCallMethod(command, new Object[] { server.getUuid(), reporter, errorDescription });
    }
}
