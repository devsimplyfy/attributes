// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.xmlrpc;

import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import javax.xml.parsers.SAXParser;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Iterator;
import com.mysql.fabric.xmlrpc.exceptions.MySQLFabricException;
import org.xml.sax.helpers.DefaultHandler;
import com.mysql.fabric.xmlrpc.base.ResponseParser;
import javax.xml.parsers.SAXParserFactory;
import java.net.HttpURLConnection;
import com.mysql.fabric.xmlrpc.base.MethodResponse;
import com.mysql.fabric.xmlrpc.base.MethodCall;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;
import java.net.URL;

public class Client
{
    private URL url;
    private Map<String, String> headers;
    
    public Client(final String url) throws MalformedURLException {
        this.headers = new HashMap<String, String>();
        this.url = new URL(url);
    }
    
    public void setHeader(final String name, final String value) {
        this.headers.put(name, value);
    }
    
    public void clearHeader(final String name) {
        this.headers.remove(name);
    }
    
    public MethodResponse execute(final MethodCall methodCall) throws IOException, ParserConfigurationException, SAXException, MySQLFabricException {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection)this.url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("User-Agent", "MySQL XML-RPC");
            connection.setRequestProperty("Content-Type", "text/xml");
            connection.setUseCaches(false);
            connection.setDoInput(true);
            connection.setDoOutput(true);
            for (final Map.Entry<String, String> entry : this.headers.entrySet()) {
                connection.setRequestProperty(entry.getKey(), entry.getValue());
            }
            final String out = methodCall.toString();
            final OutputStream os = connection.getOutputStream();
            os.write(out.getBytes());
            os.flush();
            os.close();
            final InputStream is = connection.getInputStream();
            final SAXParserFactory factory = SAXParserFactory.newInstance();
            final SAXParser parser = factory.newSAXParser();
            final ResponseParser saxp = new ResponseParser();
            parser.parse(is, saxp);
            is.close();
            final MethodResponse resp = saxp.getMethodResponse();
            if (resp.getFault() != null) {
                throw new MySQLFabricException(resp.getFault());
            }
            return resp;
        }
        finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }
}
