// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.xmlrpc.exceptions;

import com.mysql.fabric.xmlrpc.base.Struct;
import com.mysql.fabric.xmlrpc.base.Member;
import com.mysql.fabric.xmlrpc.base.Fault;
import java.sql.SQLException;

public class MySQLFabricException extends SQLException
{
    static final long serialVersionUID = -8776763137552613517L;
    
    public MySQLFabricException() {
    }
    
    public MySQLFabricException(final Fault fault) {
        super((String)((Struct)fault.getValue().getValue()).getMember().get(1).getValue().getValue(), "", (int)((Struct)fault.getValue().getValue()).getMember().get(0).getValue().getValue());
    }
    
    public MySQLFabricException(final String reason, final String SQLState, final int vendorCode) {
        super(reason, SQLState, vendorCode);
    }
    
    public MySQLFabricException(final String reason, final String SQLState) {
        super(reason, SQLState);
    }
    
    public MySQLFabricException(final String reason) {
        super(reason);
    }
}
