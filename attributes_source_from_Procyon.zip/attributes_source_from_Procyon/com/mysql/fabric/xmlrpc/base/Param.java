// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.xmlrpc.base;

public class Param
{
    protected Value value;
    
    public Param() {
    }
    
    public Param(final Value value) {
        this.value = value;
    }
    
    public Value getValue() {
        return this.value;
    }
    
    public void setValue(final Value value) {
        this.value = value;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("<param>");
        sb.append(this.value.toString());
        sb.append("</param>");
        return sb.toString();
    }
}
