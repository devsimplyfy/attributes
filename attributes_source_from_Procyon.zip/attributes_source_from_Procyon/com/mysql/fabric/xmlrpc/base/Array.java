// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.xmlrpc.base;

public class Array
{
    protected Data data;
    
    public Data getData() {
        return this.data;
    }
    
    public void setData(final Data value) {
        this.data = value;
    }
    
    public void addValue(final Value v) {
        if (this.data == null) {
            this.data = new Data();
        }
        this.data.addValue(v);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("<array>");
        sb.append(this.data.toString());
        sb.append("</array>");
        return sb.toString();
    }
}
