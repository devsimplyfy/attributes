// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.xmlrpc.base;

public class MethodCall
{
    protected String methodName;
    protected Params params;
    
    public String getMethodName() {
        return this.methodName;
    }
    
    public void setMethodName(final String value) {
        this.methodName = value;
    }
    
    public Params getParams() {
        return this.params;
    }
    
    public void setParams(final Params value) {
        this.params = value;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        sb.append("<methodCall>");
        sb.append("\t<methodName>" + this.methodName + "</methodName>");
        if (this.params != null) {
            sb.append(this.params.toString());
        }
        sb.append("</methodCall>");
        return sb.toString();
    }
}
