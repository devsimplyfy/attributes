// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.xmlrpc.base;

import org.xml.sax.Locator;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;
import java.util.Stack;
import org.xml.sax.helpers.DefaultHandler;

public class ResponseParser extends DefaultHandler
{
    private MethodResponse resp;
    Stack<Object> elNames;
    Stack<Object> objects;
    
    public ResponseParser() {
        this.resp = null;
        this.elNames = new Stack<Object>();
        this.objects = new Stack<Object>();
    }
    
    public MethodResponse getMethodResponse() {
        return this.resp;
    }
    
    @Override
    public void startElement(final String uri, final String localName, final String qName, final Attributes attributes) throws SAXException {
        final String thisElement = qName;
        if (thisElement != null) {
            this.elNames.push(thisElement);
            if (thisElement.equals("methodResponse")) {
                this.objects.push(new MethodResponse());
            }
            else if (thisElement.equals("params")) {
                this.objects.push(new Params());
            }
            else if (thisElement.equals("param")) {
                this.objects.push(new Param());
            }
            else if (thisElement.equals("value")) {
                this.objects.push(new Value());
            }
            else if (thisElement.equals("array")) {
                this.objects.push(new Array());
            }
            else if (thisElement.equals("data")) {
                this.objects.push(new Data());
            }
            else if (thisElement.equals("struct")) {
                this.objects.push(new Struct());
            }
            else if (thisElement.equals("member")) {
                this.objects.push(new Member());
            }
            else if (thisElement.equals("fault")) {
                this.objects.push(new Fault());
            }
        }
    }
    
    @Override
    public void endElement(final String uri, final String localName, final String qName) throws SAXException {
        final String thisElement = this.elNames.pop();
        if (thisElement != null) {
            if (thisElement.equals("methodResponse")) {
                this.resp = this.objects.pop();
            }
            else if (thisElement.equals("params")) {
                final Params pms = this.objects.pop();
                final MethodResponse parent = this.objects.peek();
                parent.setParams(pms);
            }
            else if (thisElement.equals("param")) {
                final Param p = this.objects.pop();
                final Params parent2 = this.objects.peek();
                parent2.addParam(p);
            }
            else if (thisElement.equals("value")) {
                final Value v = this.objects.pop();
                final Object parent3 = this.objects.peek();
                if (parent3 instanceof Data) {
                    ((Data)parent3).addValue(v);
                }
                else if (parent3 instanceof Param) {
                    ((Param)parent3).setValue(v);
                }
                else if (parent3 instanceof Member) {
                    ((Member)parent3).setValue(v);
                }
                else if (parent3 instanceof Fault) {
                    ((Fault)parent3).setValue(v);
                }
            }
            else if (thisElement.equals("array")) {
                final Array a = this.objects.pop();
                final Value parent4 = this.objects.peek();
                parent4.setArray(a);
            }
            else if (thisElement.equals("data")) {
                final Data d = this.objects.pop();
                final Array parent5 = this.objects.peek();
                parent5.setData(d);
            }
            else if (thisElement.equals("struct")) {
                final Struct s = this.objects.pop();
                final Value parent4 = this.objects.peek();
                parent4.setStruct(s);
            }
            else if (thisElement.equals("member")) {
                final Member m = this.objects.pop();
                final Struct parent6 = this.objects.peek();
                parent6.addMember(m);
            }
            else if (thisElement.equals("fault")) {
                final Fault f = this.objects.pop();
                final MethodResponse parent = this.objects.peek();
                parent.setFault(f);
            }
        }
    }
    
    @Override
    public void characters(final char[] ch, final int start, final int length) throws SAXException {
        try {
            final String thisElement = this.elNames.peek();
            if (thisElement != null) {
                if (thisElement.equals("name")) {
                    this.objects.peek().setName(new String(ch, start, length));
                }
                else if (thisElement.equals("value")) {
                    this.objects.peek().appendString(new String(ch, start, length));
                }
                else if (thisElement.equals("i4") || thisElement.equals("int")) {
                    this.objects.peek().setInt(new String(ch, start, length));
                }
                else if (thisElement.equals("boolean")) {
                    this.objects.peek().setBoolean(new String(ch, start, length));
                }
                else if (thisElement.equals("string")) {
                    this.objects.peek().appendString(new String(ch, start, length));
                }
                else if (thisElement.equals("double")) {
                    this.objects.peek().setDouble(new String(ch, start, length));
                }
                else if (thisElement.equals("dateTime.iso8601")) {
                    this.objects.peek().setDateTime(new String(ch, start, length));
                }
                else if (thisElement.equals("base64")) {
                    this.objects.peek().setBase64(new String(ch, start, length).getBytes());
                }
            }
        }
        catch (Exception e) {
            throw new SAXParseException(e.getMessage(), null, e);
        }
    }
}
