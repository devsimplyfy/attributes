// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.xmlrpc.base;

public class Member
{
    protected String name;
    protected Value value;
    
    public Member() {
    }
    
    public Member(final String name, final Value value) {
        this.setName(name);
        this.setValue(value);
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String value) {
        this.name = value;
    }
    
    public Value getValue() {
        return this.value;
    }
    
    public void setValue(final Value value) {
        this.value = value;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("<member>");
        sb.append("<name>" + this.name + "</name>");
        sb.append(this.value.toString());
        sb.append("</member>");
        return sb.toString();
    }
}
