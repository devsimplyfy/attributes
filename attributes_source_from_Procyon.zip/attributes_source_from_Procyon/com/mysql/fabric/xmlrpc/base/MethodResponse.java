// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.xmlrpc.base;

public class MethodResponse
{
    protected Params params;
    protected Fault fault;
    
    public Params getParams() {
        return this.params;
    }
    
    public void setParams(final Params value) {
        this.params = value;
    }
    
    public Fault getFault() {
        return this.fault;
    }
    
    public void setFault(final Fault value) {
        this.fault = value;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        sb.append("<methodResponse>");
        if (this.params != null) {
            sb.append(this.params.toString());
        }
        if (this.fault != null) {
            sb.append(this.fault.toString());
        }
        sb.append("</methodResponse>");
        return sb.toString();
    }
}
