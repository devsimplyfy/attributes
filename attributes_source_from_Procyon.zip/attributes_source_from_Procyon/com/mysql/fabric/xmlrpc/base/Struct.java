// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.xmlrpc.base;

import java.util.ArrayList;
import java.util.List;

public class Struct
{
    protected List<Member> member;
    
    public List<Member> getMember() {
        if (this.member == null) {
            this.member = new ArrayList<Member>();
        }
        return this.member;
    }
    
    public void addMember(final Member m) {
        this.getMember().add(m);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        if (this.member != null) {
            sb.append("<struct>");
            for (int i = 0; i < this.member.size(); ++i) {
                sb.append(this.member.get(i).toString());
            }
            sb.append("</struct>");
        }
        return sb.toString();
    }
}
