// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.xmlrpc.base;

import java.util.ArrayList;
import java.util.List;

public class Data
{
    protected List<Value> value;
    
    public List<Value> getValue() {
        if (this.value == null) {
            this.value = new ArrayList<Value>();
        }
        return this.value;
    }
    
    public void addValue(final Value v) {
        this.getValue().add(v);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        if (this.value != null) {
            sb.append("<data>");
            for (int i = 0; i < this.value.size(); ++i) {
                sb.append(this.value.get(i).toString());
            }
            sb.append("</data>");
        }
        return sb.toString();
    }
}
