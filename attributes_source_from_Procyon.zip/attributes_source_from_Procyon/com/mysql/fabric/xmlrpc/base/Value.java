// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.xmlrpc.base;

import java.util.Arrays;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.datatype.DatatypeConfigurationException;
import java.util.GregorianCalendar;
import javax.xml.datatype.DatatypeFactory;

public class Value
{
    public static final byte TYPE_i4 = 0;
    public static final byte TYPE_int = 1;
    public static final byte TYPE_boolean = 2;
    public static final byte TYPE_string = 3;
    public static final byte TYPE_double = 4;
    public static final byte TYPE_dateTime_iso8601 = 5;
    public static final byte TYPE_base64 = 6;
    public static final byte TYPE_struct = 7;
    public static final byte TYPE_array = 8;
    protected Object objValue;
    protected byte objType;
    private DatatypeFactory dtf;
    
    public Value() {
        this.objValue = "";
        this.objType = 3;
        this.dtf = null;
    }
    
    public Value(final int value) {
        this.objValue = "";
        this.objType = 3;
        this.dtf = null;
        this.setInt(value);
    }
    
    public Value(final String value) {
        this.objValue = "";
        this.objType = 3;
        this.dtf = null;
        this.setString(value);
    }
    
    public Value(final boolean value) {
        this.objValue = "";
        this.objType = 3;
        this.dtf = null;
        this.setBoolean(value);
    }
    
    public Value(final double value) {
        this.objValue = "";
        this.objType = 3;
        this.dtf = null;
        this.setDouble(value);
    }
    
    public Value(final GregorianCalendar value) throws DatatypeConfigurationException {
        this.objValue = "";
        this.objType = 3;
        this.dtf = null;
        this.setDateTime(value);
    }
    
    public Value(final byte[] value) {
        this.objValue = "";
        this.objType = 3;
        this.dtf = null;
        this.setBase64(value);
    }
    
    public Value(final Struct value) {
        this.objValue = "";
        this.objType = 3;
        this.dtf = null;
        this.setStruct(value);
    }
    
    public Value(final Array value) {
        this.objValue = "";
        this.objType = 3;
        this.dtf = null;
        this.setArray(value);
    }
    
    public Object getValue() {
        return this.objValue;
    }
    
    public byte getType() {
        return this.objType;
    }
    
    public void setInt(final int value) {
        this.objValue = value;
        this.objType = 1;
    }
    
    public void setInt(final String value) {
        this.objValue = Integer.valueOf(value);
        this.objType = 1;
    }
    
    public void setString(final String value) {
        this.objValue = value;
        this.objType = 3;
    }
    
    public void appendString(final String value) {
        this.objValue = ((this.objValue != null) ? (this.objValue + value) : value);
        this.objType = 3;
    }
    
    public void setBoolean(final boolean value) {
        this.objValue = value;
        this.objType = 2;
    }
    
    public void setBoolean(final String value) {
        if (value.trim().equals("1") || value.trim().equalsIgnoreCase("true")) {
            this.objValue = true;
        }
        else {
            this.objValue = false;
        }
        this.objType = 2;
    }
    
    public void setDouble(final double value) {
        this.objValue = value;
        this.objType = 4;
    }
    
    public void setDouble(final String value) {
        this.objValue = Double.valueOf(value);
        this.objType = 4;
    }
    
    public void setDateTime(final GregorianCalendar value) throws DatatypeConfigurationException {
        if (this.dtf == null) {
            this.dtf = DatatypeFactory.newInstance();
        }
        this.objValue = this.dtf.newXMLGregorianCalendar(value);
        this.objType = 5;
    }
    
    public void setDateTime(final String value) throws DatatypeConfigurationException {
        if (this.dtf == null) {
            this.dtf = DatatypeFactory.newInstance();
        }
        this.objValue = this.dtf.newXMLGregorianCalendar(value);
        this.objType = 5;
    }
    
    public void setBase64(final byte[] value) {
        this.objValue = value;
        this.objType = 6;
    }
    
    public void setStruct(final Struct value) {
        this.objValue = value;
        this.objType = 7;
    }
    
    public void setArray(final Array value) {
        this.objValue = value;
        this.objType = 8;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("<value>");
        switch (this.objType) {
            case 0: {
                sb.append("<i4>" + ((Integer)this.objValue).toString() + "</i4>");
                break;
            }
            case 1: {
                sb.append("<int>" + ((Integer)this.objValue).toString() + "</int>");
                break;
            }
            case 2: {
                sb.append("<boolean>" + (((boolean)this.objValue) ? 1 : 0) + "</boolean>");
                break;
            }
            case 4: {
                sb.append("<double>" + ((Double)this.objValue).toString() + "</double>");
                break;
            }
            case 5: {
                sb.append("<dateTime.iso8601>" + ((XMLGregorianCalendar)this.objValue).toString() + "</dateTime.iso8601>");
                break;
            }
            case 6: {
                sb.append("<base64>" + Arrays.toString((byte[])this.objValue) + "</base64>");
                break;
            }
            case 7: {
                sb.append(((Struct)this.objValue).toString());
                break;
            }
            case 8: {
                sb.append(((Array)this.objValue).toString());
                break;
            }
            default: {
                sb.append("<string>" + this.escapeXMLChars(this.objValue.toString()) + "</string>");
                break;
            }
        }
        sb.append("</value>");
        return sb.toString();
    }
    
    private String escapeXMLChars(final String s) {
        final StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); ++i) {
            final char c = s.charAt(i);
            switch (c) {
                case '&': {
                    sb.append("&amp;");
                    break;
                }
                case '<': {
                    sb.append("&lt;");
                    break;
                }
                case '>': {
                    sb.append("&gt;");
                    break;
                }
                default: {
                    sb.append(c);
                    break;
                }
            }
        }
        return sb.toString();
    }
}
