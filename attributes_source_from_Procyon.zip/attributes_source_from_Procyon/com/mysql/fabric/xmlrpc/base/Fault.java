// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.xmlrpc.base;

public class Fault
{
    protected Value value;
    
    public Value getValue() {
        return this.value;
    }
    
    public void setValue(final Value value) {
        this.value = value;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        if (this.value != null) {
            sb.append("<fault>");
            sb.append(this.value.toString());
            sb.append("</fault>");
        }
        return sb.toString();
    }
}
