// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric;

import java.util.Collections;
import java.util.Set;

public abstract class ShardMapping
{
    private int mappingId;
    private ShardingType shardingType;
    private String globalGroupName;
    protected Set<ShardTable> shardTables;
    protected Set<ShardIndex> shardIndices;
    
    public ShardMapping(final int mappingId, final ShardingType shardingType, final String globalGroupName, final Set<ShardTable> shardTables, final Set<ShardIndex> shardIndices) {
        this.mappingId = mappingId;
        this.shardingType = shardingType;
        this.globalGroupName = globalGroupName;
        this.shardTables = shardTables;
        this.shardIndices = shardIndices;
    }
    
    public String getGroupNameForKey(final String key) {
        return this.getShardIndexForKey(key).getGroupName();
    }
    
    protected abstract ShardIndex getShardIndexForKey(final String p0);
    
    public int getMappingId() {
        return this.mappingId;
    }
    
    public ShardingType getShardingType() {
        return this.shardingType;
    }
    
    public String getGlobalGroupName() {
        return this.globalGroupName;
    }
    
    public Set<ShardTable> getShardTables() {
        return Collections.unmodifiableSet((Set<? extends ShardTable>)this.shardTables);
    }
    
    public Set<ShardIndex> getShardIndices() {
        return Collections.unmodifiableSet((Set<? extends ShardIndex>)this.shardIndices);
    }
}
