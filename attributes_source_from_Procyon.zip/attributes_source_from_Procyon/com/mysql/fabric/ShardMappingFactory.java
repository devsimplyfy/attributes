// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric;

import java.util.Set;

public class ShardMappingFactory
{
    public ShardMapping createShardMapping(final int mappingId, final ShardingType shardingType, final String globalGroupName, final Set<ShardTable> shardTables, final Set<ShardIndex> shardIndices) {
        ShardMapping sm = null;
        switch (shardingType) {
            case RANGE: {
                sm = new RangeShardMapping(mappingId, shardingType, globalGroupName, shardTables, shardIndices);
                break;
            }
            case HASH: {
                sm = new HashShardMapping(mappingId, shardingType, globalGroupName, shardTables, shardIndices);
                break;
            }
            default: {
                throw new IllegalArgumentException("Invalid ShardingType");
            }
        }
        return sm;
    }
}
