// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric;

public enum ServerRole
{
    FAULTY, 
    SPARE, 
    SECONDARY, 
    PRIMARY, 
    CONFIGURING;
    
    public static ServerRole getFromConstant(final Integer constant) {
        return values()[constant];
    }
}
