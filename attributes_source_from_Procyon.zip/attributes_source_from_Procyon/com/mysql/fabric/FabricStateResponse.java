// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric;

import java.util.concurrent.TimeUnit;

public class FabricStateResponse<T>
{
    private T data;
    private int secsTtl;
    private long expireTimeMillis;
    
    public FabricStateResponse(final T data, final int secsTtl) {
        this.data = data;
        this.secsTtl = secsTtl;
        this.expireTimeMillis = System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(secsTtl);
    }
    
    public FabricStateResponse(final T data, final int secsTtl, final long presetExpireTimeMillis) {
        this.data = data;
        this.secsTtl = secsTtl;
        this.expireTimeMillis = presetExpireTimeMillis;
    }
    
    public T getData() {
        return this.data;
    }
    
    public int getTtl() {
        return this.secsTtl;
    }
    
    public long getExpireTimeMillis() {
        return this.expireTimeMillis;
    }
}
