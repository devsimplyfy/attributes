// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.fabric.hibernate;

import java.util.Iterator;
import java.sql.SQLException;
import java.sql.DriverManager;
import com.mysql.fabric.ServerMode;
import com.mysql.fabric.Server;
import java.sql.Connection;
import com.mysql.fabric.FabricCommunicationException;
import com.mysql.fabric.ServerGroup;
import com.mysql.fabric.ShardMapping;
import com.mysql.fabric.FabricConnection;
import org.hibernate.service.jdbc.connections.spi.MultiTenantConnectionProvider;

public class FabricMultiTenantConnectionProvider implements MultiTenantConnectionProvider
{
    private static final long serialVersionUID = 1L;
    private FabricConnection fabricConnection;
    private String database;
    private String table;
    private String user;
    private String password;
    private ShardMapping shardMapping;
    private ServerGroup globalGroup;
    
    public FabricMultiTenantConnectionProvider(final String fabricUrl, final String database, final String table, final String user, final String password, final String fabricUser, final String fabricPassword) {
        try {
            this.fabricConnection = new FabricConnection(fabricUrl, fabricUser, fabricPassword);
            this.database = database;
            this.table = table;
            this.user = user;
            this.password = password;
            this.shardMapping = this.fabricConnection.getShardMapping(this.database, this.table);
            this.globalGroup = this.fabricConnection.getServerGroup(this.shardMapping.getGlobalGroupName());
        }
        catch (FabricCommunicationException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    private Connection getReadWriteConnectionFromServerGroup(final ServerGroup serverGroup) throws SQLException {
        for (final Server s : serverGroup.getServers()) {
            if (ServerMode.READ_WRITE.equals(s.getMode())) {
                final String jdbcUrl = String.format("jdbc:mysql://%s:%s/%s", s.getHostname(), s.getPort(), this.database);
                return DriverManager.getConnection(jdbcUrl, this.user, this.password);
            }
        }
        throw new SQLException("Unable to find r/w server for chosen shard mapping in group " + serverGroup.getName());
    }
    
    public Connection getAnyConnection() throws SQLException {
        return this.getReadWriteConnectionFromServerGroup(this.globalGroup);
    }
    
    public Connection getConnection(final String tenantIdentifier) throws SQLException {
        final String serverGroupName = this.shardMapping.getGroupNameForKey(tenantIdentifier);
        final ServerGroup serverGroup = this.fabricConnection.getServerGroup(serverGroupName);
        return this.getReadWriteConnectionFromServerGroup(serverGroup);
    }
    
    public void releaseAnyConnection(final Connection connection) throws SQLException {
        try {
            connection.close();
        }
        catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
    
    public void releaseConnection(final String tenantIdentifier, final Connection connection) throws SQLException {
        this.releaseAnyConnection(connection);
    }
    
    public boolean supportsAggressiveRelease() {
        return false;
    }
    
    public boolean isUnwrappableAs(final Class unwrapType) {
        return false;
    }
    
    public <T> T unwrap(final Class<T> unwrapType) {
        return null;
    }
}
