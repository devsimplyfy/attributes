// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import java.sql.SQLType;
import java.sql.SQLException;

public class JDBC42CallableStatement extends JDBC4CallableStatement
{
    public JDBC42CallableStatement(final MySQLConnection conn, final CallableStatementParamInfo paramInfo) throws SQLException {
        super(conn, paramInfo);
    }
    
    public JDBC42CallableStatement(final MySQLConnection conn, final String sql, final String catalog, final boolean isFunctionCall) throws SQLException {
        super(conn, sql, catalog, isFunctionCall);
    }
    
    private int checkSqlType(final int sqlType) throws SQLException {
        return JDBC42Helper.checkSqlType(sqlType, this.getExceptionInterceptor());
    }
    
    private int translateAndCheckSqlType(final SQLType sqlType) throws SQLException {
        return JDBC42Helper.translateAndCheckSqlType(sqlType, this.getExceptionInterceptor());
    }
    
    @Override
    public void registerOutParameter(final int parameterIndex, final SQLType sqlType) throws SQLException {
        super.registerOutParameter(parameterIndex, this.translateAndCheckSqlType(sqlType));
    }
    
    @Override
    public void registerOutParameter(final int parameterIndex, final SQLType sqlType, final int scale) throws SQLException {
        super.registerOutParameter(parameterIndex, this.translateAndCheckSqlType(sqlType), scale);
    }
    
    @Override
    public void registerOutParameter(final int parameterIndex, final SQLType sqlType, final String typeName) throws SQLException {
        super.registerOutParameter(parameterIndex, this.translateAndCheckSqlType(sqlType), typeName);
    }
    
    @Override
    public void registerOutParameter(final String parameterName, final SQLType sqlType) throws SQLException {
        super.registerOutParameter(parameterName, this.translateAndCheckSqlType(sqlType));
    }
    
    @Override
    public void registerOutParameter(final String parameterName, final SQLType sqlType, final int scale) throws SQLException {
        super.registerOutParameter(parameterName, this.translateAndCheckSqlType(sqlType), scale);
    }
    
    @Override
    public void registerOutParameter(final String parameterName, final SQLType sqlType, final String typeName) throws SQLException {
        super.registerOutParameter(parameterName, this.translateAndCheckSqlType(sqlType), typeName);
    }
    
    @Override
    public void setObject(final int parameterIndex, final Object x) throws SQLException {
        synchronized (this.checkClosed().getConnectionMutex()) {
            super.setObject(parameterIndex, JDBC42Helper.convertJavaTimeToJavaSql(x));
        }
    }
    
    @Override
    public void setObject(final int parameterIndex, final Object x, final int targetSqlType) throws SQLException {
        synchronized (this.checkClosed().getConnectionMutex()) {
            super.setObject(parameterIndex, JDBC42Helper.convertJavaTimeToJavaSql(x), this.checkSqlType(targetSqlType));
        }
    }
    
    @Override
    public void setObject(final int parameterIndex, final Object x, final int targetSqlType, final int scaleOrLength) throws SQLException {
        synchronized (this.checkClosed().getConnectionMutex()) {
            super.setObject(parameterIndex, JDBC42Helper.convertJavaTimeToJavaSql(x), this.checkSqlType(targetSqlType), scaleOrLength);
        }
    }
    
    @Override
    public void setObject(final int parameterIndex, final Object x, final SQLType targetSqlType) throws SQLException {
        synchronized (this.checkClosed().getConnectionMutex()) {
            super.setObject(parameterIndex, JDBC42Helper.convertJavaTimeToJavaSql(x), this.translateAndCheckSqlType(targetSqlType));
        }
    }
    
    @Override
    public void setObject(final int parameterIndex, final Object x, final SQLType targetSqlType, final int scaleOrLength) throws SQLException {
        synchronized (this.checkClosed().getConnectionMutex()) {
            super.setObject(parameterIndex, JDBC42Helper.convertJavaTimeToJavaSql(x), this.translateAndCheckSqlType(targetSqlType), scaleOrLength);
        }
    }
    
    @Override
    public void setObject(final String parameterName, final Object x, final SQLType targetSqlType) throws SQLException {
        synchronized (this.checkClosed().getConnectionMutex()) {
            super.setObject(parameterName, JDBC42Helper.convertJavaTimeToJavaSql(x), this.translateAndCheckSqlType(targetSqlType));
        }
    }
    
    @Override
    public void setObject(final String parameterName, final Object x, final SQLType targetSqlType, final int scaleOrLength) throws SQLException {
        synchronized (this.checkClosed().getConnectionMutex()) {
            super.setObject(parameterName, JDBC42Helper.convertJavaTimeToJavaSql(x), this.translateAndCheckSqlType(targetSqlType), scaleOrLength);
        }
    }
}
