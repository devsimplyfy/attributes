// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc.util;

import java.sql.SQLException;
import com.mysql.jdbc.ConnectionPropertiesImpl;

public class PropertiesDocGenerator extends ConnectionPropertiesImpl
{
    static final long serialVersionUID = -4869689139143855383L;
    
    public static void main(final String[] args) throws SQLException {
        System.out.println(new PropertiesDocGenerator().exposeAsXml());
    }
}
