// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.lang.ref.Reference;
import java.util.concurrent.ExecutorService;

public class AbandonedConnectionCleanupThread implements Runnable
{
    private static final ExecutorService cleanupThreadExcecutorService;
    static Thread threadRef;
    
    private AbandonedConnectionCleanupThread() {
    }
    
    public void run() {
        while (true) {
            try {
                while (true) {
                    this.checkContextClassLoaders();
                    final Reference<? extends ConnectionImpl> ref = NonRegisteringDriver.refQueue.remove(5000L);
                    if (ref != null) {
                        try {
                            ((NonRegisteringDriver.ConnectionPhantomReference)ref).cleanup();
                        }
                        finally {
                            NonRegisteringDriver.connectionPhantomRefs.remove(ref);
                        }
                    }
                }
            }
            catch (InterruptedException e) {
                AbandonedConnectionCleanupThread.threadRef = null;
            }
            catch (Exception ex) {
                continue;
            }
            break;
        }
    }
    
    private void checkContextClassLoaders() {
        try {
            AbandonedConnectionCleanupThread.threadRef.getContextClassLoader().getResource("");
        }
        catch (Throwable e) {
            uncheckedShutdown();
        }
    }
    
    private static boolean consistentClassLoaders() {
        final ClassLoader callerCtxClassLoader = Thread.currentThread().getContextClassLoader();
        final ClassLoader threadCtxClassLoader = AbandonedConnectionCleanupThread.threadRef.getContextClassLoader();
        return callerCtxClassLoader != null && threadCtxClassLoader != null && callerCtxClassLoader == threadCtxClassLoader;
    }
    
    public static void checkedShutdown() {
        shutdown(true);
    }
    
    public static void uncheckedShutdown() {
        shutdown(false);
    }
    
    private static void shutdown(final boolean checked) {
        if (checked && !consistentClassLoaders()) {
            return;
        }
        AbandonedConnectionCleanupThread.cleanupThreadExcecutorService.shutdownNow();
    }
    
    @Deprecated
    public static void shutdown() {
        checkedShutdown();
    }
    
    static {
        AbandonedConnectionCleanupThread.threadRef = null;
        (cleanupThreadExcecutorService = Executors.newSingleThreadExecutor(new ThreadFactory() {
            public Thread newThread(final Runnable r) {
                final Thread t = new Thread(r, "Abandoned connection cleanup thread");
                t.setDaemon(true);
                t.setContextClassLoader(AbandonedConnectionCleanupThread.class.getClassLoader());
                return AbandonedConnectionCleanupThread.threadRef = t;
            }
        })).execute(new AbandonedConnectionCleanupThread());
    }
}
