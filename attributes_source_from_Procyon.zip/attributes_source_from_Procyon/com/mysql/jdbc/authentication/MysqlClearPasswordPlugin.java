// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc.authentication;

import java.io.UnsupportedEncodingException;
import com.mysql.jdbc.ExceptionInterceptor;
import com.mysql.jdbc.SQLError;
import com.mysql.jdbc.Messages;
import com.mysql.jdbc.StringUtils;
import java.util.List;
import com.mysql.jdbc.Buffer;
import java.sql.SQLException;
import java.util.Properties;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.AuthenticationPlugin;

public class MysqlClearPasswordPlugin implements AuthenticationPlugin
{
    private Connection connection;
    private String password;
    
    public MysqlClearPasswordPlugin() {
        this.password = null;
    }
    
    public void init(final Connection conn, final Properties props) throws SQLException {
        this.connection = conn;
    }
    
    public void destroy() {
        this.password = null;
    }
    
    public String getProtocolPluginName() {
        return "mysql_clear_password";
    }
    
    public boolean requiresConfidentiality() {
        return true;
    }
    
    public boolean isReusable() {
        return true;
    }
    
    public void setAuthenticationParameters(final String user, final String password) {
        this.password = password;
    }
    
    public boolean nextAuthenticationStep(final Buffer fromServer, final List<Buffer> toServer) throws SQLException {
        toServer.clear();
        Buffer bresp;
        try {
            final String encoding = this.connection.versionMeetsMinimum(5, 7, 6) ? this.connection.getPasswordCharacterEncoding() : "UTF-8";
            bresp = new Buffer(StringUtils.getBytes((this.password != null) ? this.password : "", encoding));
        }
        catch (UnsupportedEncodingException e) {
            throw SQLError.createSQLException(Messages.getString("MysqlClearPasswordPlugin.1", new Object[] { this.connection.getPasswordCharacterEncoding() }), "S1000", null);
        }
        bresp.setPosition(bresp.getBufLength());
        final int oldBufLength = bresp.getBufLength();
        bresp.writeByte((byte)0);
        bresp.setBufLength(oldBufLength + 1);
        bresp.setPosition(0);
        toServer.add(bresp);
        return true;
    }
}
