// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc.log;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public class Slf4JLogger implements Log
{
    private Logger log;
    
    public Slf4JLogger(final String name) {
        this.log = LoggerFactory.getLogger(name);
    }
    
    public boolean isDebugEnabled() {
        return this.log.isDebugEnabled();
    }
    
    public boolean isErrorEnabled() {
        return this.log.isErrorEnabled();
    }
    
    public boolean isFatalEnabled() {
        return this.log.isErrorEnabled();
    }
    
    public boolean isInfoEnabled() {
        return this.log.isInfoEnabled();
    }
    
    public boolean isTraceEnabled() {
        return this.log.isTraceEnabled();
    }
    
    public boolean isWarnEnabled() {
        return this.log.isWarnEnabled();
    }
    
    public void logDebug(final Object msg) {
        this.log.debug(msg.toString());
    }
    
    public void logDebug(final Object msg, final Throwable thrown) {
        this.log.debug(msg.toString(), thrown);
    }
    
    public void logError(final Object msg) {
        this.log.error(msg.toString());
    }
    
    public void logError(final Object msg, final Throwable thrown) {
        this.log.error(msg.toString(), thrown);
    }
    
    public void logFatal(final Object msg) {
        this.log.error(msg.toString());
    }
    
    public void logFatal(final Object msg, final Throwable thrown) {
        this.log.error(msg.toString(), thrown);
    }
    
    public void logInfo(final Object msg) {
        this.log.info(msg.toString());
    }
    
    public void logInfo(final Object msg, final Throwable thrown) {
        this.log.info(msg.toString(), thrown);
    }
    
    public void logTrace(final Object msg) {
        this.log.trace(msg.toString());
    }
    
    public void logTrace(final Object msg, final Throwable thrown) {
        this.log.trace(msg.toString(), thrown);
    }
    
    public void logWarn(final Object msg) {
        this.log.warn(msg.toString());
    }
    
    public void logWarn(final Object msg, final Throwable thrown) {
        this.log.warn(msg.toString(), thrown);
    }
}
