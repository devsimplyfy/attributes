// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import java.sql.SQLType;
import java.sql.SQLException;

public class JDBC42ServerPreparedStatement extends JDBC4ServerPreparedStatement
{
    public JDBC42ServerPreparedStatement(final MySQLConnection conn, final String sql, final String catalog, final int resultSetType, final int resultSetConcurrency) throws SQLException {
        super(conn, sql, catalog, resultSetType, resultSetConcurrency);
    }
    
    private int checkSqlType(final int sqlType) throws SQLException {
        return JDBC42Helper.checkSqlType(sqlType, this.getExceptionInterceptor());
    }
    
    private int translateAndCheckSqlType(final SQLType sqlType) throws SQLException {
        return JDBC42Helper.translateAndCheckSqlType(sqlType, this.getExceptionInterceptor());
    }
    
    @Override
    public void setObject(final int parameterIndex, final Object x) throws SQLException {
        synchronized (this.checkClosed().getConnectionMutex()) {
            super.setObject(parameterIndex, JDBC42Helper.convertJavaTimeToJavaSql(x));
        }
    }
    
    @Override
    public void setObject(final int parameterIndex, final Object x, final int targetSqlType) throws SQLException {
        synchronized (this.checkClosed().getConnectionMutex()) {
            super.setObject(parameterIndex, JDBC42Helper.convertJavaTimeToJavaSql(x), this.checkSqlType(targetSqlType));
        }
    }
    
    @Override
    public void setObject(final int parameterIndex, final Object x, final int targetSqlType, final int scaleOrLength) throws SQLException {
        synchronized (this.checkClosed().getConnectionMutex()) {
            super.setObject(parameterIndex, JDBC42Helper.convertJavaTimeToJavaSql(x), this.checkSqlType(targetSqlType), scaleOrLength);
        }
    }
    
    @Override
    public void setObject(final int parameterIndex, final Object x, final SQLType targetSqlType) throws SQLException {
        synchronized (this.checkClosed().getConnectionMutex()) {
            super.setObject(parameterIndex, JDBC42Helper.convertJavaTimeToJavaSql(x), this.translateAndCheckSqlType(targetSqlType));
        }
    }
    
    @Override
    public void setObject(final int parameterIndex, final Object x, final SQLType targetSqlType, final int scaleOrLength) throws SQLException {
        synchronized (this.checkClosed().getConnectionMutex()) {
            super.setObject(parameterIndex, JDBC42Helper.convertJavaTimeToJavaSql(x), this.translateAndCheckSqlType(targetSqlType), scaleOrLength);
        }
    }
}
