// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc.jdbc2.optional;

import java.sql.SQLException;
import java.sql.Connection;
import javax.sql.XAConnection;
import javax.sql.XADataSource;

public class MysqlXADataSource extends MysqlDataSource implements XADataSource
{
    static final long serialVersionUID = 7911390333152247455L;
    
    public XAConnection getXAConnection() throws SQLException {
        final Connection conn = this.getConnection();
        return this.wrapConnection(conn);
    }
    
    public XAConnection getXAConnection(final String u, final String p) throws SQLException {
        final Connection conn = this.getConnection(u, p);
        return this.wrapConnection(conn);
    }
    
    private XAConnection wrapConnection(final Connection conn) throws SQLException {
        if (this.getPinGlobalTxToPhysicalConnection() || ((com.mysql.jdbc.Connection)conn).getPinGlobalTxToPhysicalConnection()) {
            return SuspendableXAConnection.getInstance((com.mysql.jdbc.Connection)conn);
        }
        return MysqlXAConnection.getInstance((com.mysql.jdbc.Connection)conn, this.getLogXaCommands());
    }
}
