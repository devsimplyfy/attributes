// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import java.time.OffsetTime;
import java.time.format.DateTimeParseException;
import java.time.OffsetDateTime;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.LocalDate;
import java.sql.SQLType;
import java.sql.SQLException;

public class JDBC42UpdatableResultSet extends JDBC4UpdatableResultSet
{
    public JDBC42UpdatableResultSet(final String catalog, final Field[] fields, final RowData tuples, final MySQLConnection conn, final StatementImpl creatorStmt) throws SQLException {
        super(catalog, fields, tuples, conn, creatorStmt);
    }
    
    private int translateAndCheckSqlType(final SQLType sqlType) throws SQLException {
        return JDBC42Helper.translateAndCheckSqlType(sqlType, this.getExceptionInterceptor());
    }
    
    @Override
    public <T> T getObject(final int columnIndex, final Class<T> type) throws SQLException {
        synchronized (this.checkClosed().getConnectionMutex()) {
            if (type == null) {
                throw SQLError.createSQLException("Type parameter can not be null", "S1009", this.getExceptionInterceptor());
            }
            if (type.equals(LocalDate.class)) {
                return type.cast(this.getDate(columnIndex).toLocalDate());
            }
            if (type.equals(LocalDateTime.class)) {
                return type.cast(this.getTimestamp(columnIndex).toLocalDateTime());
            }
            if (type.equals(LocalTime.class)) {
                return type.cast(this.getTime(columnIndex).toLocalTime());
            }
            if (type.equals(OffsetDateTime.class)) {
                try {
                    return type.cast(OffsetDateTime.parse(this.getString(columnIndex)));
                }
                catch (DateTimeParseException ex) {
                    return super.getObject(columnIndex, type);
                }
            }
            if (type.equals(OffsetTime.class)) {
                try {
                    return type.cast(OffsetTime.parse(this.getString(columnIndex)));
                }
                catch (DateTimeParseException ex2) {}
            }
            return super.getObject(columnIndex, type);
        }
    }
    
    @Override
    public void updateObject(final int columnIndex, final Object x) throws SQLException {
        super.updateObject(columnIndex, JDBC42Helper.convertJavaTimeToJavaSql(x));
    }
    
    @Override
    public void updateObject(final int columnIndex, final Object x, final int scaleOrLength) throws SQLException {
        super.updateObject(columnIndex, JDBC42Helper.convertJavaTimeToJavaSql(x), scaleOrLength);
    }
    
    @Override
    public void updateObject(final String columnLabel, final Object x) throws SQLException {
        super.updateObject(columnLabel, JDBC42Helper.convertJavaTimeToJavaSql(x));
    }
    
    @Override
    public void updateObject(final String columnLabel, final Object x, final int scaleOrLength) throws SQLException {
        super.updateObject(columnLabel, JDBC42Helper.convertJavaTimeToJavaSql(x), scaleOrLength);
    }
    
    @Override
    public void updateObject(final int columnIndex, final Object x, final SQLType targetSqlType) throws SQLException {
        super.updateObjectInternal(columnIndex, JDBC42Helper.convertJavaTimeToJavaSql(x), this.translateAndCheckSqlType(targetSqlType), 0);
    }
    
    @Override
    public void updateObject(final int columnIndex, final Object x, final SQLType targetSqlType, final int scaleOrLength) throws SQLException {
        super.updateObjectInternal(columnIndex, JDBC42Helper.convertJavaTimeToJavaSql(x), this.translateAndCheckSqlType(targetSqlType), scaleOrLength);
    }
    
    @Override
    public void updateObject(final String columnLabel, final Object x, final SQLType targetSqlType) throws SQLException {
        super.updateObjectInternal(this.findColumn(columnLabel), JDBC42Helper.convertJavaTimeToJavaSql(x), this.translateAndCheckSqlType(targetSqlType), 0);
    }
    
    @Override
    public void updateObject(final String columnLabel, final Object x, final SQLType targetSqlType, final int scaleOrLength) throws SQLException {
        super.updateObjectInternal(this.findColumn(columnLabel), JDBC42Helper.convertJavaTimeToJavaSql(x), this.translateAndCheckSqlType(targetSqlType), scaleOrLength);
    }
}
