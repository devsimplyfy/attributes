// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import java.security.cert.CertPathValidatorResult;
import java.security.cert.CertPath;
import java.security.cert.CertPathValidatorException;
import java.security.InvalidAlgorithmParameterException;
import java.security.cert.PKIXCertPathValidatorResult;
import java.security.cert.CertPathParameters;
import java.security.cert.Certificate;
import java.security.cert.X509CertSelector;
import java.security.cert.X509Certificate;
import java.util.Set;
import java.security.cert.TrustAnchor;
import java.util.HashSet;
import java.security.cert.CertPathValidator;
import java.security.cert.PKIXParameters;
import java.security.cert.CertificateFactory;
import java.net.SocketException;
import java.net.Socket;
import java.security.Key;
import javax.crypto.Cipher;
import java.security.spec.KeySpec;
import java.security.KeyFactory;
import java.security.spec.X509EncodedKeySpec;
import com.mysql.jdbc.util.Base64Decoder;
import java.security.interfaces.RSAPublicKey;
import java.io.InputStream;
import javax.net.ssl.KeyManager;
import java.security.KeyManagementException;
import java.security.SecureRandom;
import javax.net.ssl.SSLContext;
import javax.net.ssl.X509TrustManager;
import java.security.cert.CertificateException;
import java.security.KeyStoreException;
import java.security.UnrecoverableKeyException;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.TrustManager;
import java.net.MalformedURLException;
import java.net.URL;
import javax.net.ssl.SSLSocketFactory;
import java.sql.SQLException;
import java.util.List;
import java.io.IOException;
import java.io.BufferedOutputStream;
import java.io.BufferedInputStream;
import javax.net.ssl.SSLSocket;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;

public class ExportControlled
{
    private static final String SQL_STATE_BAD_SSL_PARAMS = "08000";
    private static final String TLSv1 = "TLSv1";
    private static final String TLSv1_1 = "TLSv1.1";
    private static final String TLSv1_2 = "TLSv1.2";
    private static final String[] TLS_PROTOCOLS;
    
    protected static boolean enabled() {
        return true;
    }
    
    protected static void transformSocketToSSLSocket(final MysqlIO mysqlIO) throws SQLException {
        final SocketFactory sslFact = new StandardSSLSocketFactory(getSSLSocketFactoryDefaultOrConfigured(mysqlIO), mysqlIO.socketFactory, mysqlIO.mysqlConnection);
        try {
            mysqlIO.mysqlConnection = sslFact.connect(mysqlIO.host, mysqlIO.port, null);
            String[] tryProtocols = null;
            final String enabledTLSProtocols = mysqlIO.connection.getEnabledTLSProtocols();
            if (enabledTLSProtocols != null && enabledTLSProtocols.length() > 0) {
                tryProtocols = enabledTLSProtocols.split("\\s*,\\s*");
            }
            else if (mysqlIO.versionMeetsMinimum(5, 6, 0) && Util.isEnterpriseEdition(mysqlIO.getServerVersion())) {
                tryProtocols = new String[] { "TLSv1.2", "TLSv1.1", "TLSv1" };
            }
            if (tryProtocols == null) {
                tryProtocols = new String[] { "TLSv1.1", "TLSv1" };
            }
            final List<String> configuredProtocols = new ArrayList<String>(Arrays.asList(tryProtocols));
            final List<String> jvmSupportedProtocols = Arrays.asList(((SSLSocket)mysqlIO.mysqlConnection).getSupportedProtocols());
            final List<String> allowedProtocols = new ArrayList<String>();
            for (final String protocol : ExportControlled.TLS_PROTOCOLS) {
                if (jvmSupportedProtocols.contains(protocol) && configuredProtocols.contains(protocol)) {
                    allowedProtocols.add(protocol);
                }
            }
            ((SSLSocket)mysqlIO.mysqlConnection).setEnabledProtocols(allowedProtocols.toArray(new String[0]));
            final String enabledSSLCipherSuites = mysqlIO.connection.getEnabledSSLCipherSuites();
            final boolean overrideCiphers = enabledSSLCipherSuites != null && enabledSSLCipherSuites.length() > 0;
            List<String> allowedCiphers = null;
            if (overrideCiphers) {
                allowedCiphers = new ArrayList<String>();
                final List<String> availableCiphers = Arrays.asList(((SSLSocket)mysqlIO.mysqlConnection).getEnabledCipherSuites());
                for (final String cipher : enabledSSLCipherSuites.split("\\s*,\\s*")) {
                    if (availableCiphers.contains(cipher)) {
                        allowedCiphers.add(cipher);
                    }
                }
            }
            else {
                boolean disableDHAlgorithm = false;
                if ((mysqlIO.versionMeetsMinimum(5, 5, 45) && !mysqlIO.versionMeetsMinimum(5, 6, 0)) || (mysqlIO.versionMeetsMinimum(5, 6, 26) && !mysqlIO.versionMeetsMinimum(5, 7, 0)) || mysqlIO.versionMeetsMinimum(5, 7, 6)) {
                    if (Util.getJVMVersion() < 8) {
                        disableDHAlgorithm = true;
                    }
                }
                else if (Util.getJVMVersion() >= 8) {
                    disableDHAlgorithm = true;
                }
                if (disableDHAlgorithm) {
                    allowedCiphers = new ArrayList<String>();
                    for (final String cipher : ((SSLSocket)mysqlIO.mysqlConnection).getEnabledCipherSuites()) {
                        if (!disableDHAlgorithm || (cipher.indexOf("_DHE_") <= -1 && cipher.indexOf("_DH_") <= -1)) {
                            allowedCiphers.add(cipher);
                        }
                    }
                }
            }
            if (allowedCiphers != null) {
                ((SSLSocket)mysqlIO.mysqlConnection).setEnabledCipherSuites(allowedCiphers.toArray(new String[0]));
            }
            ((SSLSocket)mysqlIO.mysqlConnection).startHandshake();
            if (mysqlIO.connection.getUseUnbufferedInput()) {
                mysqlIO.mysqlInput = mysqlIO.mysqlConnection.getInputStream();
            }
            else {
                mysqlIO.mysqlInput = new BufferedInputStream(mysqlIO.mysqlConnection.getInputStream(), 16384);
            }
            (mysqlIO.mysqlOutput = new BufferedOutputStream(mysqlIO.mysqlConnection.getOutputStream(), 16384)).flush();
            mysqlIO.socketFactory = sslFact;
        }
        catch (IOException ioEx) {
            throw SQLError.createCommunicationsException(mysqlIO.connection, mysqlIO.getLastPacketSentTimeMs(), mysqlIO.getLastPacketReceivedTimeMs(), ioEx, mysqlIO.getExceptionInterceptor());
        }
    }
    
    private ExportControlled() {
    }
    
    private static SSLSocketFactory getSSLSocketFactoryDefaultOrConfigured(final MysqlIO mysqlIO) throws SQLException {
        String clientCertificateKeyStoreUrl = mysqlIO.connection.getClientCertificateKeyStoreUrl();
        String clientCertificateKeyStorePassword = mysqlIO.connection.getClientCertificateKeyStorePassword();
        String clientCertificateKeyStoreType = mysqlIO.connection.getClientCertificateKeyStoreType();
        String trustCertificateKeyStoreUrl = mysqlIO.connection.getTrustCertificateKeyStoreUrl();
        String trustCertificateKeyStorePassword = mysqlIO.connection.getTrustCertificateKeyStorePassword();
        String trustCertificateKeyStoreType = mysqlIO.connection.getTrustCertificateKeyStoreType();
        if (StringUtils.isNullOrEmpty(clientCertificateKeyStoreUrl)) {
            clientCertificateKeyStoreUrl = System.getProperty("javax.net.ssl.keyStore");
            clientCertificateKeyStorePassword = System.getProperty("javax.net.ssl.keyStorePassword");
            clientCertificateKeyStoreType = System.getProperty("javax.net.ssl.keyStoreType");
            if (StringUtils.isNullOrEmpty(clientCertificateKeyStoreType)) {
                clientCertificateKeyStoreType = "JKS";
            }
            if (!StringUtils.isNullOrEmpty(clientCertificateKeyStoreUrl)) {
                try {
                    new URL(clientCertificateKeyStoreUrl);
                }
                catch (MalformedURLException e4) {
                    clientCertificateKeyStoreUrl = "file:" + clientCertificateKeyStoreUrl;
                }
            }
        }
        if (StringUtils.isNullOrEmpty(trustCertificateKeyStoreUrl)) {
            trustCertificateKeyStoreUrl = System.getProperty("javax.net.ssl.trustStore");
            trustCertificateKeyStorePassword = System.getProperty("javax.net.ssl.trustStorePassword");
            trustCertificateKeyStoreType = System.getProperty("javax.net.ssl.trustStoreType");
            if (StringUtils.isNullOrEmpty(trustCertificateKeyStoreType)) {
                trustCertificateKeyStoreType = "JKS";
            }
            if (!StringUtils.isNullOrEmpty(trustCertificateKeyStoreUrl)) {
                try {
                    new URL(trustCertificateKeyStoreUrl);
                }
                catch (MalformedURLException e4) {
                    trustCertificateKeyStoreUrl = "file:" + trustCertificateKeyStoreUrl;
                }
            }
        }
        TrustManagerFactory tmf = null;
        KeyManagerFactory kmf = null;
        KeyManager[] kms = null;
        final List<TrustManager> tms = new ArrayList<TrustManager>();
        try {
            tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        }
        catch (NoSuchAlgorithmException nsae2) {
            throw SQLError.createSQLException("Default algorithm definitions for TrustManager and/or KeyManager are invalid.  Check java security properties file.", "08000", 0, false, mysqlIO.getExceptionInterceptor());
        }
        if (!StringUtils.isNullOrEmpty(clientCertificateKeyStoreUrl)) {
            InputStream ksIS = null;
            try {
                if (!StringUtils.isNullOrEmpty(clientCertificateKeyStoreType)) {
                    final KeyStore clientKeyStore = KeyStore.getInstance(clientCertificateKeyStoreType);
                    final URL ksURL = new URL(clientCertificateKeyStoreUrl);
                    final char[] password = (clientCertificateKeyStorePassword == null) ? new char[0] : clientCertificateKeyStorePassword.toCharArray();
                    ksIS = ksURL.openStream();
                    clientKeyStore.load(ksIS, password);
                    kmf.init(clientKeyStore, password);
                    kms = kmf.getKeyManagers();
                }
            }
            catch (UnrecoverableKeyException uke) {
                throw SQLError.createSQLException("Could not recover keys from client keystore.  Check password?", "08000", 0, false, mysqlIO.getExceptionInterceptor());
            }
            catch (NoSuchAlgorithmException nsae) {
                throw SQLError.createSQLException("Unsupported keystore algorithm [" + nsae.getMessage() + "]", "08000", 0, false, mysqlIO.getExceptionInterceptor());
            }
            catch (KeyStoreException kse) {
                throw SQLError.createSQLException("Could not create KeyStore instance [" + kse.getMessage() + "]", "08000", 0, false, mysqlIO.getExceptionInterceptor());
            }
            catch (CertificateException nsae3) {
                throw SQLError.createSQLException("Could not load client" + clientCertificateKeyStoreType + " keystore from " + clientCertificateKeyStoreUrl, mysqlIO.getExceptionInterceptor());
            }
            catch (MalformedURLException mue) {
                throw SQLError.createSQLException(clientCertificateKeyStoreUrl + " does not appear to be a valid URL.", "08000", 0, false, mysqlIO.getExceptionInterceptor());
            }
            catch (IOException ioe) {
                final SQLException sqlEx = SQLError.createSQLException("Cannot open " + clientCertificateKeyStoreUrl + " [" + ioe.getMessage() + "]", "08000", 0, false, mysqlIO.getExceptionInterceptor());
                sqlEx.initCause(ioe);
                throw sqlEx;
            }
            finally {
                if (ksIS != null) {
                    try {
                        ksIS.close();
                    }
                    catch (IOException ex) {}
                }
            }
        }
        InputStream trustStoreIS = null;
        try {
            KeyStore trustKeyStore = null;
            if (!StringUtils.isNullOrEmpty(trustCertificateKeyStoreUrl) && !StringUtils.isNullOrEmpty(trustCertificateKeyStoreType)) {
                trustStoreIS = new URL(trustCertificateKeyStoreUrl).openStream();
                final char[] trustStorePassword = (trustCertificateKeyStorePassword == null) ? new char[0] : trustCertificateKeyStorePassword.toCharArray();
                trustKeyStore = KeyStore.getInstance(trustCertificateKeyStoreType);
                trustKeyStore.load(trustStoreIS, trustStorePassword);
            }
            tmf.init(trustKeyStore);
            final TrustManager[] origTms = tmf.getTrustManagers();
            final boolean verifyServerCert = mysqlIO.connection.getVerifyServerCertificate();
            for (final TrustManager tm : origTms) {
                tms.add((tm instanceof X509TrustManager) ? new X509TrustManagerWrapper((X509TrustManager)tm, verifyServerCert) : tm);
            }
        }
        catch (MalformedURLException e5) {
            throw SQLError.createSQLException(trustCertificateKeyStoreUrl + " does not appear to be a valid URL.", "08000", 0, false, mysqlIO.getExceptionInterceptor());
        }
        catch (KeyStoreException e) {
            throw SQLError.createSQLException("Could not create KeyStore instance [" + e.getMessage() + "]", "08000", 0, false, mysqlIO.getExceptionInterceptor());
        }
        catch (NoSuchAlgorithmException e2) {
            throw SQLError.createSQLException("Unsupported keystore algorithm [" + e2.getMessage() + "]", "08000", 0, false, mysqlIO.getExceptionInterceptor());
        }
        catch (CertificateException e6) {
            throw SQLError.createSQLException("Could not load trust" + trustCertificateKeyStoreType + " keystore from " + trustCertificateKeyStoreUrl, "08000", 0, false, mysqlIO.getExceptionInterceptor());
        }
        catch (IOException e3) {
            final SQLException sqlEx = SQLError.createSQLException("Cannot open " + trustCertificateKeyStoreType + " [" + e3.getMessage() + "]", "08000", 0, false, mysqlIO.getExceptionInterceptor());
            sqlEx.initCause(e3);
            throw sqlEx;
        }
        finally {
            if (trustStoreIS != null) {
                try {
                    trustStoreIS.close();
                }
                catch (IOException ex2) {}
            }
        }
        if (tms.size() == 0) {
            tms.add(new X509TrustManagerWrapper());
        }
        try {
            final SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(kms, tms.toArray(new TrustManager[tms.size()]), null);
            return sslContext.getSocketFactory();
        }
        catch (NoSuchAlgorithmException nsae) {
            throw SQLError.createSQLException("TLS is not a valid SSL protocol.", "08000", 0, false, mysqlIO.getExceptionInterceptor());
        }
        catch (KeyManagementException kme) {
            throw SQLError.createSQLException("KeyManagementException: " + kme.getMessage(), "08000", 0, false, mysqlIO.getExceptionInterceptor());
        }
    }
    
    public static boolean isSSLEstablished(final MysqlIO mysqlIO) {
        return SSLSocket.class.isAssignableFrom(mysqlIO.mysqlConnection.getClass());
    }
    
    public static RSAPublicKey decodeRSAPublicKey(final String key, final ExceptionInterceptor interceptor) throws SQLException {
        try {
            if (key == null) {
                throw new SQLException("key parameter is null");
            }
            final int offset = key.indexOf("\n") + 1;
            final int len = key.indexOf("-----END PUBLIC KEY-----") - offset;
            final byte[] certificateData = Base64Decoder.decode(key.getBytes(), offset, len);
            final X509EncodedKeySpec spec = new X509EncodedKeySpec(certificateData);
            final KeyFactory kf = KeyFactory.getInstance("RSA");
            return (RSAPublicKey)kf.generatePublic(spec);
        }
        catch (Exception ex) {
            throw SQLError.createSQLException("Unable to decode public key", "S1009", ex, interceptor);
        }
    }
    
    public static byte[] encryptWithRSAPublicKey(final byte[] source, final RSAPublicKey key, final ExceptionInterceptor interceptor) throws SQLException {
        try {
            final Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-1AndMGF1Padding");
            cipher.init(1, key);
            return cipher.doFinal(source);
        }
        catch (Exception ex) {
            throw SQLError.createSQLException(ex.getMessage(), "S1009", ex, interceptor);
        }
    }
    
    static {
        TLS_PROTOCOLS = new String[] { "TLSv1.2", "TLSv1.1", "TLSv1" };
    }
    
    public static class StandardSSLSocketFactory implements SocketFactory, SocketMetadata
    {
        private SSLSocket rawSocket;
        private final SSLSocketFactory sslFact;
        private final SocketFactory existingSocketFactory;
        private final Socket existingSocket;
        
        public StandardSSLSocketFactory(final SSLSocketFactory sslFact, final SocketFactory existingSocketFactory, final Socket existingSocket) {
            this.rawSocket = null;
            this.sslFact = sslFact;
            this.existingSocketFactory = existingSocketFactory;
            this.existingSocket = existingSocket;
        }
        
        public Socket afterHandshake() throws SocketException, IOException {
            this.existingSocketFactory.afterHandshake();
            return this.rawSocket;
        }
        
        public Socket beforeHandshake() throws SocketException, IOException {
            return this.rawSocket;
        }
        
        public Socket connect(final String host, final int portNumber, final Properties props) throws SocketException, IOException {
            return this.rawSocket = (SSLSocket)this.sslFact.createSocket(this.existingSocket, host, portNumber, true);
        }
        
        public boolean isLocallyConnected(final ConnectionImpl conn) throws SQLException {
            return Helper.isLocallyConnected(conn);
        }
    }
    
    public static class X509TrustManagerWrapper implements X509TrustManager
    {
        private X509TrustManager origTm;
        private boolean verifyServerCert;
        private CertificateFactory certFactory;
        private PKIXParameters validatorParams;
        private CertPathValidator validator;
        
        public X509TrustManagerWrapper(final X509TrustManager tm, final boolean verifyServerCertificate) throws CertificateException {
            this.origTm = null;
            this.verifyServerCert = false;
            this.certFactory = null;
            this.validatorParams = null;
            this.validator = null;
            this.origTm = tm;
            this.verifyServerCert = verifyServerCertificate;
            if (verifyServerCertificate) {
                try {
                    final Set<TrustAnchor> anch = new HashSet<TrustAnchor>();
                    for (final X509Certificate cert : tm.getAcceptedIssuers()) {
                        anch.add(new TrustAnchor(cert, null));
                    }
                    (this.validatorParams = new PKIXParameters(anch)).setRevocationEnabled(false);
                    this.validator = CertPathValidator.getInstance("PKIX");
                    this.certFactory = CertificateFactory.getInstance("X.509");
                }
                catch (Exception e) {
                    throw new CertificateException(e);
                }
            }
        }
        
        public X509TrustManagerWrapper() {
            this.origTm = null;
            this.verifyServerCert = false;
            this.certFactory = null;
            this.validatorParams = null;
            this.validator = null;
        }
        
        public X509Certificate[] getAcceptedIssuers() {
            return (this.origTm != null) ? this.origTm.getAcceptedIssuers() : new X509Certificate[0];
        }
        
        public void checkServerTrusted(final X509Certificate[] chain, final String authType) throws CertificateException {
            for (int i = 0; i < chain.length; ++i) {
                chain[i].checkValidity();
            }
            if (this.validatorParams != null) {
                final X509CertSelector certSelect = new X509CertSelector();
                certSelect.setSerialNumber(chain[0].getSerialNumber());
                try {
                    final CertPath certPath = this.certFactory.generateCertPath(Arrays.asList(chain));
                    final CertPathValidatorResult result = this.validator.validate(certPath, this.validatorParams);
                    ((PKIXCertPathValidatorResult)result).getTrustAnchor().getTrustedCert().checkValidity();
                }
                catch (InvalidAlgorithmParameterException e) {
                    throw new CertificateException(e);
                }
                catch (CertPathValidatorException e2) {
                    throw new CertificateException(e2);
                }
            }
            if (this.verifyServerCert) {
                this.origTm.checkServerTrusted(chain, authType);
            }
        }
        
        public void checkClientTrusted(final X509Certificate[] chain, final String authType) throws CertificateException {
            this.origTm.checkClientTrusted(chain, authType);
        }
    }
}
