// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc.exceptions;

public interface DeadlockTimeoutRollbackMarker
{
}
