// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import java.sql.SQLType;
import java.sql.SQLException;

public class JDBC42PreparedStatement extends JDBC4PreparedStatement
{
    public JDBC42PreparedStatement(final MySQLConnection conn, final String catalog) throws SQLException {
        super(conn, catalog);
    }
    
    public JDBC42PreparedStatement(final MySQLConnection conn, final String sql, final String catalog) throws SQLException {
        super(conn, sql, catalog);
    }
    
    public JDBC42PreparedStatement(final MySQLConnection conn, final String sql, final String catalog, final ParseInfo cachedParseInfo) throws SQLException {
        super(conn, sql, catalog, cachedParseInfo);
    }
    
    private int checkSqlType(final int sqlType) throws SQLException {
        return JDBC42Helper.checkSqlType(sqlType, this.getExceptionInterceptor());
    }
    
    private int translateAndCheckSqlType(final SQLType sqlType) throws SQLException {
        return JDBC42Helper.translateAndCheckSqlType(sqlType, this.getExceptionInterceptor());
    }
    
    @Override
    public void setObject(final int parameterIndex, final Object x) throws SQLException {
        synchronized (this.checkClosed().getConnectionMutex()) {
            super.setObject(parameterIndex, JDBC42Helper.convertJavaTimeToJavaSql(x));
        }
    }
    
    @Override
    public void setObject(final int parameterIndex, final Object x, final int targetSqlType) throws SQLException {
        synchronized (this.checkClosed().getConnectionMutex()) {
            super.setObject(parameterIndex, JDBC42Helper.convertJavaTimeToJavaSql(x), this.checkSqlType(targetSqlType));
        }
    }
    
    @Override
    public void setObject(final int parameterIndex, final Object x, final int targetSqlType, final int scaleOrLength) throws SQLException {
        synchronized (this.checkClosed().getConnectionMutex()) {
            super.setObject(parameterIndex, JDBC42Helper.convertJavaTimeToJavaSql(x), this.checkSqlType(targetSqlType), scaleOrLength);
        }
    }
    
    @Override
    public void setObject(final int parameterIndex, final Object x, final SQLType targetSqlType) throws SQLException {
        synchronized (this.checkClosed().getConnectionMutex()) {
            super.setObject(parameterIndex, JDBC42Helper.convertJavaTimeToJavaSql(x), this.translateAndCheckSqlType(targetSqlType));
        }
    }
    
    @Override
    public void setObject(final int parameterIndex, final Object x, final SQLType targetSqlType, final int scaleOrLength) throws SQLException {
        synchronized (this.checkClosed().getConnectionMutex()) {
            super.setObject(parameterIndex, JDBC42Helper.convertJavaTimeToJavaSql(x), this.translateAndCheckSqlType(targetSqlType), scaleOrLength);
        }
    }
}
