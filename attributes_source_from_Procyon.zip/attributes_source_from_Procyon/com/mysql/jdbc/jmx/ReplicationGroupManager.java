// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc.jmx;

import com.mysql.jdbc.ReplicationConnectionGroup;
import java.util.Iterator;
import com.mysql.jdbc.ReplicationConnectionGroupManager;
import java.sql.SQLException;
import javax.management.MBeanServer;
import com.mysql.jdbc.ExceptionInterceptor;
import com.mysql.jdbc.SQLError;
import javax.management.ObjectName;
import java.lang.management.ManagementFactory;

public class ReplicationGroupManager implements ReplicationGroupManagerMBean
{
    private boolean isJmxRegistered;
    
    public ReplicationGroupManager() {
        this.isJmxRegistered = false;
    }
    
    public synchronized void registerJmx() throws SQLException {
        if (this.isJmxRegistered) {
            return;
        }
        final MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
        try {
            final ObjectName name = new ObjectName("com.mysql.jdbc.jmx:type=ReplicationGroupManager");
            mbs.registerMBean(this, name);
            this.isJmxRegistered = true;
        }
        catch (Exception e) {
            throw SQLError.createSQLException("Unable to register replication host management bean with JMX", null, e, null);
        }
    }
    
    public void addSlaveHost(final String groupFilter, final String host) throws SQLException {
        ReplicationConnectionGroupManager.addSlaveHost(groupFilter, host);
    }
    
    public void removeSlaveHost(final String groupFilter, final String host) throws SQLException {
        ReplicationConnectionGroupManager.removeSlaveHost(groupFilter, host);
    }
    
    public void promoteSlaveToMaster(final String groupFilter, final String host) throws SQLException {
        ReplicationConnectionGroupManager.promoteSlaveToMaster(groupFilter, host);
    }
    
    public void removeMasterHost(final String groupFilter, final String host) throws SQLException {
        ReplicationConnectionGroupManager.removeMasterHost(groupFilter, host);
    }
    
    public String getMasterHostsList(final String group) {
        final StringBuilder sb = new StringBuilder("");
        boolean found = false;
        for (final String host : ReplicationConnectionGroupManager.getMasterHosts(group)) {
            if (found) {
                sb.append(",");
            }
            found = true;
            sb.append(host);
        }
        return sb.toString();
    }
    
    public String getSlaveHostsList(final String group) {
        final StringBuilder sb = new StringBuilder("");
        boolean found = false;
        for (final String host : ReplicationConnectionGroupManager.getSlaveHosts(group)) {
            if (found) {
                sb.append(",");
            }
            found = true;
            sb.append(host);
        }
        return sb.toString();
    }
    
    public String getRegisteredConnectionGroups() {
        final StringBuilder sb = new StringBuilder("");
        boolean found = false;
        for (final ReplicationConnectionGroup group : ReplicationConnectionGroupManager.getGroupsMatching(null)) {
            if (found) {
                sb.append(",");
            }
            found = true;
            sb.append(group.getGroupName());
        }
        return sb.toString();
    }
    
    public int getActiveMasterHostCount(final String group) {
        return ReplicationConnectionGroupManager.getMasterHosts(group).size();
    }
    
    public int getActiveSlaveHostCount(final String group) {
        return ReplicationConnectionGroupManager.getSlaveHosts(group).size();
    }
    
    public int getSlavePromotionCount(final String group) {
        return ReplicationConnectionGroupManager.getNumberOfMasterPromotion(group);
    }
    
    public long getTotalLogicalConnectionCount(final String group) {
        return ReplicationConnectionGroupManager.getTotalConnectionCount(group);
    }
    
    public long getActiveLogicalConnectionCount(final String group) {
        return ReplicationConnectionGroupManager.getActiveConnectionCount(group);
    }
}
