// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

public interface StreamingNotifiable
{
    void setWasStreamingResults();
}
