// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import java.util.Map;
import java.util.List;
import java.sql.SQLException;
import java.util.Properties;

public class ServerAffinityStrategy extends RandomBalanceStrategy
{
    public static final String AFFINITY_ORDER = "serverAffinityOrder";
    public String[] affinityOrderedServers;
    
    public ServerAffinityStrategy() {
        this.affinityOrderedServers = null;
    }
    
    @Override
    public void init(final Connection conn, final Properties props) throws SQLException {
        super.init(conn, props);
        final String hosts = props.getProperty("serverAffinityOrder");
        if (!StringUtils.isNullOrEmpty(hosts)) {
            this.affinityOrderedServers = hosts.split(",");
        }
    }
    
    @Override
    public ConnectionImpl pickConnection(final LoadBalancedConnectionProxy proxy, final List<String> configuredHosts, final Map<String, ConnectionImpl> liveConnections, final long[] responseTimes, final int numRetries) throws SQLException {
        if (this.affinityOrderedServers == null) {
            return super.pickConnection(proxy, configuredHosts, liveConnections, responseTimes, numRetries);
        }
        final Map<String, Long> blackList = proxy.getGlobalBlacklist();
        for (final String host : this.affinityOrderedServers) {
            if (configuredHosts.contains(host) && !blackList.containsKey(host)) {
                ConnectionImpl conn = liveConnections.get(host);
                if (conn != null) {
                    return conn;
                }
                try {
                    conn = proxy.createConnectionForHost(host);
                    return conn;
                }
                catch (SQLException sqlEx) {
                    if (proxy.shouldExceptionTriggerConnectionSwitch(sqlEx)) {
                        proxy.addToGlobalBlacklist(host);
                    }
                }
            }
        }
        return super.pickConnection(proxy, configuredHosts, liveConnections, responseTimes, numRetries);
    }
}
