// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import java.sql.SQLException;
import java.util.Map;

class LicenseConfiguration
{
    static void checkLicenseType(final Map<String, String> serverVariables) throws SQLException {
    }
    
    private LicenseConfiguration() {
    }
}
