// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

public class DocsConnectionPropsHelper extends ConnectionPropertiesImpl
{
    static final long serialVersionUID = -1580779062220390294L;
    
    public static void main(final String[] args) throws Exception {
        System.out.println(new DocsConnectionPropsHelper().exposeAsXml());
    }
}
