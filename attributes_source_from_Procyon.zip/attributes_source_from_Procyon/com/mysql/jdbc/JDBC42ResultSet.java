// 
// Decompiled by Procyon v0.5.36
// 

package com.mysql.jdbc;

import java.sql.SQLType;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Date;
import java.time.OffsetTime;
import java.time.format.DateTimeParseException;
import java.time.OffsetDateTime;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.LocalDate;
import java.sql.SQLException;

public class JDBC42ResultSet extends JDBC4ResultSet
{
    public JDBC42ResultSet(final long updateCount, final long updateID, final MySQLConnection conn, final StatementImpl creatorStmt) {
        super(updateCount, updateID, conn, creatorStmt);
    }
    
    public JDBC42ResultSet(final String catalog, final Field[] fields, final RowData tuples, final MySQLConnection conn, final StatementImpl creatorStmt) throws SQLException {
        super(catalog, fields, tuples, conn, creatorStmt);
    }
    
    @Override
    public <T> T getObject(final int columnIndex, final Class<T> type) throws SQLException {
        if (type == null) {
            throw SQLError.createSQLException("Type parameter can not be null", "S1009", this.getExceptionInterceptor());
        }
        if (type.equals(LocalDate.class)) {
            final Date date = this.getDate(columnIndex);
            return (date == null) ? null : type.cast(date.toLocalDate());
        }
        if (type.equals(LocalDateTime.class)) {
            final Timestamp timestamp = this.getTimestamp(columnIndex);
            return (timestamp == null) ? null : type.cast(timestamp.toLocalDateTime());
        }
        if (type.equals(LocalTime.class)) {
            final Time time = this.getTime(columnIndex);
            return (time == null) ? null : type.cast(time.toLocalTime());
        }
        if (type.equals(OffsetDateTime.class)) {
            try {
                final String string = this.getString(columnIndex);
                return (string == null) ? null : type.cast(OffsetDateTime.parse(string));
            }
            catch (DateTimeParseException ex) {
                return super.getObject(columnIndex, type);
            }
        }
        if (type.equals(OffsetTime.class)) {
            try {
                final String string = this.getString(columnIndex);
                return (string == null) ? null : type.cast(OffsetTime.parse(string));
            }
            catch (DateTimeParseException ex2) {}
        }
        return super.getObject(columnIndex, type);
    }
    
    @Override
    public void updateObject(final int columnIndex, final Object x, final SQLType targetSqlType) throws SQLException {
        throw new NotUpdatable();
    }
    
    @Override
    public void updateObject(final int columnIndex, final Object x, final SQLType targetSqlType, final int scaleOrLength) throws SQLException {
        throw new NotUpdatable();
    }
    
    @Override
    public void updateObject(final String columnLabel, final Object x, final SQLType targetSqlType) throws SQLException {
        throw new NotUpdatable();
    }
    
    @Override
    public void updateObject(final String columnLabel, final Object x, final SQLType targetSqlType, final int scaleOrLength) throws SQLException {
        throw new NotUpdatable();
    }
}
