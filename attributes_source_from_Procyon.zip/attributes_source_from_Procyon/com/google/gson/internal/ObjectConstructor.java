// 
// Decompiled by Procyon v0.5.36
// 

package com.google.gson.internal;

public interface ObjectConstructor<T>
{
    T construct();
}
