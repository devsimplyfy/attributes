// 
// Decompiled by Procyon v0.5.36
// 

package attributes;

import java.io.IOException;
import java.lang.reflect.UndeclaredThrowableException;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import java.sql.SQLException;
import org.json.simple.parser.ParseException;

public class launch
{
    public static void main(final String[] args) throws ParseException, IllegalAccessException, InstantiationException, SQLException, JsonSyntaxException, JsonIOException, UndeclaredThrowableException, IOException {
        final String s = "{\r\n  \"category_name\" : \"mens_footwear\",\r\n  \"categoryPath\" : \"Footwear>Men>Slippers & Flip Flops\",\r\n  \"name\" : \"Sparx SFG-2016 Slippers\",\r\n  \"description\" : \"\",\r\n  \"regular_price\" : 374,\r\n  \"sale_price\" : 374,\r\n  \"stock\" : false,\r\n  \"image\" : \"https://rukminim1.flixcart.com/image/800/800/slipper-flip-flop/b/y/z/red-sf2016g-sfg-2016-sparx-8-original-imadxzjxghbrsu74.jpeg?q=90\",\r\n  \"product_url\" : \"https://www.flipkart.com/sparx-sfg-2016-slippers/p/itmfafyfmeckthrd?pid=SFFDTZ2E5YCZSZ4T&affid=instantweb\",\r\n  \"product_id\" : \"1_SFFDTZ2E5YCZSZ4T\",\r\n  \"highlights\" : [ \"Black, White, Green, Red Color\", \"Type: Slippers\", \"For Men\", \"Sole Material: EVA\" ]\r\n}\r\n";
        final String r = transform.doCatStore(s);
        System.out.println(r);
    }
}
