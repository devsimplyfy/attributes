// 
// Decompiled by Procyon v0.5.36
// 

package attributes;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.GsonBuilder;
import java.io.FileNotFoundException;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import java.util.Iterator;
import com.google.gson.JsonElement;
import java.util.Map;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;

public class FlatWalmartProdCat
{
    static String parentkey;
    static final String DEFAULT_PARENT_KEY = "0";
    static final String DEFAULT_PARENT_KEY_NAME = "parentid";
    static final String ROW_KEY = "id";
    static final String NESTED_ATTR_NAME = "children";
    static JsonArray arrFlatCatJson;
    
    static {
        FlatWalmartProdCat.parentkey = "";
        FlatWalmartProdCat.arrFlatCatJson = new JsonArray();
    }
    
    public static String doFlat(final String categories) throws JsonSyntaxException, JsonIOException, FileNotFoundException {
        final String s = categories;
        final JsonObject objData = new Gson().fromJson(s, JsonObject.class);
        for (final Map.Entry<String, JsonElement> entry : objData.entrySet()) {
            final JsonObject objFlatCat = new JsonObject();
            if (entry.getValue() instanceof JsonArray) {
                final JsonArray jsonArrayval = entry.getValue().getAsJsonArray();
                for (int count = 0; count < jsonArrayval.size(); ++count) {
                    final JsonElement objElement = jsonArrayval.get(count);
                    final JsonObject objJson = objElement.getAsJsonObject();
                    System.out.println(objJson);
                    final String attrName;
                    final JsonElement attrVal;
                    final JsonObject jsonObject;
                    objJson.entrySet().stream().forEach(row -> {
                        attrName = row.getKey();
                        attrVal = (JsonElement)row.getValue();
                        if (attrVal instanceof JsonArray) {
                            printJson(attrVal, attrName, FlatWalmartProdCat.parentkey, attrName);
                        }
                        if ("id".equals(attrName)) {
                            FlatWalmartProdCat.parentkey = attrVal.getAsString();
                        }
                        if (!"children".equals(attrName)) {
                            jsonObject.addProperty(attrName, attrVal.getAsString());
                        }
                        return;
                    });
                    objFlatCat.addProperty("parentid", "0");
                    FlatWalmartProdCat.arrFlatCatJson.add(objFlatCat);
                }
            }
        }
        printMap();
        return FlatWalmartProdCat.arrFlatCatJson.toString();
    }
    
    public static String printMap() {
        final Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE).create();
        return gson.toJson(FlatWalmartProdCat.arrFlatCatJson);
    }
    
    static void printJson(final JsonElement jsonElement, final String key, final String parentid, final String rowkey) {
        final String innerParentKey = parentid;
        String rowIdentifier = "";
        if (jsonElement instanceof JsonArray) {
            final JsonArray jsonArr = jsonElement.getAsJsonArray();
            for (int j = 0; j < jsonArr.size(); ++j) {
                final JsonObject objFlatCat = new JsonObject();
                final JsonElement objectData = jsonArr.get(j);
                final JsonObject joa = objectData.getAsJsonObject();
                for (final Map.Entry<String, JsonElement> data : joa.entrySet()) {
                    final String currKey = data.getKey();
                    final JsonElement currElement = data.getValue();
                    if ("id".equals(currKey)) {
                        rowIdentifier = currElement.getAsString();
                    }
                    if (currElement instanceof JsonArray) {
                        printJson(currElement, currKey, rowIdentifier, rowIdentifier);
                    }
                    else {
                        if ("children".equals(currKey)) {
                            continue;
                        }
                        objFlatCat.addProperty(currKey, currElement.getAsString());
                    }
                }
                objFlatCat.addProperty("parentid", innerParentKey);
                FlatWalmartProdCat.arrFlatCatJson.add(objFlatCat);
            }
        }
    }
}
