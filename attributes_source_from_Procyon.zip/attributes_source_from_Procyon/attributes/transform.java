// 
// Decompiled by Procyon v0.5.36
// 

package attributes;

import java.sql.CallableStatement;
import java.util.ArrayList;
import java.sql.Date;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import java.io.File;
import java.util.TimeZone;
import java.text.SimpleDateFormat;
import org.json.simple.JSONArray;
import java.util.Iterator;
import java.util.Set;
import java.io.UnsupportedEncodingException;
import org.json.simple.parser.ParseException;
import java.sql.SQLException;
import java.sql.DriverManager;
import com.mysql.jdbc.Statement;
import java.sql.Connection;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class transform
{
    static JSONParser parser;
    static String callProcedure;
    static JSONObject jobj;
    static Connection conn;
    static Statement stmt;
    
    static {
        transform.parser = new JSONParser();
        transform.callProcedure = null;
        transform.jobj = null;
        transform.conn = null;
    }
    
    public static void dbconfig() throws IllegalAccessException, InstantiationException, SQLException, ParseException, UnsupportedEncodingException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            final String url = "jdbc:mysql://DESKTOP-8T43HRL:3306/wsimcpsn_shopnowee";
            transform.conn = DriverManager.getConnection(url, "root", "Alfred_21");
            System.out.println("CONNECTION DONE");
        }
        catch (Exception ex) {
            System.err.println(ex.getMessage());
        }
        transform.stmt = (Statement)transform.conn.createStatement();
    }
    
    public static String doAttrStore(final String str) throws ParseException {
        transform.jobj = (JSONObject)transform.parser.parse(str);
        final String x = transform.jobj.get("product_id");
        final String[] data = x.split("_");
        final String vendorId = data[0];
        final String productId = data[1];
        String total_att_name = "";
        String total_att_val = "";
        final Set keySet = transform.jobj.keySet();
        for (final String att_name : keySet) {
            if (!att_name.equals("product_id") && !att_name.equals("productUrl") && !att_name.equals("inStock") && !att_name.equals("specialPrice") && !att_name.equals("active_id")) {
                if (transform.jobj.get(att_name).toString().length() < 1) {
                    continue;
                }
                total_att_name = total_att_name.concat(att_name).concat("~");
                if (att_name.equals("color")) {
                    final String regEx = "[\\[|\\]|(|//|&|.|$|,|\\d|\\)|-]|(AND)|(and)|(And)|(with)|(With)";
                    String color;
                    final String att_val = color = transform.jobj.get(att_name);
                    color = color.replaceAll(regEx, "&");
                    if (color.indexOf("&") == 0) {
                        color = color.replaceFirst(regEx, "");
                    }
                    while (color.contains("&&")) {
                        color = color.replaceAll("&&", "&");
                    }
                    total_att_val = total_att_val.concat(color.trim()).concat("~");
                }
                else {
                    final String att_val = transform.jobj.get(att_name);
                    total_att_val = total_att_val.concat(att_val).concat("~");
                }
            }
        }
        String toGroovy;
        if (total_att_name != "") {
            transform.callProcedure = "call spInsUpdateProdAttr(\"" + total_att_name.substring(0, total_att_name.length() - 1) + "\",\"" + total_att_val.substring(0, total_att_val.length() - 1) + "\",\"" + productId + "\",\"" + transform.jobj.get("active_id") + "\",\"" + vendorId + "\",\"" + transform.jobj.get("productUrl") + "\",\"" + transform.jobj.get("inStock") + "\",\"" + String.valueOf(transform.jobj.get("specialPrice")) + "\",@insProductID);";
            toGroovy = transform.callProcedure.replace("[", "").replace("]", "");
        }
        else {
            toGroovy = "NO_ATTRIBUTES";
        }
        return toGroovy;
    }
    
    public static String doAttrStoreTried(final String str) throws ParseException {
        transform.jobj = (JSONObject)transform.parser.parse(str);
        final String x = transform.jobj.get("product_id");
        final String[] data = x.split("_");
        final String vendorId = data[0];
        final String productId = data[1];
        String total_att_name = "";
        String total_att_val = "";
        String clr = transform.jobj.get("color");
        final Set keySet = transform.jobj.keySet();
        for (final String att_name : keySet) {
            if (!att_name.equals("product_id") && !att_name.equals("productUrl") && !att_name.equals("inStock") && !att_name.equals("specialPrice") && !att_name.equals("active_id")) {
                if (transform.jobj.get(att_name).toString().length() < 1) {
                    continue;
                }
                total_att_name = total_att_name.concat(att_name).concat("~");
                if (att_name.equals("color")) {
                    final String regEx = "[\\[|\\]|(|//|&|.|$|,|\\d|\\)|-]|(AND)|(and)|(And)|(with)|(With)";
                    String color;
                    final String att_val = color = transform.jobj.get(att_name);
                    color = color.replaceAll(regEx, "&");
                    if (color.indexOf("&") == 0) {
                        color = color.replaceFirst(regEx, "");
                    }
                    while (color.contains("&&")) {
                        color = color.replaceAll("&&", "&");
                    }
                    clr = color;
                    total_att_val = total_att_val.concat(color.trim()).concat("~");
                }
                else {
                    final String att_val = transform.jobj.get(att_name);
                    total_att_val = total_att_val.concat(att_val).concat("~");
                }
            }
        }
        String toGroovy;
        if (total_att_name != "") {
            transform.callProcedure = "call spInsUpdateProdAttr(\"" + total_att_name.substring(0, total_att_name.length() - 1) + "\",\"" + total_att_val.substring(0, total_att_val.length() - 1) + "\",\"" + productId + "\",\"" + transform.jobj.get("active_id") + "\",\"" + vendorId + "\",\"" + transform.jobj.get("productUrl") + "\",\"" + transform.jobj.get("inStock") + "\",\"" + String.valueOf(transform.jobj.get("specialPrice")) + "\",@insProductID);";
            toGroovy = transform.callProcedure.replace("[", "").replace("]", "");
        }
        else {
            toGroovy = "NO_ATTRIBUTES";
        }
        return toGroovy;
    }
    
    public static JSONArray doAttrStore1(final String str) throws ParseException {
        final JSONArray jArray = new JSONArray();
        transform.jobj = (JSONObject)transform.parser.parse(str);
        final String x = transform.jobj.get("product_id");
        final String[] data = x.split("_");
        final String productId = data[1];
        String total_att_name = "";
        String total_att_val = "";
        final Set keySet = transform.jobj.keySet();
        for (final String att_name : keySet) {
            if (!att_name.equals("product_id")) {
                if (transform.jobj.get(att_name).toString().length() < 1) {
                    continue;
                }
                total_att_name = total_att_name.concat(att_name).concat("~");
                final String att_val = transform.jobj.get(att_name);
                total_att_val = total_att_val.concat(att_val).concat("~");
                jArray.add(transform.callProcedure = "call spInsUpdateProdAttr(\"" + att_name + "\",\"" + att_val + "\",\"" + productId + "\",@insProductID);");
            }
        }
        return jArray;
    }
    
    public static String doCatStore(final String str) throws ParseException {
        transform.jobj = (JSONObject)transform.parser.parse(str);
        String parent = null;
        String child = null;
        String cMap = null;
        String vendorId = null;
        String productId = null;
        int index1 = 0;
        final Integer[] a1 = new Integer[30];
        String cPath = transform.jobj.get("categoryPath");
        final String s = transform.jobj.get("nameTerms");
        if (s != null) {
            String child_product;
            if (s.contains(", Size") || s.contains(", Created")) {
                String s2 = null;
                if (s.contains(", Size")) {
                    s2 = s.substring(0, s.indexOf(", Size"));
                }
                else {
                    s2 = s.substring(0, s.indexOf(", Created"));
                }
                for (int i = 0; i < s2.length(); ++i) {
                    if (s2.charAt(i) == ' ') {
                        a1[index1] = i;
                        ++index1;
                    }
                }
                child_product = s2.substring(a1[index1 - 2]);
            }
            else {
                System.out.println("ELSE");
                for (int j = 0; j < s.length(); ++j) {
                    if (s.charAt(j) == ' ') {
                        a1[index1] = j;
                        ++index1;
                    }
                }
                child_product = s.substring(a1[index1 - 2]);
            }
            cPath = String.valueOf(cPath) + " >" + child_product;
        }
        final String x = transform.jobj.get("product_id");
        if (x.contains("_")) {
            final String[] data = x.split("_");
            vendorId = data[0];
            productId = data[1];
        }
        else {
            productId = x;
            vendorId = transform.jobj.get("vendor_id");
        }
        int j = 0;
        int index2 = 0;
        int find = 0;
        final Integer[] a2 = new Integer[10];
        for (j = 0; j < cPath.length(); ++j) {
            if (cPath.charAt(j) == '>') {
                ++find;
                a2[index2] = j;
                ++index2;
            }
        }
        if (cPath.contains("Men")) {
            parent = "Men";
        }
        if (cPath.contains("Women")) {
            parent = "Women";
        }
        if (cPath.contains("Boys")) {
            parent = "Boys";
        }
        if (cPath.contains("Girls")) {
            parent = "Girls";
        }
        child = cPath.substring(cPath.lastIndexOf(">") + 1, cPath.length());
        if (parent == null) {
            parent = cPath;
        }
        if (child == null) {
            child = cPath;
        }
        if (find >= 3) {
            if (cPath.contains("Infant") || cPath.contains("Kids")) {
                cMap = cPath.substring(a2[index2 - 2] + 1, a2[index2 - 1]);
            }
            else {
                cMap = cPath.substring(a2[1] + 1, a2[2]);
            }
        }
        else {
            cMap = child;
        }
        String description = null;
        final JSONArray highlights = transform.jobj.get("highlights");
        if (highlights != null) {
            description = String.valueOf(transform.jobj.get("description")) + " " + highlights.toString().replaceAll("\"", "");
        }
        else {
            description = transform.jobj.get("description");
        }
        final JSONObject demo = new JSONObject();
        demo.put("name", transform.jobj.get("name"));
        transform.callProcedure = "call productInsUpdate(\"" + parent + "\", \"" + cMap.trim() + "\",\"" + child.trim() + "\",\"" + transform.jobj.get("name") + "\",\"" + description + "\",\"" + transform.jobj.get("regular_price") + "\",\"" + transform.jobj.get("sale_price") + "\",\"" + transform.jobj.get("stock") + "\",\"" + transform.jobj.get("image") + "\",\"" + transform.jobj.get("product_url") + "\",\"" + productId + "\",\"" + vendorId + "\",\"" + 0 + "\",\"" + transform.jobj.get("similar_product_id") + "\",@insProductID);";
        return transform.callProcedure.replace("[", "").replace("]", "");
    }
    
    public static String doKeywordsStore(final String str) throws ParseException {
        transform.jobj = (JSONObject)transform.parser.parse(str);
        final String x = transform.jobj.get("product_id");
        final String productId = x.substring(x.lastIndexOf("_") + 1);
        transform.callProcedure = "call keywordsProcedure(\"" + productId + "\",\"" + transform.jobj.get("keywords") + "\");";
        return transform.callProcedure.replaceAll("\"", "").replace("[", "").replace("]", "");
    }
    
    public static String doImageStore(final String str) throws ParseException {
        transform.jobj = (JSONObject)transform.parser.parse(str);
        return transform.callProcedure = "call ImageProcedure(\"" + transform.jobj.get("product_id") + "\",\"" + transform.jobj.get("200x200") + "\",\"" + transform.jobj.get("400x400") + "\",\"" + transform.jobj.get("800x800") + "\");";
    }
    
    public static String doImageKeywordsStore(final String str) throws ParseException {
        transform.jobj = (JSONObject)transform.parser.parse(str);
        return transform.callProcedure = "call image_keywordsProcedure(\"" + transform.jobj.get("product_id") + "\",\"" + transform.jobj.get("keywords") + "\");";
    }
    
    public static String doDealStore(final String str) throws ParseException, IOException {
        transform.jobj = (JSONObject)transform.parser.parse(str);
        String valid = "NULL";
        String parent = null;
        String cPath = null;
        String child = null;
        int index = 0;
        final Integer[] a = new Integer[30];
        for (int i = 0; i < transform.jobj.get("product_url").length(); ++i) {
            if (transform.jobj.get("product_url").toString().charAt(i) == '/') {
                a[index] = i;
                ++index;
            }
        }
        final String start_time = transform.jobj.get("start_date").toString();
        final String end_time = transform.jobj.get("end_date").toString();
        final SimpleDateFormat jdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss z");
        jdf.setTimeZone(TimeZone.getTimeZone("GMT"));
        final File keywords = new File("E:\\Java_Jars\\include_keyword.txt");
        final String spec = FileUtils.readFileToString(keywords, "UTF-8");
        final String[] match = spec.split(",");
        final String modified_name = transform.jobj.get("name").replace("'", "");
        if (a[3] != null) {
            final String toCompare = transform.jobj.get("product_url").toString().substring(a[2] + 1, a[3]).replace("-", " ");
            if (toCompare.equalsIgnoreCase("all")) {
                for (int k = 0; k < match.length; ++k) {
                    if (modified_name.equalsIgnoreCase(match[k])) {
                        cPath = modified_name;
                        if (cPath.contains("Mens") || cPath.contains("Men")) {
                            parent = "Men";
                        }
                        if (cPath.contains("Womens") || cPath.contains("Women")) {
                            parent = "Women";
                        }
                        if (cPath.contains("Boys") || cPath.contains("Boy")) {
                            parent = "Boys";
                        }
                        if (cPath.contains("Girls") || cPath.contains("Girl")) {
                            parent = "Girls";
                        }
                        if (cPath.contains("Kids") || cPath.contains("Kid")) {
                            parent = "Kids";
                        }
                        child = "Kids fashion";
                        valid = "Matched";
                        break;
                    }
                }
            }
            else {
                valid = "SKIP";
            }
            for (int j = 0; j < match.length; ++j) {
                if (toCompare.equalsIgnoreCase(match[j])) {
                    if (toCompare.equalsIgnoreCase("clothing")) {
                        cPath = transform.jobj.get("product_url").toString().substring(a[3] + 1, a[4]).replace("-", " ").replace("~", " ");
                    }
                    else {
                        cPath = toCompare;
                    }
                    if (cPath.contains("mens") || cPath.contains("men")) {
                        parent = "Men";
                    }
                    if (cPath.contains("womens") || cPath.contains("women")) {
                        parent = "Women";
                    }
                    if (cPath.contains("boys") || cPath.contains("boy")) {
                        parent = "Boys";
                    }
                    if (cPath.contains("girls") || cPath.contains("girl")) {
                        parent = "Girls";
                    }
                    if (cPath.contains("kids") || cPath.contains("kid")) {
                        parent = "Kids";
                    }
                    if (cPath.contains("bras")) {
                        parent = "Women";
                    }
                    if (cPath.contains("jewellery")) {
                        parent = "Women";
                    }
                    child = toCompare;
                    valid = "Matched";
                    break;
                }
            }
        }
        if (valid != "Matched") {
            transform.callProcedure = "SKIPcall dealsProcedure(\"" + parent + "\", \"" + transform.jobj.get("name") + "\",\"" + child + "\",\"" + transform.jobj.get("prodName") + "\",\"" + transform.jobj.get("description") + "\",\"" + "0.0" + "\",\"" + "0.0" + "\",\"" + "LIVE" + "\",\"" + transform.jobj.get("imageUrl") + "\",\"" + transform.jobj.get("product_url") + "\",\"" + transform.jobj.get("product_id") + "\",\"" + 1 + "\",\"" + 0 + "\",\"" + transform.jobj.get("similar_product_id") + "\",\"" + transform.jobj.get("start_date") + "\",\"" + transform.jobj.get("end_date") + "\",@insProductID);";
        }
        else {
            transform.callProcedure = "call dealsProcedure(\"" + parent + "\",\"" + transform.jobj.get("name") + "\",\"" + child + "\",\"" + transform.jobj.get("prodName") + "\",\"" + transform.jobj.get("description") + "\",\"" + "0.0" + "\",\"" + "0.0" + "\",\"" + "LIVE" + "\",\"" + transform.jobj.get("imageUrl") + "\",\"" + transform.jobj.get("product_url") + "\",\"" + transform.jobj.get("product_id") + "\",\"" + 1 + "\",\"" + 0 + "\",\"" + transform.jobj.get("similar_product_id") + "\",\"" + transform.jobj.get("start_date") + "\",\"" + transform.jobj.get("end_date") + "\",@insProductID);";
        }
        return transform.callProcedure;
    }
    
    public static String doDealStore1(final String str) throws ParseException, IOException {
        final String[] call_return = new String[2];
        transform.jobj = (JSONObject)transform.parser.parse(str);
        String valid = "NULL";
        String parent = null;
        String cPath = null;
        String child = null;
        int index = 0;
        final Integer[] a = new Integer[30];
        for (int i = 0; i < transform.jobj.get("product_url").length(); ++i) {
            if (transform.jobj.get("product_url").toString().charAt(i) == '/') {
                a[index] = i;
                ++index;
            }
        }
        final String start_time = transform.jobj.get("start_date").toString();
        final String end_time = transform.jobj.get("end_date").toString();
        final long start_timeStamp = Long.parseLong(start_time.substring(0, start_time.length() - 3));
        final long end_timeStamp = Long.parseLong(end_time.substring(0, end_time.length() - 3));
        final Date sdate = new Date(start_timeStamp * 1000L);
        final Date edate = new Date(end_timeStamp * 1000L);
        final SimpleDateFormat jdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss z");
        jdf.setTimeZone(TimeZone.getTimeZone("GMT"));
        final String start_date = jdf.format(sdate);
        final String end_date = jdf.format(edate);
        final File keywords = new File("E:\\Java_Jars\\include_keyword.txt");
        final String spec = FileUtils.readFileToString(keywords, "UTF-8");
        final String[] match = spec.split(",");
        final String modified_name = transform.jobj.get("name").replace("'", "");
        if (a[3] != null) {
            final String toCompare = transform.jobj.get("product_url").toString().substring(a[2] + 1, a[3]).replace("-", " ");
            if (toCompare.equalsIgnoreCase("all")) {
                for (int k = 0; k < match.length; ++k) {
                    if (modified_name.equalsIgnoreCase(match[k])) {
                        cPath = modified_name;
                        if (cPath.contains("Mens")) {
                            parent = "Men";
                        }
                        if (cPath.contains("Womens")) {
                            parent = "Women";
                        }
                        if (cPath.contains("Boys")) {
                            parent = "Boys";
                        }
                        if (cPath.contains("Girls")) {
                            parent = "Girls";
                        }
                        if (cPath.contains("Kids")) {
                            parent = "Kids";
                        }
                        child = "Kids fashion";
                        valid = "Matched";
                        break;
                    }
                }
            }
            else {
                valid = "SKIP";
            }
            for (int j = 0; j < match.length; ++j) {
                if (toCompare.equalsIgnoreCase(match[j])) {
                    cPath = toCompare;
                    if (cPath.contains("mens")) {
                        parent = "Men";
                    }
                    if (cPath.contains("womens")) {
                        parent = "Women";
                    }
                    if (cPath.contains("boys")) {
                        parent = "Boys";
                    }
                    if (cPath.contains("girls")) {
                        parent = "Girls";
                    }
                    if (cPath.contains("kids")) {
                        parent = "Kids";
                    }
                    if (cPath.contains("bras")) {
                        parent = "Women";
                    }
                    if (cPath.contains("jewellery")) {
                        parent = "Women";
                    }
                    child = toCompare;
                    valid = "Matched";
                    break;
                }
            }
        }
        final String like = "%\\_%\\_";
        if (valid != "Matched") {
            transform.callProcedure = "SKIPcall dealsProcedure(\"" + transform.jobj.get("category") + "\",\"" + transform.jobj.get("product_id") + "\",\"" + transform.jobj.get("start_date") + "\",\"" + like + transform.jobj.get("end_date") + "\",\"" + transform.jobj.get("end_date") + "\");";
            final String callProcedure1 = "SKIPcall productInsUpdate(\"" + parent + "\", \"" + transform.jobj.get("name") + "\",\"" + child + "\",\"" + transform.jobj.get("name") + "\",\"" + transform.jobj.get("description") + "\",\"" + "0.0" + "\",\"" + "0.0" + "\",\"" + "LIVE" + "\",\"" + transform.jobj.get("imageUrl") + "\",\"" + transform.jobj.get("deal_url") + "\",\"" + transform.jobj.get("product_id") + "\",\"" + 1 + "\",\"" + 0 + "\",\"" + transform.jobj.get("similar_product_id") + "\",@insProductID);";
            call_return[0] = transform.callProcedure;
            call_return[1] = callProcedure1;
        }
        else {
            transform.callProcedure = "call dealsProcedure(\"" + transform.jobj.get("category") + "\",\"" + transform.jobj.get("product_id") + "\",\"" + transform.jobj.get("start_date") + "\",\"" + like + transform.jobj.get("end_date") + "\",\"" + transform.jobj.get("end_date") + "\");";
            final String callProcedure1 = "call productInsUpdate(\"" + parent + "\", \"" + transform.jobj.get("name") + "\",\"" + child + "\",\"" + transform.jobj.get("name") + "\",\"" + transform.jobj.get("description") + "\",\"" + "0.0" + "\",\"" + "0.0" + "\",\"" + "LIVE" + "\",\"" + transform.jobj.get("imageUrl") + "\",\"" + transform.jobj.get("deal_url") + "\",\"" + transform.jobj.get("product_id") + "\",\"" + 1 + "\",\"" + 0 + "\",\"" + transform.jobj.get("similar_product_id") + "\",@insProductID);";
            call_return[0] = transform.callProcedure;
            call_return[1] = callProcedure1;
        }
        return transform.callProcedure;
    }
    
    public static String comp(final String str, final String name) throws IOException {
        String s = "NULL";
        int index = 0;
        final Integer[] a = new Integer[10];
        for (int i = 0; i < str.length(); ++i) {
            if (str.charAt(i) == '/') {
                a[index] = i;
                ++index;
            }
        }
        final String sj = "1542274252031";
        final int timeStamp = Integer.valueOf(sj.substring(0, sj.length() - 3));
        final Date date = new Date(timeStamp * 1000L);
        final SimpleDateFormat jdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss z");
        jdf.setTimeZone(TimeZone.getTimeZone("GMT"));
        final String java_date = jdf.format(date);
        System.out.println("\n" + java_date.replace(" GMT", "") + "\n");
        final File keywords = new File("include_keyword.txt");
        final String spec = FileUtils.readFileToString(keywords, "UTF-8");
        final String[] match = spec.split(",");
        final String toCompare = str.substring(a[2] + 1, a[3]).replace("-", " ");
        final String modified_name = name.replace("'", "");
        if (toCompare.equalsIgnoreCase("all")) {
            for (int k = 0; k < match.length; ++k) {
                if (modified_name.equalsIgnoreCase(match[k])) {
                    s = "Matched";
                    break;
                }
            }
        }
        else {
            s = "SKIP";
        }
        for (int j = 0; j < match.length; ++j) {
            if (toCompare.equalsIgnoreCase(match[j])) {
                s = "Matched";
                break;
            }
        }
        if (s != "Matched") {
            s = "SKIP";
        }
        return s;
    }
    
    public static String test(final String s) {
        final String cPath = s;
        int find = 0;
        final Integer[] a = new Integer[10];
        int index = 0;
        for (int i = 0; i < cPath.length(); ++i) {
            if (cPath.charAt(i) == '\'') {
                ++find;
                a[index] = i;
                ++index;
            }
        }
        final String cMap = cPath.substring(a[2] + 1, a[3]);
        int find2 = 0;
        final Integer[] a2 = new Integer[10];
        int index2 = 0;
        for (int j = 0; j < cMap.length(); ++j) {
            if (cMap.charAt(j) == '~') {
                ++find2;
                a2[index2] = j;
                ++index2;
            }
        }
        String final_color = null;
        if (find2 > 1) {
            final String cMap2 = cMap.substring(a2[0] + 1, a2[1]);
            final String replace_color = regEx(cMap2);
            final_color = cMap.replace(cMap2, replace_color);
        }
        else if (find2 == 0) {
            final_color = cMap;
        }
        else {
            final String cMap2 = cMap.substring(a2[0] + 1, cMap.length());
            final String replace_color = regEx(cMap2);
            final_color = cMap.replace(cMap2, replace_color);
        }
        return cPath.replace(cMap, final_color);
    }
    
    static String regEx(String color) {
        final String regEx = "[\\[|\\]|(|//|&|.|$|,|\\d|\\)|-]|(AND)|(and)|(And)|(with)|(With)";
        color = color.replaceAll(regEx, "&");
        if (color.indexOf("&") == 0) {
            color = color.replaceFirst(regEx, "");
        }
        while (color.contains("&&")) {
            color = color.replaceAll("&&", "&");
        }
        return color;
    }
    
    public static String check_valid_json(final String s) {
        final String[] match = s.split("\r\n");
        for (int i = 0; i < match.length; ++i) {
            int find = 0;
            final ArrayList<Integer> arl = new ArrayList<Integer>();
            final String demo = match[i];
            for (int j = 0; j < demo.length(); ++j) {
                if (demo.charAt(j) == '\"') {
                    ++find;
                    arl.add(j);
                }
            }
            final StringBuilder sb = new StringBuilder(match[i]);
            if (find > 4) {
                int count = 0;
                int n = 1;
                for (int k = 3; k < arl.size() - 1; ++k) {
                    if (count > 0) {
                        sb.deleteCharAt(arl.get(k) - n);
                        ++n;
                    }
                    else {
                        sb.deleteCharAt(arl.get(k));
                    }
                    ++count;
                }
            }
            match[i] = sb.toString();
        }
        final StringBuilder builder = new StringBuilder();
        String[] array;
        for (int length = (array = match).length, l = 0; l < length; ++l) {
            final String s2 = array[l];
            builder.append(s2);
        }
        final String str = builder.toString();
        return str;
    }
    
    public static String doOptionsStore(final String str) throws ParseException {
        transform.jobj = (JSONObject)transform.parser.parse(str);
        final String x = transform.jobj.get("product_id");
        final String[] data = x.split("_");
        final String vendorId = data[0];
        final String productId = data[1];
        String total_att_name = "";
        String total_att_val = "";
        final Set keySet = transform.jobj.keySet();
        for (final String att_name : keySet) {
            if (!att_name.equals("product_id")) {
                if (transform.jobj.get(att_name).toString().length() < 1) {
                    continue;
                }
                total_att_name = total_att_name.concat(att_name).concat("~");
                final String att_val = transform.jobj.get(att_name);
                total_att_val = total_att_val.concat(att_val).concat("~");
            }
        }
        String toGroovy;
        if (total_att_name != "") {
            transform.callProcedure = "call optionsInsUpdate(\"" + total_att_name.substring(0, total_att_name.length() - 1) + "\",\"" + total_att_val.substring(0, total_att_val.length() - 1) + "\",\"" + productId + "\",\"" + vendorId + "\",@insProductID);";
            toGroovy = transform.callProcedure.replace("[", "").replace("]", "");
        }
        else {
            toGroovy = "NO_ATTRIBUTES";
        }
        return toGroovy;
    }
    
    public static String doOfferStore(final String str) throws ParseException {
        transform.jobj = (JSONObject)transform.parser.parse(str);
        final String x = transform.jobj.get("product_id");
        final String[] data = x.split("_");
        final String vendorId = data[0];
        final String productId = data[1];
        transform.callProcedure = "call offersInsUpdate(\"" + transform.jobj.get("offers").toString().replaceAll("\"", "") + "\",\"" + productId + "\",\"" + vendorId + "\",@insProductID);";
        return transform.callProcedure.replace("[", "").replace("]", "");
    }
    
    public static void call_proc(final String s) throws IllegalAccessException, InstantiationException, UnsupportedEncodingException, SQLException, ParseException {
        dbconfig();
        final String[] data = s.split("~");
        for (int i = 0; i < data.length; ++i) {
            final CallableStatement cStmt = transform.conn.prepareCall(data[i]);
            System.out.println(i);
            System.out.println(data[i]);
            cStmt.execute();
        }
    }
    
    public static String json_key_value(final String s) throws ParseException {
        final JSONParser jp = new JSONParser();
        final JSONObject jobj = (JSONObject)jp.parse(s);
        final JSONArray jarray = new JSONArray();
        final Set keySet = jobj.keySet();
        final Iterator iterator = keySet.iterator();
        final Iterator iterator2 = keySet.iterator();
        while (iterator.hasNext()) {
            final JSONObject jobj2 = new JSONObject();
            jobj2.put(iterator2.next(), jobj.get(iterator.next()));
            jarray.add(jobj2);
        }
        return jarray.toString();
    }
}
