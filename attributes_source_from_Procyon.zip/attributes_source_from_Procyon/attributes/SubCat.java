// 
// Decompiled by Procyon v0.5.36
// 

package attributes;

public class SubCat
{
    public static void subCatg() {
    }
}
