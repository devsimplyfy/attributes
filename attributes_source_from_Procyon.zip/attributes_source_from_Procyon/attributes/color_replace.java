// 
// Decompiled by Procyon v0.5.36
// 

package attributes;

public class color_replace
{
    public static String test(final String s) {
        final String cPath = s;
        int find = 0;
        final Integer[] a = new Integer[10];
        int index = 0;
        for (int i = 0; i < cPath.length(); ++i) {
            if (cPath.charAt(i) == '\'') {
                ++find;
                a[index] = i;
                ++index;
            }
        }
        final String cMap = cPath.substring(a[2] + 1, a[3]);
        int find2 = 0;
        final Integer[] a2 = new Integer[10];
        int index2 = 0;
        for (int j = 0; j < cMap.length(); ++j) {
            if (cMap.charAt(j) == '~') {
                ++find2;
                a2[index2] = j;
                ++index2;
            }
        }
        final String cMap2 = cMap.substring(a2[0] + 1, a2[1]);
        final String replace_color = regEx(cMap2);
        final String final_color = cMap.replace(cMap2, replace_color);
        return cPath.replace(cMap, final_color);
    }
    
    static String regEx(String color) {
        final String regEx = "[\\[|\\]|(|//|&|.|$|,|\\d|\\)|-]|(AND)|(and)|(And)|(with)|(With)";
        color = color.replaceAll(regEx, "&");
        if (color.indexOf("&") == 0) {
            color = color.replaceFirst(regEx, "");
        }
        while (color.contains("&&")) {
            color = color.replaceAll("&&", "&");
        }
        return color;
    }
}
