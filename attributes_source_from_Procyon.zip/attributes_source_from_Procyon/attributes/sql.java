// 
// Decompiled by Procyon v0.5.36
// 

package attributes;

import java.sql.CallableStatement;
import java.util.Iterator;
import java.util.Set;
import java.lang.reflect.UndeclaredThrowableException;
import java.io.UnsupportedEncodingException;
import org.json.simple.parser.ParseException;
import java.sql.SQLException;
import java.sql.DriverManager;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import com.mysql.jdbc.Statement;
import java.sql.Connection;

public class sql
{
    static Connection conn;
    static Statement stmt;
    static JSONParser parser;
    static JSONObject jobj;
    
    static {
        sql.conn = null;
        sql.parser = new JSONParser();
        sql.jobj = null;
    }
    
    public static void dbconfig() throws IllegalAccessException, InstantiationException, SQLException, ParseException, UnsupportedEncodingException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            final String url = "jdbc:mysql://IWW-PC:3306/wsimcpsn_shopnowee";
            sql.conn = DriverManager.getConnection(url, "root", "Alfred_21");
            System.out.println("CONNECTION DONE");
        }
        catch (Exception ex) {
            System.err.println(ex.getMessage());
        }
        sql.stmt = (Statement)sql.conn.createStatement();
    }
    
    public static void dbconfig2() throws IllegalAccessException, InstantiationException, SQLException, ParseException, UnsupportedEncodingException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            final String url = "jdbc:mysql://admin-PC:3306/test";
            sql.conn = DriverManager.getConnection(url, "root", "Alfred_21");
            System.out.println("CONNECTION DONE");
        }
        catch (Exception ex) {
            System.err.println(ex.getMessage());
        }
        sql.stmt = (Statement)sql.conn.createStatement();
    }
    
    public static void doKeywordsStore(final String str) throws IllegalAccessException, InstantiationException, SQLException, ParseException, UnsupportedEncodingException, UndeclaredThrowableException {
        sql.jobj = (JSONObject)sql.parser.parse(str);
        final String x = sql.jobj.get("product_id");
        final String[] data = x.split("_");
        final String productId = data[1];
        dbconfig();
        final String callProcedure = "call keywordsProcedure('" + productId + "','" + sql.jobj.get("keywords") + "');";
        sql.stmt.executeUpdate(callProcedure);
    }
    
    public static void doImageKeywordsStore(final String str) throws IllegalAccessException, InstantiationException, SQLException, ParseException, UnsupportedEncodingException, UndeclaredThrowableException {
        sql.jobj = (JSONObject)sql.parser.parse(str);
        dbconfig();
        final String callProcedure = "call image_keywordsProcedure('" + sql.jobj.get("product_id") + "','" + sql.jobj.get("keywords") + "');";
        sql.stmt.executeUpdate(callProcedure);
    }
    
    public static void doDealStore(final String str) throws IllegalAccessException, InstantiationException, SQLException, ParseException, UnsupportedEncodingException, UndeclaredThrowableException {
        sql.jobj = (JSONObject)sql.parser.parse(str);
        dbconfig();
        final String callProcedure = "call dealsProcedure('" + sql.jobj.get("name") + "','" + sql.jobj.get("imageUrl") + "','" + sql.jobj.get("show_homepage") + "','" + sql.jobj.get("product_id") + "');";
        sql.stmt.executeUpdate(callProcedure);
    }
    
    public static void doAttrStore(final String str) throws IllegalAccessException, InstantiationException, SQLException, ParseException, UnsupportedEncodingException, UndeclaredThrowableException {
        sql.jobj = (JSONObject)sql.parser.parse(str);
        final String x = sql.jobj.get("product_id");
        final String[] data = x.split("_");
        final String productId = data[1];
        dbconfig();
        final Set keySet = sql.jobj.keySet();
        for (final String att_name : keySet) {
            if (att_name != "product_id") {
                String att_val;
                if (sql.jobj.get(att_name) == "") {
                    att_val = "NA";
                }
                else {
                    att_val = sql.jobj.get(att_name);
                }
                final String callProcedure = "call spInsUpdateProdAttr('" + att_name + "','" + att_val + "','" + productId + "',@insProductID);";
                sql.stmt.executeUpdate(callProcedure);
            }
        }
    }
    
    public static void doCatStore(final String str) throws IllegalAccessException, InstantiationException, SQLException, ParseException, UnsupportedEncodingException, UndeclaredThrowableException {
        sql.jobj = (JSONObject)sql.parser.parse(str);
        dbconfig();
        final String x = sql.jobj.get("product_id");
        final String[] data = x.split("_");
        final String vendorId = data[0];
        final String productId = data[1];
        String parent = null;
        String cName = null;
        final String cPath = sql.jobj.get("categoryPath");
        String child = null;
        if (cPath.toLowerCase().contains("men") || cPath.toLowerCase().contains("man")) {
            parent = "Men";
        }
        if (cPath.toLowerCase().contains("women") || cPath.toLowerCase().contains("woman")) {
            parent = "Women";
        }
        if (cPath.toLowerCase().contains("boys") || cPath.toLowerCase().contains("boy")) {
            parent = "Boys";
        }
        if (cPath.toLowerCase().contains("girls") || cPath.toLowerCase().contains("girl")) {
            parent = "Girls";
        }
        if (cPath.contains(">")) {
            child = cPath.substring(cPath.lastIndexOf(">") + 1, cPath.length());
        }
        else {
            child = cPath;
        }
        if (parent != null) {
            cName = parent;
        }
        else {
            cName = sql.jobj.get("category_name");
        }
        final String callProcedure = "call productInsUpdate('" + cName + "', '" + child + "','" + sql.jobj.get("name") + "','" + sql.jobj.get("description") + "','" + sql.jobj.get("regular_price") + "','" + sql.jobj.get("sale_price") + "','" + sql.jobj.get("stock") + "','" + sql.jobj.get("image") + "','" + sql.jobj.get("product_url") + "','" + productId + "','" + vendorId + "','" + 0 + "','" + sql.jobj.get("similar_product_id") + "',@insProductID);";
        System.out.println(callProcedure);
        sql.stmt.executeUpdate(callProcedure);
    }
    
    public static void path(final String str, final String str1) throws IllegalAccessException, InstantiationException, SQLException, ParseException, UnsupportedEncodingException, UndeclaredThrowableException {
        dbconfig2();
        final String callProcedure = "INSERT IGNORE INTO msg(Cpath,mainCat) VALUES ('" + str + "','" + str1 + "')";
        sql.stmt.executeUpdate(callProcedure);
    }
    
    public static String subPath(final String str) {
        String parent = null;
        String child = null;
        final String cTree = str;
        if (str.contains("Men") || str.contains("Man")) {
            parent = "Men";
        }
        if (str.contains("Women") || str.contains("Woman")) {
            parent = "Women";
        }
        if (str.contains("Boys") || str.contains("Boy")) {
            parent = "Boys";
        }
        if (str.contains("Girls") || str.contains("Girl")) {
            parent = "Girls";
        }
        child = str.substring(str.lastIndexOf(">") + 1, str.length());
        if (parent == null) {
            parent = str;
        }
        if (child == null) {
            child = str;
        }
        final String callProcedure = "INSERT IGNORE INTO levels(parent,child,cTree) VALUES ('" + parent + "','" + child + "','" + cTree + "')";
        return callProcedure;
    }
    
    public static String cat_map(final String str) {
        String parent = null;
        String child = null;
        String cMap = null;
        int i = 0;
        int index = 0;
        int find = 0;
        final Integer[] a = new Integer[10];
        for (i = 0; i < str.length(); ++i) {
            if (str.charAt(i) == '>') {
                ++find;
                a[index] = i;
                ++index;
            }
        }
        if (str.contains("Men")) {
            parent = "Men";
        }
        if (str.contains("Women")) {
            parent = "Women";
        }
        if (str.contains("Boys")) {
            parent = "Boys";
        }
        if (str.contains("Girls")) {
            parent = "Girls";
        }
        child = str.substring(str.lastIndexOf(">") + 1, str.length());
        if (parent == null) {
            parent = str;
        }
        if (child == null) {
            child = str;
        }
        if (find >= 3) {
            if (str.contains("Infant") || str.contains("Kids")) {
                cMap = str.substring(a[index - 2] + 1, a[index - 1]);
            }
            else {
                cMap = str.substring(a[1] + 1, a[2]);
            }
        }
        else {
            cMap = child;
        }
        System.out.println("Root(Parent)\t:\t" + parent);
        System.out.println("Sub(Map)Category:\t" + cMap);
        System.out.println("Category(Child)\t:\t" + child + "\n");
        final String callProcedure = "INSERT IGNORE INTO catg_map(main,src,destn) VALUES ('" + parent + "','" + cMap + "','" + child + "')";
        return callProcedure;
    }
    
    public static void call_proc(final String s) throws IllegalAccessException, InstantiationException, UnsupportedEncodingException, SQLException, ParseException {
        dbconfig();
        final CallableStatement cStmt = sql.conn.prepareCall(s);
        cStmt.execute();
    }
}
